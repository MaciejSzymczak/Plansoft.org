SPOOL Version30.log

CREATE OR REPLACE FUNCTION EXTRACTWORD  (poz NUMBER, str VARCHAR, sep VARCHAR) RETURN VARCHAR IS
word VARCHAR2(2000):='';
word2 VARCHAR2(2000);
str2 VARCHAR2(2000):= str || sep;
BEGIN
/*
 Zwraca ciag znakow miedzy separatorami
 poz - ktory ciag
 str - string
 sep - separator np. '|'
*/
for i in 1..poz loop
 if i = 1 then
  word:=substr(str2,1,instr(str2,sep,poz)-1);
  word2:=str2;
 else
  word2:=substr(word2,length(word2)+2-length(substr(word2,instr(word2,sep,1))));
     word:=substr(word2,1,instr(word2,sep,1)-1);
 end if;
end loop;
  RETURN Word;
 exception when others then
   WORD:='Prosz� zmieni� parametry wej�ciowe';
  RETURN WORD;
END;
/

CREATE OR REPLACE FUNCTION "ISSUBSETOF" (Set1 VARCHAR2, Set2 VARCHAR2) return VARCHAR2 is
 T INTEGER;
 NOT_FOUND BOOLEAN;
 ELEMENT VARCHAR2(100);
/* 
FUNCTION RETURNS TRUE IF SET1 IS A SUBSET OF SET2
ELEMENTS ARE SEPARATED BY ;
*/ 
BEGIN
 NOT_FOUND := FALSE;
 T := 1;
 ELEMENT := EXTRACTWORD(1,SET1,';');
 while (NVL(ELEMENT,'<EMPTY>') <> '<EMPTY>') AND (NOT_FOUND = FALSE) loop
   IF InStr(Set2, ELEMENT) = 0 then 
     NOT_FOUND := TRUE;
   END IF;	 
   T := T + 1;
   ELEMENT := EXTRACTWORD(T,SET1,';');
 end loop;
 IF NOT_FOUND THEN 
    RETURN 'N';
 ELSE 
    RETURN 'Y';
 END IF;
END;
/


commit;
spool off
