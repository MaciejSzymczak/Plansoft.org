insert into system_parameters (name, value, description) values ('TT_LOG', 'N', 'Disables or enables internal looging for module tt. Logs cunsumes a lot or resource (db space), so use it carrefully. Logs are stored in the table tt_logs');

update system_parameters set value = '4.1' where name = 'PLANOWANIE.VERSION_INFO';

/*
drop sequence tt_check_results_seq;
drop sequence tt_seq;
drop view tt_check_results_v;
drop view tt_rescat_combinations_v;
drop table tt_pla;
drop table tt_cla;
drop table tt_check_results;
drop table tt_resource_lists;
drop table tt_inclusions;
drop table tt_combinations;
drop table tt_rescat_combinations_dtl;
drop table tt_rescat_combinations;
drop table tt_log;
drop table tt_ids;
drop table timetable;
drop public synonym timetable;
*/

create table tt_rescat_combinations (
    id                 number primary key
  , combination_number number not null
  , cardinality        number not null
);

create unique index tt_rescat_combinations_uk on tt_rescat_combinations (combination_number, cardinality);

comment on table tt_rescat_combinations is 'Sprawdzane kombinacje typ�w zasob�w np. wyk�adowca i przedmiot; grupa i przedmiot i forma i liczba godzin zaj��';
comment on column tt_rescat_combinations.combination_number  is 'Suma kolumny resource_categories.weight typ�w zasob�w, kt�re wesz�y do kombinacji';
comment on column tt_rescat_combinations.cardinality         is 'Liczba element�w, kt�ra wesz�a do kombinacji. Liczba element�w, opr�cz wagi jest potrzebna, ze wzgl�du na to, �e zasoby z tej samej kategorii mog� wyst�powa� wielokrotnie';


create table tt_pla (
 id         number primary key
,pla_id     number not null
,rescat_comb_id number not null
);

comment on table tt_pla is 'Powi�zanie typ kombinacji - planista. Tylko dla powi�zanego planisty aktywny jest typ kombinacji';

create index tt_pla_i1 on tt_pla (pla_id);
create index tt_pla_i2 on tt_pla (rescat_comb_id);

alter table tt_pla add  constraint tt_pla_fk1
 foreign key (pla_id) 
  references planners (id) on delete cascade;

alter table tt_pla add  constraint tt_pla_fk2
 foreign key (rescat_comb_id) 
  references tt_rescat_combinations (id) on delete cascade;

create unique index tt_pla_u1 on tt_pla (pla_id, rescat_comb_id);

create table tt_rescat_combinations_dtl
( id number primary key
, rescat_comb_id number not null
, rescat_id number not null
, created_by       varchar2(30 byte) default user not null
, creation_date    date              default sysdate not null
);

alter table tt_rescat_combinations_dtl add  constraint tt_rescat_combinations_dtl_fk1
 foreign key (rescat_comb_id) 
  references tt_rescat_combinations (id) on delete cascade;
  
alter table tt_rescat_combinations_dtl add  constraint tt_rescat_combinations_dtl_fk2
 foreign key (rescat_id) 
  references resource_categories (id);
  
create index tt_rescat_combinations_dtl_i1 on tt_rescat_combinations_dtl (rescat_comb_id);
create index tt_rescat_combinations_dtl_i2 on tt_rescat_combinations_dtl (rescat_id);

comment on table tt_rescat_combinations_dtl is 'Intersekcja pomi�dzy tabelami "tt_rescat_combinations" i "resource_combinations"';

create table tt_combinations
(id             number(10) primary key
,rescat_comb_id number not null
,weight         number
,avail_type     char(1) default 'N' 
,avail_orig     number  default null
,avail_curr     number  default null
,enabled        char(1) default 'Y' not null
,sort_order     number(10)
);

alter table tt_combinations add  constraint tt_combinations_fk1
 foreign key (rescat_comb_id) 
  references tt_rescat_combinations (id) on delete cascade;

create index tt_combinations_I0 on tt_combinations (rescat_comb_id);
create index tt_combinations_I1 on tt_combinations (weight);
create index tt_combinations_I2 on tt_combinations (avail_curr);
create index tt_combinations_I3 on tt_combinations (avail_orig);
create index tt_combinations_I5 on tt_combinations (avail_type);

--bitmap index not enabled in 10g so add ordinaly index
create index tt_combinations_I4 on tt_combinations (enabled);

comment on column tt_combinations.weight     is 'Waga wynikaj�ca z sumowania wag poszczeg�lnych typ�w zasob�w z podrz�dnej tabeli tt_inclusions';
comment on column tt_combinations.avail_type is 'Typ dost�pnosci zasobu: N=NOLIMIT, L=LIMIT';
comment on column tt_combinations.avail_orig is 'Pocz�tkowa liczba jednostek dost�pnosci';
comment on column tt_combinations.avail_curr is 'Bie��ca liczba jednostek dost�pnosci';
comment on column tt_combinations.enabled    is 'Czy rekord jest dost�pny';
comment on column tt_combinations.sort_order is 'Porz�dek wy�wietlania danych, zdefiniowany przez u�ytkownika';

create table tt_inclusions
(id number primary key
,tt_comb_id number not null
,rescat_id number not null
,inclusion_type varchar2(5) not null--list none all n/a
);

create table tt_resource_lists
(id number primary key
,tt_comb_id number not null
,res_id number not null
);

alter table tt_inclusions add ( constraint tt_inclusions_c1 check (inclusion_type in ('LIST', 'ALL' )));

alter table tt_inclusions add  constraint tt_inclusions_fk1
 foreign key (tt_comb_id) 
  references tt_combinations (id) on delete cascade;

alter table tt_resource_lists add  constraint tt_resource_lists_fk1
 foreign key (tt_comb_id) 
  references tt_combinations (id) on delete cascade;

create index tt_inclusions_i1 on tt_inclusions (tt_comb_id);
create index tt_resource_lists_i1 on tt_resource_lists (tt_comb_id);

alter table tt_inclusions add  constraint tt_inclusions_fk2
 foreign key (rescat_id) 
  references resource_categories (id) on delete cascade;

alter table tt_inclusions drop constraint TT_INCLUSIONS_FK2;  
  
create index tt_inclusions_i2 on tt_inclusions (rescat_id);

create unique index tt_inclusions_u1 on tt_inclusions (tt_comb_id, rescat_id);

create unique index tt_resource_lists_u1 on tt_resource_lists (tt_comb_id, res_id);

comment on table tt_combinations is 'Dozwolone kombinacje zasob�w';

comment on table tt_resource_lists is 'Lista dozwolonych zasob�w dla danej kombinacji';
comment on column tt_resource_lists.tt_comb_id is 'Klucz obcy';
comment on column tt_resource_lists.res_id is 'Klucz obcy';

comment on table tt_inclusions is 'Typy w��cze� tzn. albo lista zasob�w dla okre�lonej kategorii zasob�w albo wszystkie zasoby dla okre�lonej kategorii zasob�w';
comment on column tt_inclusions.tt_comb_id is 'Klucz obcy'; 
comment on column tt_inclusions.rescat_id is 'Klucz obcy';
comment on column tt_inclusions.inclusion_type is 'LIST = lista zasob�w ALL=ka�dy zas�b dozwolony';

create global temporary table tt_check_results
( id number primary key
, found_tt number
, rescat_comb_id number
);

declare 
 l number;
begin
 for l in 1..200 loop
   execute immediate 'alter table tt_check_results add ( res_id'||l||'    number, rescat_id'||l||' number, res_desc'||l||'  varchar2(240))';
 end loop;  
end;
/

create sequence tt_check_results_seq;
create sequence tt_seq;


alter table resource_categories add ( weight number, plural_name varchar2(30) default 'name');
alter table resource_categories add ( sql_name varchar2(60) default 'name');
alter table resource_categories modify ( name not null);

create index resource_categories_i1 on resource_categories (weight);

create or replace package resource_categories_pkg as
  type tids is table of number index by binary_integer;
  ids tids;
end;
/

create or replace trigger resource_categories_trg_fer
after insert on resource_categories referencing new as new for each row
begin
  resource_categories_pkg.ids( resource_categories_pkg.ids.count+1 ) := :new.id;
end;

create or replace trigger resource_categories_trg
after insert on resource_categories
declare
  l_char		varchar2(250);
  j			number;
begin
  j := resource_categories_pkg.ids.first;
  while j is not null loop
    update	resource_categories
       set	weight = nvl( ( select max(weight)*2 from resource_categories ), 1) 
     where	id = resource_categories_pkg.ids (j);
    j := resource_categories_pkg.ids.next(j);
  end loop;
  resource_categories_pkg.ids.delete;
end;

begin
  delete from resource_categories where id < 0;
  insert into resource_categories(id,name, weight, plural_name, sql_name) values (-2, 'Forma zaj��'   ,null , 'Formy zaj��'   , 'name||''(''||abbreviation||'')''');
  insert into resource_categories(id,name, weight, plural_name, sql_name) values (-3, 'Przedmiot'     ,null , 'Przedmioty'    , 'name');
  insert into resource_categories(id,name, weight, plural_name, sql_name) values (-4, 'Wyk�adowca'    ,null , 'Wyk�adowcy'    , 'title||'' ''||last_name||'' ''||first_name');
  insert into resource_categories(id,name, weight, plural_name, sql_name) values (-5, 'Grupa'         ,null , 'Grupy'         , 'abbreviation');
  insert into resource_categories(id,name, weight, plural_name, sql_name) values (-6, 'Planista'      ,null,  'Plani�ci'      , 'name');
  insert into resource_categories(id,name, weight, plural_name, sql_name) values (-7, 'Semestr'       ,null,  'Semestry'      , 'name');
  insert into resource_categories(id,name, weight, plural_name, sql_name) values (-8, 'Data i godzina',null,  'Daty i godziny', 'n/a');
  update resource_categories
    set name = 'Sala'
      , plural_name = 'Sale'
      , sql_name = 'name||'' ''||substr(attribs_01,1,55)'
    where id = 1;  
  commit;
end;

begin
 update resource_categories set weight = null;
 for rec in (select * from resource_categories order by id) loop
  update resource_categories 
     set weight = nvl( ( select max(weight)*2 from resource_categories ), 1)
    where id = rec.id;
 end loop;
 commit;
end;


alter table tt_combinations add
( attribs_01         varchar2(240 byte),
  attribs_02         varchar2(240 byte),
  attribs_03         varchar2(240 byte),
  attribs_04         varchar2(240 byte),
  attribs_05         varchar2(240 byte),
  attribs_06         varchar2(240 byte),
  attribs_07         varchar2(240 byte),
  attribs_08         varchar2(240 byte),
  attribs_09         varchar2(240 byte),
  attribs_10         varchar2(240 byte),
  attribs_11         varchar2(240 byte),
  attribs_12         varchar2(240 byte),
  attribs_13         varchar2(240 byte),
  attribs_14         varchar2(240 byte),
  attribs_15         varchar2(240 byte),
  attribd_01         date,
  attribd_02         date,
  attribd_03         date,
  attribd_04         date,
  attribd_05         date,
  attribd_06         date,
  attribd_07         date,
  attribd_08         date,
  attribd_09         date,
  attribd_10         date,
  attribd_11         date,
  attribd_12         date,
  attribd_13         date,
  attribd_14         date,
  attribd_15         date,
  attribn_01         number,
  attribn_02         number,
  attribn_03         number,
  attribn_04         number,
  attribn_05         number,
  attribn_06         number,
  attribn_07         number,
  attribn_08         number,
  attribn_09         number,
  attribn_10         number,
  attribn_11         number,
  attribn_12         number,
  attribn_13         number,
  attribn_14         number,
  attribn_15         number,
  creation_date      date                       default sysdate               not null,
  created_by         varchar2(30 byte)          default user                  not null,
  last_update_date   date                       default sysdate               not null,
  last_updated_by    varchar2(30 byte)          default user                  not null
);


alter table tt_rescat_combinations add
( attribs_01         varchar2(240 byte),
  attribs_02         varchar2(240 byte),
  attribs_03         varchar2(240 byte),
  attribs_04         varchar2(240 byte),
  attribs_05         varchar2(240 byte),
  attribs_06         varchar2(240 byte),
  attribs_07         varchar2(240 byte),
  attribs_08         varchar2(240 byte),
  attribs_09         varchar2(240 byte),
  attribs_10         varchar2(240 byte),
  attribs_11         varchar2(240 byte),
  attribs_12         varchar2(240 byte),
  attribs_13         varchar2(240 byte),
  attribs_14         varchar2(240 byte),
  attribs_15         varchar2(240 byte),
  attribd_01         date,
  attribd_02         date,
  attribd_03         date,
  attribd_04         date,
  attribd_05         date,
  attribd_06         date,
  attribd_07         date,
  attribd_08         date,
  attribd_09         date,
  attribd_10         date,
  attribd_11         date,
  attribd_12         date,
  attribd_13         date,
  attribd_14         date,
  attribd_15         date,
  attribn_01         number,
  attribn_02         number,
  attribn_03         number,
  attribn_04         number,
  attribn_05         number,
  attribn_06         number,
  attribn_07         number,
  attribn_08         number,
  attribn_09         number,
  attribn_10         number,
  attribn_11         number,
  attribn_12         number,
  attribn_13         number,
  attribn_14         number,
  attribn_15         number,
  creation_date      date                       default sysdate               not null,
  created_by         varchar2(30 byte)          default user                  not null,
  last_update_date   date                       default sysdate               not null,
  last_updated_by    varchar2(30 byte)          default user                  not null
);

create or replace view tt_rescat_combinations_v
as 
select t.*, tt_planner.get_resource_cat_names (t.combination_number) names 
  from tt_rescat_combinations t
/    

create or replace view tt_check_results_v as
select trim(',' from 
         decode(res_desc1,0, null, res_desc1||'    :    ') ||
         decode(res_desc2,0, null, res_desc2||'    :    ') ||
         decode(res_desc3,0, null, res_desc3||'    :    ') ||
         decode(res_desc4,0, null, res_desc4||'    :    ') ||
         decode(res_desc5,0, null, res_desc5||'    :    ') ||
         decode(res_desc6,0, null, res_desc6||'    :    ') ||
         decode(res_desc7,0, null, res_desc7||'    :    ') ||
         decode(res_desc8,0, null, res_desc8||'    :    ') ||
         decode(res_desc9,0, null, res_desc9||'    :    ') ||
         decode(res_desc10,0, null, res_desc10||'    :    ') ||
         decode(res_desc11,0, null, res_desc11||'    :    ') ||
         decode(res_desc12,0, null, res_desc12||'    :    ') ||
         decode(res_desc13,0, null, res_desc13||'    :    ') ||
         decode(res_desc14,0, null, res_desc14||'    :    ') ||
         decode(res_desc15,0, null, res_desc15||'    :    ') ||
         decode(res_desc16,0, null, res_desc16||'    :    ') ||
         decode(res_desc17,0, null, res_desc17||'    :    ') ||
         decode(res_desc18,0, null, res_desc18||'    :    ') ||
         decode(res_desc19,0, null, res_desc19||'    :    ') ||
         decode(res_desc20,0, null, res_desc20||'    :    ') ||
         decode(res_desc21,0, null, res_desc21||'    :    ') ||
         decode(res_desc22,0, null, res_desc22||'    :    ') ||
         decode(res_desc23,0, null, res_desc23||'    :    ') ||
         decode(res_desc24,0, null, res_desc24||'    :    ') ||
         decode(res_desc25,0, null, res_desc25||'    :    ') ||
         decode(res_desc26,0, null, res_desc26||'    :    ') ||
         decode(res_desc27,0, null, res_desc27||'    :    ') ||
         decode(res_desc28,0, null, res_desc28||'    :    ') ||
         decode(res_desc29,0, null, res_desc29||'    :    ') ||
         decode(res_desc30,0, null, res_desc30||'    :    ') ||
         decode(res_desc31,0, null, res_desc31||'    :    ') ||
         decode(res_desc32,0, null, res_desc32||'    :    ') ||
         decode(res_desc33,0, null, res_desc33||'    :    ') ||
         decode(res_desc34,0, null, res_desc34||'    :    ') ||
         decode(res_desc35,0, null, res_desc35||'    :    ') ||
         decode(res_desc36,0, null, res_desc36||'    :    ') ||
         decode(res_desc37,0, null, res_desc37||'    :    ') ||
         decode(res_desc38,0, null, res_desc38||'    :    ') ||
         decode(res_desc39,0, null, res_desc39||'    :    ') ||
         decode(res_desc40,0, null, res_desc40||'    :    ') ||
         decode(res_desc41,0, null, res_desc41||'    :    ') ||
         decode(res_desc42,0, null, res_desc42||'    :    ') ||
         decode(res_desc43,0, null, res_desc43||'    :    ') ||
         decode(res_desc44,0, null, res_desc44||'    :    ') ||
         decode(res_desc45,0, null, res_desc45||'    :    ') ||
         decode(res_desc46,0, null, res_desc46||'    :    ') ||
         decode(res_desc47,0, null, res_desc47||'    :    ') ||
         decode(res_desc48,0, null, res_desc48||'    :    ') ||
         decode(res_desc49,0, null, res_desc49||'    :    ') ||
         decode(res_desc50,0, null, res_desc50||'    :    ') ||
         decode(res_desc51,0, null, res_desc51||'    :    ') ||
         decode(res_desc52,0, null, res_desc52||'    :    ') ||
         decode(res_desc53,0, null, res_desc53||'    :    ') ||
         decode(res_desc54,0, null, res_desc54||'    :    ') ||
         decode(res_desc55,0, null, res_desc55||'    :    ') ||
         decode(res_desc56,0, null, res_desc56||'    :    ') ||
         decode(res_desc57,0, null, res_desc57||'    :    ') ||
         decode(res_desc58,0, null, res_desc58||'    :    ') ||
         decode(res_desc59,0, null, res_desc59||'    :    ') ||
         decode(res_desc60,0, null, res_desc60||'    :    ') ||
         decode(res_desc61,0, null, res_desc61||'    :    ') ||
         decode(res_desc62,0, null, res_desc62||'    :    ') ||
         decode(res_desc63,0, null, res_desc63||'    :    ') ||
         decode(res_desc64,0, null, res_desc64||'    :    ') ) concatenated_desc
        ,decode(to_char(res_id1),0, null, res_id1||',') ||
         decode(to_char(res_id2),0, null, res_id2||',') ||
         decode(to_char(res_id3),0, null, res_id3||',') ||
         decode(to_char(res_id4),0, null, res_id4||',') ||
         decode(to_char(res_id5),0, null, res_id5||',') ||
         decode(to_char(res_id6),0, null, res_id6||',') ||
         decode(to_char(res_id7),0, null, res_id7||',') ||
         decode(to_char(res_id8),0, null, res_id8||',') ||
         decode(to_char(res_id9),0, null, res_id9||',') ||
         decode(to_char(res_id10),0, null, res_id10||',') ||
         decode(to_char(res_id11),0, null, res_id11||',') ||
         decode(to_char(res_id12),0, null, res_id12||',') ||
         decode(to_char(res_id13),0, null, res_id13||',') ||
         decode(to_char(res_id14),0, null, res_id14||',') ||
         decode(to_char(res_id15),0, null, res_id15||',') ||
         decode(to_char(res_id16),0, null, res_id16||',') ||
         decode(to_char(res_id17),0, null, res_id17||',') ||
         decode(to_char(res_id18),0, null, res_id18||',') ||
         decode(to_char(res_id19),0, null, res_id19||',') ||
         decode(to_char(res_id20),0, null, res_id20||',') ||
         decode(to_char(res_id21),0, null, res_id21||',') ||
         decode(to_char(res_id22),0, null, res_id22||',') ||
         decode(to_char(res_id23),0, null, res_id23||',') ||
         decode(to_char(res_id24),0, null, res_id24||',') ||
         decode(to_char(res_id25),0, null, res_id25||',') ||
         decode(to_char(res_id26),0, null, res_id26||',') ||
         decode(to_char(res_id27),0, null, res_id27||',') ||
         decode(to_char(res_id28),0, null, res_id28||',') ||
         decode(to_char(res_id29),0, null, res_id29||',') ||
         decode(to_char(res_id30),0, null, res_id30||',') ||
         decode(to_char(res_id31),0, null, res_id31||',') ||
         decode(to_char(res_id32),0, null, res_id32||',') ||
         decode(to_char(res_id33),0, null, res_id33||',') ||
         decode(to_char(res_id34),0, null, res_id34||',') ||
         decode(to_char(res_id35),0, null, res_id35||',') ||
         decode(to_char(res_id36),0, null, res_id36||',') ||
         decode(to_char(res_id37),0, null, res_id37||',') ||
         decode(to_char(res_id38),0, null, res_id38||',') ||
         decode(to_char(res_id39),0, null, res_id39||',') ||
         decode(to_char(res_id40),0, null, res_id40||',') ||
         decode(to_char(res_id41),0, null, res_id41||',') ||
         decode(to_char(res_id42),0, null, res_id42||',') ||
         decode(to_char(res_id43),0, null, res_id43||',') ||
         decode(to_char(res_id44),0, null, res_id44||',') ||
         decode(to_char(res_id45),0, null, res_id45||',') ||
         decode(to_char(res_id46),0, null, res_id46||',') ||
         decode(to_char(res_id47),0, null, res_id47||',') ||
         decode(to_char(res_id48),0, null, res_id48||',') ||
         decode(to_char(res_id49),0, null, res_id49||',') ||
         decode(to_char(res_id50),0, null, res_id50||',') ||
         decode(to_char(res_id51),0, null, res_id51||',') ||
         decode(to_char(res_id52),0, null, res_id52||',') ||
         decode(to_char(res_id53),0, null, res_id53||',') ||
         decode(to_char(res_id54),0, null, res_id54||',') ||
         decode(to_char(res_id55),0, null, res_id55||',') ||
         decode(to_char(res_id56),0, null, res_id56||',') ||
         decode(to_char(res_id57),0, null, res_id57||',') ||
         decode(to_char(res_id58),0, null, res_id58||',') ||
         decode(to_char(res_id59),0, null, res_id59||',') ||
         decode(to_char(res_id60),0, null, res_id60||',') ||
         decode(to_char(res_id61),0, null, res_id61||',') ||
         decode(to_char(res_id62),0, null, res_id62||',') ||
         decode(to_char(res_id63),0, null, res_id63||',') ||
         decode(to_char(res_id64),0, null, res_id64||',')  concatenated_res_ids
        ,tt_check_results.*
        ,tt_check_results.rowid tt_check_results_rowid         
  from tt_check_results
/

update resource_categories set sql_name = 'name' where sql_name is null
/

commit
/

create table tt_log
(
  id            number(11) primary key,
  message       varchar2(200 byte),
  parameters    clob,
  created       date                            default sysdate
);

drop sequence pla_Seq;
drop sequence per_Seq;

declare
 l_newId number := 600;
begin
  for rec in (select * from periods order by id) loop 
    xxmsz_tools.update_record('PLANNER','PERIODS', rec.id, l_newId, 'ID');
    l_newId := l_newId + 1;
    commit;
  end loop;
  for rec in (select * from planners order by id) loop 
    xxmsz_tools.update_record('PLANNER','PLANNERS', rec.id, l_newId, 'ID');
    l_newId := l_newId + 1;
    commit;
  end loop;
end;  

create global temporary table tt_ids ( id number );

create table tt_cla (
 id         number primary key
,cla_id     number not null
,tt_comb_id number not null
);

comment on table tt_cla is 'Powi�zanie zaj�cie - dozwolone kombinacje';

create index tt_cla_i1 on tt_cla (cla_id);
create index tt_cla_i2 on tt_cla (tt_comb_id);

alter table tt_cla add  constraint tt_cla_fk1
 foreign key (cla_id) 
  references classes (id) on delete cascade;

alter table tt_cla add  constraint tt_cla_fk2
 foreign key (tt_comb_id) 
  references tt_combinations (id) on delete cascade;

create unique index tt_cla_u1 on tt_cla (cla_id, tt_comb_id);


--SELECT  * 
--FROM PLANNER.LOOKUPS
--WHERE (0=0 AND ROWNUM <= 1000) AND lookup_type = 'DBMESSAGE_TRANSLATION' AND 0=0
--ORDER BY ID

begin
  delete from lookups where LOOKUP_TYPE = 'DBMESSAGE_TRANSLATION' AND CODE = 'TT_PLA_U1';
  insert into lookups (ID, VALUE_SET_ID, LOOKUP_TYPE, CODE, MEANING, DESCRIPTION, ENABLED) 
  values (
   lookups_seq.nextval
  ,(select id from value_sets where name = 'DBMESSAGE_TRANSLATION') 
  ,'DBMESSAGE_TRANSLATION'
  ,'TT_PLA_U1'
  ,'Nie mo�na ponownie doda� tego samego planisty'
  ,null
  ,'Y'
   );
  commit;
end;
    
@version4.0.tt_extras.sql
@CREATE_PUBLIC_SYNONYMS.sql

create or replace view tt_rescat_combinations_v
as 
select t.*, tt_planner.get_resource_cat_names (t.combination_number) names 
  from tt_rescat_combinations t
/    


