INSERT INTO SUBJECTS (ID,NAME,abbreviation,COLOUR) VALUES (1,'Modelowanie matematyczne','MM',16776960);
INSERT INTO SUBJECTS (ID,NAME,abbreviation,COLOUR) VALUES (2,'Sztuczna inteligencja','SI',16711680);
INSERT INTO SUBJECTS (ID,NAME,abbreviation,COLOUR) VALUES (3,'Matematyka','M',255);
INSERT INTO SUBJECTS (ID,NAME,abbreviation,COLOUR) VALUES (4,'Kryptografia','Kr',12632256);
INSERT INTO SUBJECTS (ID,NAME,abbreviation,COLOUR) VALUES (5,'Chemia','Ch',8421504);
INSERT INTO SUBJECTS (ID,NAME,abbreviation,COLOUR) VALUES (6,'Modelografia','Mo',4648002);
INSERT INTO SUBJECTS (ID,NAME,abbreviation,COLOUR) VALUES (7,'Geografia','G',326651);
