
UPDATE LECTURERS SET abbreviation = abbreviation||ID WHERE abbreviation IN (SELECT abbreviation FROM (SELECT abbreviation, COUNT(*) FROM LECTURERS GROUP BY abbreviation HAVING COUNT(*) > 1));
CREATE UNIQUE INDEX LEC_abbreviation_I ON LECTURERS (abbreviation);

UPDATE GROUPS SET abbreviation = abbreviation||ID WHERE abbreviation IN (SELECT abbreviation FROM (SELECT abbreviation, COUNT(*) FROM GROUPS GROUP BY abbreviation HAVING COUNT(*) > 1));
CREATE UNIQUE INDEX GRO_abbreviation_I ON GROUPS (abbreviation);

UPDATE SUBJECTS SET abbreviation = abbreviation||ID WHERE abbreviation IN (SELECT abbreviation FROM (SELECT abbreviation, COUNT(*) FROM SUBJECTS GROUP BY abbreviation HAVING COUNT(*) > 1));
CREATE UNIQUE INDEX SUB_abbreviation_I ON SUBJECTS (abbreviation);

UPDATE FORMS SET abbreviation = abbreviation||ID WHERE abbreviation IN (SELECT abbreviation FROM (SELECT abbreviation, COUNT(*) FROM FORMS GROUP BY abbreviation HAVING COUNT(*) > 1));
CREATE UNIQUE INDEX FRM_abbreviation_I ON FORMS (abbreviation);
