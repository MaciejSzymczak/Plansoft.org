SPOOL Version33.log

connect planner/planner@planning.world

PROMPT PORZ�DEK SORTOWANIA FORM ZAJ�� NA RAPORTACH 

ALTER TABLE PLANNER.FORMS ADD (SORT_ORDER_ON_REPORTS NUMBER);

UPDATE PLANNER.FORMS SET SORT_ORDER_ON_REPORTS = 1 WHERE NAME = 'Wyk�ad';
UPDATE PLANNER.FORMS SET SORT_ORDER_ON_REPORTS = 2 WHERE NAME = '�wiczenia';
UPDATE PLANNER.FORMS SET SORT_ORDER_ON_REPORTS = 3 WHERE NAME = 'Laboratorium';
UPDATE PLANNER.FORMS SET SORT_ORDER_ON_REPORTS = 4 WHERE NAME = 'Pracownia problemowa';
UPDATE PLANNER.FORMS SET SORT_ORDER_ON_REPORTS = 5 WHERE NAME = 'Projekt';
UPDATE PLANNER.FORMS SET SORT_ORDER_ON_REPORTS = 6 WHERE NAME = 'Egzamin';
COMMIT;

PROMPT TABELA Z U�YCIAMI PODGL�DANYMI

CREATE TABLE LOOKUPS (
 ID           NUMBER       NOT NULL
,TYPE         VARCHAR2(50) NOT NULL
,CODE         VARCHAR2(50) NOT NULL
,NAME         VARCHAR2(50) NOT NULL
,DESCRIPTION  VARCHAR2(50)
);

CREATE SEQUENCE LOO_SEQ START WITH 50;
ALTER TABLE LOOKUPS ADD CONSTRAINT LOO_PK PRIMARY KEY (ID);
CREATE INDEX LOO_TYPE_FK_I ON LOOKUPS (TYPE);
CREATE INDEX LOO_CODE_FK_I ON LOOKUPS (CODE);
CREATE INDEX LOO_NAME_FK_I ON LOOKUPS (NAME);

DELETE FROM LOOKUPS;
INSERT INTO LOOKUPS ( ID, TYPE, CODE, NAME, DESCRIPTION ) VALUES (LOO_SEQ.NEXTVAL, 'GROUP_TYPE',        'STATIONARY',      'Dzienne', NULL );
INSERT INTO LOOKUPS ( ID, TYPE, CODE, NAME, DESCRIPTION ) VALUES (LOO_SEQ.NEXTVAL, 'GROUP_TYPE',        'EXTRAMURAL',      'Zaoczne', NULL );
INSERT INTO LOOKUPS ( ID, TYPE, CODE, NAME, DESCRIPTION ) VALUES (LOO_SEQ.NEXTVAL, 'FORM_FORMULA_TYPE', 'LEC_UTILIZATION', 'Obci��enie wyk�adowc�w', NULL );
INSERT INTO LOOKUPS ( ID, TYPE, CODE, NAME, DESCRIPTION ) VALUES (LOO_SEQ.NEXTVAL, 'FORM_FORMULA_TYPE', 'STUDENTHOURS',    'Studentogodziny',        NULL );
COMMIT;

CREATE OR REPLACE VIEW LOOKUPS_GROUP_TYPE AS
SELECT * FROM PLANNER.LOOKUPS WHERE TYPE = 'GROUP_TYPE'
/

CREATE OR REPLACE VIEW LOOKUPS_FORM_FORMULA_TYPE AS
SELECT * FROM PLANNER.LOOKUPS WHERE TYPE = 'FORM_FORMULA_TYPE'
/

PROMPT DODANIE TYPU GRUPY DLA GRUPY

ALTER TABLE GROUPS ADD ( GROUP_TYPE VARCHAR2(50));
CREATE INDEX GRO_TYPE_FK_I ON GROUPS (GROUP_TYPE);

PROMPT KONWERSJA TEMP_NUMBER_OF_PEOPLES Z VARCHAR2 NA NUMBER

ALTER TABLE GROUPS ADD ( TEMP_NUMBER_OF_PEOPLES NUMBER(10));
ALTER TABLE ROOMS  ADD ( TEMP_NUMBER_OF_PEOPLES NUMBER(10));

UPDATE GROUPS SET TEMP_NUMBER_OF_PEOPLES = NUMBER_OF_PEOPLES;
UPDATE ROOMS  SET TEMP_NUMBER_OF_PEOPLES = NUMBER_OF_PEOPLES;

ALTER TABLE GROUPS DROP ( NUMBER_OF_PEOPLES );
ALTER TABLE ROOMS  DROP ( NUMBER_OF_PEOPLES );

ALTER TABLE GROUPS ADD ( NUMBER_OF_PEOPLES NUMBER(10));
ALTER TABLE ROOMS  ADD ( NUMBER_OF_PEOPLES NUMBER(10));

UPDATE GROUPS SET NUMBER_OF_PEOPLES = TEMP_NUMBER_OF_PEOPLES;
UPDATE ROOMS  SET NUMBER_OF_PEOPLES = TEMP_NUMBER_OF_PEOPLES;

ALTER TABLE GROUPS DROP ( TEMP_NUMBER_OF_PEOPLES );
ALTER TABLE ROOMS  DROP ( TEMP_NUMBER_OF_PEOPLES );

PROMPT TABELA Z JEDNOSTKAMI ORGANIZACYJNYMI

CREATE TABLE ORG_UNITS (
  ID             NUMBER(10)    NOT NULL
 ,NAME           VARCHAR2(50)  NOT NULL
 ,CODE           VARCHAR2(5)   NOT NULL
 ,PARENT_ID      NUMBER(10)
 ,STRUCT_CODE    VARCHAR2(500) NOT NULL
 ,DESC1          VARCHAR2(200)
 ,DESC2          VARCHAR2(200)
);

CREATE SEQUENCE ORGUNI_SEQ START WITH 50;
ALTER TABLE ORG_UNITS ADD CONSTRAINT ORGUNI_PK PRIMARY KEY (ID);
CREATE INDEX ORGUNI_ORGUNI_FK_I ON ORG_UNITS (PARENT_ID);
ALTER TABLE PLANNER.ORG_UNITS ADD CONSTRAINT ORGUNI_ORGUNI_FK FOREIGN KEY (PARENT_ID) REFERENCES ORG_UNITS (ID);
CREATE UNIQUE INDEX ORGUNI_NAME_FK_I ON ORG_UNITS (NAME);
CREATE UNIQUE INDEX ORGUNI_STRUCT_CODE_FK_I ON ORG_UNITS (STRUCT_CODE);

PROMPT PRZYK�ADOWE DANE

INSERT INTO ORG_UNITS (ID ,NAME ,CODE ,PARENT_ID ,STRUCT_CODE ) VALUES (1, 'Wojskowa Akademia Techniczna','WAT' ,NULL,'WAT');
INSERT INTO ORG_UNITS (ID ,NAME ,CODE ,PARENT_ID ,STRUCT_CODE ) VALUES (2, 'Wydzia� Cybernetyki'         ,'WCY' ,   1,'WAT.WCY');
INSERT INTO ORG_UNITS (ID ,NAME ,CODE ,PARENT_ID ,STRUCT_CODE ) VALUES (3, 'Instytut 1'                  ,'INS1',   2,'WAT.WCY.INS1');
INSERT INTO ORG_UNITS (ID ,NAME ,CODE ,PARENT_ID ,STRUCT_CODE ) VALUES (4, 'Instytut 2'                  ,'INS2',   2,'WAT.WCY.INS2');
INSERT INTO ORG_UNITS (ID ,NAME ,CODE ,PARENT_ID ,STRUCT_CODE ) VALUES (5, 'Instytut 3'                  ,'INS3',   2,'WAT.WCY.INS3');
INSERT INTO ORG_UNITS (ID ,NAME ,CODE ,PARENT_ID ,STRUCT_CODE ) VALUES (6, 'Wydzia� Elektroniki'         ,'WEL' ,   1,'WAT.WEL');

commit;

PROMPT TABELA FORMU� DLA FORM ZAJ��

CREATE TABLE FORM_FORMULAS (
  ID          NUMBER(10)       NOT NULL
 ,FOR_ID      NUMBER(10)       NOT NULL
 ,ORGUNI_ID   NUMBER(10)       NOT NULL
 ,FORMULA_TYPE VARCHAR2(50)    NOT NULL
 ,FORMULA     VARCHAR2(254)    NOT NULL
 ,DATE_FROM   DATE             NOT NULL
 ,DATE_TO     DATE  
 ,DESC1       VARCHAR2(200)
 ,DESC2       VARCHAR2(200)
);

CREATE SEQUENCE FORFOR_SEQ START WITH 50;
ALTER TABLE FORM_FORMULAS ADD CONSTRAINT FORFOR_PK PRIMARY KEY (ID);

CREATE INDEX FORFOR_ORGUNI_FK_I ON FORM_FORMULAS ( ORGUNI_ID );
CREATE INDEX FORFOR_FOR_FK_I    ON FORM_FORMULAS ( FOR_ID );

ALTER TABLE FORM_FORMULAS ADD CONSTRAINT FORFOR_ORGUNI_FK FOREIGN KEY (ORGUNI_ID) REFERENCES ORG_UNITS (ID);
ALTER TABLE FORM_FORMULAS ADD CONSTRAINT FORFOR_FOR_FK    FOREIGN KEY (FOR_ID)    REFERENCES FORMS     (ID);

PROMPT POWI�ZANIE WYK�ADOWCA - JEDNOSTKA ORGANIZACYJNA

ALTER TABLE LECTURERS ADD (ORGUNI_ID NUMBER);

CREATE INDEX LECTURERS_ORGUNI_FK_I ON LECTURERS (ORGUNI_ID);

ALTER TABLE LECTURERS ADD CONSTRAINT LECTURERS_ORGUNI_FK FOREIGN KEY (ORGUNI_ID) REFERENCES ORG_UNITS(ID);

PROMPT TABELA Z PARAMETRAMI SYSTEMOWYMI

CREATE TABLE SYSTEM_PARAMETERS (
  NAME  VARCHAR2(200)
 ,VALUE VARCHAR2(200)
);

CREATE UNIQUE INDEX SYSTEM_PARAMETERS_UK ON SYSTEM_PARAMETERS ( NAME );

INSERT INTO SYSTEM_PARAMETERS (NAME, VALUE ) VALUES ('PLANOWANIE.VERSION_INFO', 'N/A');

PROMPT PAKIET

CREATE OR REPLACE PACKAGE PLANNER_UTILS IS

   /*****************************************************************************************************************************
   |* Planowanie toolkit
   |*****************************************************************************************************************************
   | Maciej Szymczak
   | 2004.11.21 Usuniecie problemu zwiazanego z nie dodawaniem rezerwacji dla sali
   | 2005.04.19 Dodanie funkcji GET_CLASS_COEFFFICIENT
   \*-----------------------------------------------------------------------------------------------------------------------------*/
  
  -- parametry diagnostyczne dla procedury 
  LAST_ERROR             VARCHAR2(1000);
  LAST_ORGUNI_ID         NUMBER;            
  LAST_LEC_ID            NUMBER; 
  LAST_FOR_ID            NUMBER;  

  LAST_FFID              NUMBER;                    
  LAST_FORMULA           VARCHAR2(1000);
  LAST_HORUS             NUMBER;
  LAST_NUMBER_OF_PEOPLES NUMBER;

  PROCEDURE insertClasses(ADAY      DATE
                         ,AHOUR     NUMBER
						 ,AFILL     NUMBER
						 ,ASUB_ID   NUMBER
						 ,AFOR_ID   NUMBER
						 ,AOWNER    VARCHAR2
						 ,Lecturers VARCHAR2
						 ,Groups    VARCHAR2
						 ,Resources VARCHAR2
						);

  PROCEDURE UPDATE_LGRS;       
  
  /*
   Funkcja zwraca warto�� wsp�czynnika dla zaj�cia wyliczonego za pomoca odnalezionej formu�y.
   Funkcja zwraca zero, jezeli wystapi b��d.
   Algotytm wyznaczania formu�y:                                                      
   Dla ka�dego wyk�adowcy:
     Pobierz formu�� na dzie� i wylicz wartosc formuly. Podstaw liczba student�w = liczba wszystkich student�w spo�r�d grup w zaj�ciu.                                                       
     Je�eli nie znaleziono formu�y, pobierz formu�� dla jednostki nadrz�dnej. Powt�rz operacje a� do odnalezienia formu�y lub wyst�pienia b��du.
   Je�eli dla poszczeg�lnych wyk�adowc�w wsp�czynniki r�ni� si�, w�wczas zg�o� b��d.
   
   W przypadku b��du funkcja zwraca warto�� 0. Komunikat o b��dzie odczytaj w�wczas za pomoc� funkcji GET_LAST_ERROR. W celu diagnostyki b�edu sprawd� zmienne o nazwach zaczynaj�cych si� od LAST     
  */
  FUNCTION GET_CLASS_COEFFFICIENT ( AID NUMBER, AFORM_FORMULA_TYPE VARCHAR2, ADAY DATE DEFAULT SYSDATE) RETURN NUMBER;
  FUNCTION GET_LAST_ERROR RETURN VARCHAR2;                                                             
  FUNCTION GET_CLASS_COEFFFICIENT_TESTER ( AID NUMBER, AFORM_FORMULA_TYPE VARCHAR2, ADAY DATE DEFAULT SYSDATE) RETURN VARCHAR2;
END;
/

CREATE OR REPLACE PACKAGE BODY PLANNER_UTILS IS
   

  PROCEDURE UPDATE_LGR(CLA_ID NUMBER);

  PROCEDURE insertClasses(ADAY      DATE
                         ,AHOUR     NUMBER
						 ,AFILL     NUMBER
						 ,ASUB_ID   NUMBER
						 ,AFOR_ID   NUMBER
						 ,AOWNER    VARCHAR2
						 ,Lecturers VARCHAR2
						 ,Groups    VARCHAR2
						 ,Resources VARCHAR2
						) is
    CLA_SEQ_NEXTVAL NUMBER;
	T               NUMBER;
  BEGIN
    SELECT CLA_SEQ.NEXTVAL
	  INTO CLA_SEQ_NEXTVAL
	  FROM DUAL;

    INSERT INTO CLASSES (ID,DAY,HOUR,FILL,SUB_ID,FOR_ID,OWNER) VALUES (CLA_SEQ_NEXTVAL,ADAY ,AHOUR ,AFILL ,ASUB_ID ,AFOR_ID ,AOWNER);

	FOR T IN 1 .. XXMSZ_TOOLS.wordCount(Lecturers, '|') LOOP
	  INSERT INTO LEC_CLA (ID, LEC_ID, CLA_ID) VALUES (LECCLA_SEQ.NEXTVAL,xxmsz_tools.extractWord(T,Lecturers,'|'),CLA_SEQ_NEXTVAL);
	END LOOP;

	FOR T IN 1 .. XXMSZ_TOOLS.wordCount(Groups, '|') LOOP
	  INSERT INTO GRO_CLA (ID, GRO_ID, CLA_ID) VALUES (GROCLA_SEQ.NEXTVAL,xxmsz_tools.extractWord(T,Groups,'|'),CLA_SEQ_NEXTVAL);
	END LOOP;

	FOR T IN 1 .. XXMSZ_TOOLS.wordCount(Resources, '|') LOOP
	  INSERT INTO ROM_CLA (ID, ROM_ID, CLA_ID) VALUES (ROMCLA_SEQ.NEXTVAL,xxmsz_tools.extractWord(T,Resources,'|'),CLA_SEQ_NEXTVAL);
	END LOOP;

    UPDATE_LGR(CLA_SEQ_NEXTVAL);
  END;

  PROCEDURE UPDATE_LGRS IS
    CURSOR CUR IS SELECT ID FROM CLASSES;
  BEGIN
    FOR REC IN CUR LOOP
     UPDATE_LGR(REC.ID);
     COMMIT;
    END LOOP;
  END;

  PROCEDURE UPDATE_LGR(CLA_ID NUMBER) IS
  CURSOR CUR_L(ACLA_ID NUMBER) IS
    SELECT abbreviation X, ID
    FROM   LECTURERS
    WHERE  ID IN (SELECT LEC_ID FROM LEC_CLA WHERE CLA_ID = ACLA_ID) ORDER BY X;
  CURSOR CUR_G(ACLA_ID NUMBER) IS
    SELECT abbreviation X, ID
    FROM   GROUPS
    WHERE  ID IN (SELECT GRO_ID FROM GRO_CLA WHERE CLA_ID = ACLA_ID) ORDER BY X;
  CURSOR CUR_R(ACLA_ID NUMBER) IS
    SELECT NAME||' '||BUILDING X, ID
    FROM   ROOMS
    WHERE  ID IN (SELECT ROM_ID FROM ROM_CLA WHERE CLA_ID = ACLA_ID) ORDER BY X;
  L VARCHAR2(500);
  G VARCHAR2(500);
  R VARCHAR2(500);
  L_ID VARCHAR2(500);
  G_ID VARCHAR2(500);
  R_ID VARCHAR2(500);
  BEGIN
    L    := '';
    L_ID := '';
    FOR REC_L IN CUR_L(CLA_ID) LOOP
     L    := xxmsz_tools.MERGE(L   , REC_L.X , '; ');
     L_ID := xxmsz_tools.MERGE(L_ID, REC_L.ID, ';');
    END LOOP;
    G    := '';
    G_ID := '';
    FOR REC_G IN CUR_G(CLA_ID) LOOP
     G    := xxmsz_tools.MERGE(G   , REC_G.X , '; ');
     G_ID := xxmsz_tools.MERGE(G_ID, REC_G.ID, ';');
    END LOOP;
    R    := '';
    R_ID := '';
    FOR REC_R IN CUR_R(CLA_ID) LOOP
     R    := xxmsz_tools.MERGE(R   , REC_R.X , '; ');
     R_ID := xxmsz_tools.MERGE(R_ID, REC_R.ID, ';');
    END LOOP;
    UPDATE CLASSES
    SET    CALC_LECTURERS = L,
           CALC_GROUPS    = G,
           CALC_ROOMS     = R,
           CALC_LEC_IDS   = L_ID,
           CALC_GRO_IDS   = G_ID,
           CALC_ROM_IDS   = R_ID
    WHERE ID = CLA_ID;
  END;

    FUNCTION GET_CLASS_COEFFFICIENT ( AID NUMBER, AFORM_FORMULA_TYPE VARCHAR2, ADAY DATE DEFAULT SYSDATE) RETURN NUMBER IS
      AFOR_ID            NUMBER;
      COE                NUMBER; 
      PRIOR_COE          NUMBER;
      ANUMBER_OF_PEOPLES NUMBER;
      AHOURS             NUMBER; 
      ACALC_LECTURERS    CLASSES.CALC_LECTURERS%TYPE; 
      ACALC_GROUPS       CLASSES.CALC_GROUPS%TYPE;
      
      FUNCTION GET_LEC_COEFFICIENT (ALEC_ID NUMBER) RETURN NUMBER IS
        AORGUNI_ID NUMBER;
        COE        NUMBER;
        GUARD      NUMBER := 0; 
        FFFORMULA  VARCHAR2(500);
          FUNCTION GET_ORGUNI_FORMULA ( AORGUNI_ID NUMBER ) RETURN VARCHAR2 IS
            FFID       NUMBER;
            FFFORMULA  VARCHAR2(500);
            PARENT_ORGUNI_ID NUMBER;
          BEGIN           
            BEGIN                    
              -- WYSZUKIWANIE FORMULY 
              LAST_ORGUNI_ID := AORGUNI_ID;
              SELECT ID,FORMULA
                INTO FFID,FFFORMULA
          	    FROM FORM_FORMULAS
        	   WHERE FOR_ID       = AFOR_ID 
        	     AND ORGUNI_ID    = AORGUNI_ID
        	     AND FORMULA_TYPE = AFORM_FORMULA_TYPE
        	     AND ADAY BETWEEN DATE_FROM AND NVL(DATE_TO,ADAY); 
               LAST_FFID := FFID;
               RETURN FFFORMULA;
            EXCEPTION
             WHEN TOO_MANY_ROWS THEN
        	   LAST_ERROR := '(01)Odnaleziono kilka formu� dla podanej formy, jednostki, typu formu�y, daty)';
        	   RETURN 0; 
             WHEN NO_DATA_FOUND THEN
               GUARD := GUARD + 1;
               IF GUARD > 100 THEN
        	     LAST_ERROR := '(02)Przekroczono dopuszczaln� liczb� zagnie�d�e� w strukturze organizacyjnej ( 100 ). Sprawd�, czy struktura organizacyjna nie zawiera cykli';
        	     RETURN NULL;            
               ELSE 
                 SELECT PARENT_ID 
                   INTO PARENT_ORGUNI_ID 
                   FROM ORG_UNITS
                  WHERE ID = AORGUNI_ID; 
                  IF PARENT_ORGUNI_ID IS NULL THEN
        	        LAST_ERROR := '(03)Nie odnaleziono formu�y dla formy prowadzenia zaj��, zadanego dnia oraz jedn.org (oraz jednostek nadrz�dnych)';              
        	        RETURN NULL;                          
                  ELSE
                   RETURN  GET_ORGUNI_FORMULA ( PARENT_ORGUNI_ID );
                  END IF;
               END IF;           
        	 WHEN OTHERS        THEN
        	   LAST_ERROR := '(04)Wyszukiwanie formu�y - b��d: ' || TO_CHAR (SQLCODE) || ' ' || SQLERRM;
        	   RETURN NULL;
            END;       
          END;
      BEGIN  
        BEGIN
          SELECT ORGUNI_ID
            INTO AORGUNI_ID
    	    FROM LECTURERS WHERE ID = ALEC_ID;
        EXCEPTION
    	  WHEN OTHERS        THEN
    	    LAST_ERROR := '(05)Nie powiod�o si� wyznaczenie jednostki organizacyjnej dla wyk�adowcy. B��d: ' || TO_CHAR (SQLCODE) || ' ' || SQLERRM;
    	    RETURN 0;
        END;    
        
        IF AORGUNI_ID IS NULL THEN 
           LAST_ERROR := '(06)Dla wyk�adowcy nie okre�lono jednostki organizacyjnej - nie mo�na wyznaczy� formu�y';
           RETURN 0;
        END IF;    
        
        FFFORMULA := GET_ORGUNI_FORMULA ( AORGUNI_ID );  
        IF FFFORMULA IS NULL THEN --BLAD
         RETURN 0;
        END IF;                  
        
        FFFORMULA := replace (FFFORMULA, 'Zaogr�glij'      , 'Round');
        FFFORMULA := replace (FFFORMULA, 'Liczba_godz'     , TO_CHAR(AHOURS,'99999.0000') );
        FFFORMULA := replace (FFFORMULA, 'Liczba_student�w', TO_CHAR(ANUMBER_OF_PEOPLES,'99999.0000'));
        
        LAST_FORMULA := FFFORMULA;
        
        BEGIN
          RETURN XXMSZ_TOOLS.getSQLValue('SELECT '||FFFORMULA||' FROM DUAL');
        EXCEPTION
          WHEN OTHERS THEN 
            LAST_ERROR := '(07)B��d podczas wyliczania formu�y "' || FFFORMULA || '" B��d: ' || TO_CHAR (SQLCODE) || ' ' || SQLERRM;
            RETURN 0;
        END;          
      END;
      
    BEGIN
      LAST_ERROR     := NULL;
      LAST_FORMULA   := NULL;
      LAST_ORGUNI_ID := NULL;            
      LAST_HORUS     := NULL;
      LAST_NUMBER_OF_PEOPLES := NULL;
      LAST_LEC_ID    := NULL; 
      LAST_FOR_ID    := NULL;                      
      
      SELECT FOR_ID, 2 * FILL / 100, CALC_LECTURERS, CALC_GROUPS
        INTO AFOR_ID, AHOURS, ACALC_LECTURERS, ACALC_GROUPS 
    	FROM CLASSES
    	WHERE ID = AID;
      
      IF ACALC_LECTURERS IS NULL THEN
        LAST_ERROR := '(08)Nie mo�na wyznaczy� wsp�czynnika, poniewa� nie okre�lono wyk�adowcy';
        RETURN 0;
      END IF; 
      
      IF ACALC_GROUPS IS NULL THEN
        LAST_ERROR := '(09)Nie mo�na wyznaczy� wsp�czynnika, poniewa� nie okre�lono grup';
        RETURN 0;
      END IF; 
      
      SELECT NVL( SUM ( NUMBER_OF_PEOPLES ), 0)
        INTO ANUMBER_OF_PEOPLES
        FROM GROUPS                            
        WHERE ID IN ( SELECT GRO_ID FROM GRO_CLA WHERE CLA_ID = AID );     
      
      IF ANUMBER_OF_PEOPLES = 0 THEN
        LAST_ERROR := '(10)Nie mo�na wyznaczy� wsp�czynnika, poniewa� nie okre�lono liczno�ci grup';
        RETURN 0;
      END IF; 

      LAST_FOR_ID            := AFOR_ID;
      LAST_HORUS             := AHOURS; 
      LAST_NUMBER_OF_PEOPLES := ANUMBER_OF_PEOPLES;
        
      -- wyznacz wsp�czynnik dla ka�dego wyk�adowcy	
      COE := 0;
      FOR REC_LEC IN ( SELECT LEC_ID FROM LEC_CLA WHERE CLA_ID = AID ) LOOP 
        PRIOR_COE   := COE;           
        LAST_LEC_ID := REC_LEC.LEC_ID;
        COE := GET_LEC_COEFFICIENT (REC_LEC.LEC_ID); 
    	IF COE = 0 THEN -- BLAD
          EXIT; 
        END IF;
        IF PRIOR_COE <> 0 THEN
          IF PRIOR_COE <> COE THEN
            LAST_ERROR := '(11)Otrzymano r�ne warto�ci wsp�czynnika dla wyk�adowc�w prowadz�cych zaj�cie (' || PRIOR_COE || ', '||  COE || ')';
            RETURN 0;
          END IF;
        END IF;
      END LOOP;
      
      IF LAST_ERROR IS NOT NULL THEN                                                 
        LAST_ERROR := LAST_ERROR || ' wywo�anie: GET_CLASS_COEFFFICIENT ( '||AID||','''||AFORM_FORMULA_TYPE||''',TO_DATE(' || TO_CHAR(ADAY,'YYYY-MM-DD') || ',''YYYY-MM-DD''))';
      END IF; 
      
      RETURN COE;
    END;

    FUNCTION GET_LAST_ERROR RETURN VARCHAR2 IS
    BEGIN
      RETURN LAST_ERROR;
    END; 
    
    FUNCTION GET_CLASS_COEFFFICIENT_TESTER ( AID NUMBER, AFORM_FORMULA_TYPE VARCHAR2, ADAY DATE  DEFAULT SYSDATE) RETURN VARCHAR2 IS
     COE NUMBER;
    BEGIN                                                                                
      COE  := GET_CLASS_COEFFFICIENT ( AID, AFORM_FORMULA_TYPE, ADAY);
      RETURN ' COE='                   || TO_CHAR ( COE ) 
           ||' LAST_ERROR='            || LAST_ERROR
           ||' LAST_ORGUNI_ID='        || LAST_ORGUNI_ID
           ||' LAST_LEC_ID='           || LAST_LEC_ID
           ||' LAST_FOR_ID='           || LAST_FOR_ID
           ||' LAST_FFID='             || LAST_FFID
           ||' LAST_FORMULA='          || LAST_FORMULA
           ||' LAST_HORUS='            || LAST_HORUS
           ||' LAST_NUMBER_OF_PEOPLES='|| LAST_NUMBER_OF_PEOPLES;            
    END;

END;
/


PROMPT AKTUALIZACJA INFORMACJI O WERSJI SCHEMATU BAZY DANYCH

UPDATE SYSTEM_PARAMETERS SET VALUE = '3.3' WHERE NAME = 'PLANOWANIE.VERSION_INFO';

COMMIT;

PROMPT Aktulizacja zako�czy�a si�. Uruchom teraz KONIECZNIE skrypt CREATE_PUBLIC_SYNONYMS.sql

spool off
