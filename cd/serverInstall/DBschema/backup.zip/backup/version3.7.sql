prompt 2010.11.07 Maciej Szymczak
prmpt  utworzenie wsp�lnej tabeli str_elems do przechowywania relacji nadrz�dny-podrz�dny zamiast
prompt trzech oddzielnych tabel lec_str_elems, gro_str_elems, res_str_elems

drop sequence lec_str_elems_seq;
drop sequence gro_str_elems_seq;
drop sequence res_str_elems_seq;

drop public synonym lec_str_elems_seq;
drop public synonym gro_str_elems_seq;
drop public synonym res_str_elems_seq;

create or replace view resources 
as
select id, name from rooms
union 
select id, abbreviation||' '||name from groups
union 
select id, title||' '||last_name||' '||first_name from lecturers;

create public synonym resources for resources;

---

create table str_elems
(
  id                number,
  parent_id         number,
  child_id          number,
  str_name_lov      varchar2(100 byte)          default 'STREAM',
  creation_date     date                        default sysdate               not null,
  created_by        varchar2(30 byte)           default user                  not null,
  last_update_date  date                        default sysdate               not null,
  last_updated_by   varchar2(30 byte)           default user                  not null
)
tablespace users;

create index strelem1 on str_elems (parent_id) tablespace users;
create index strelem2 on str_elems (child_id) tablespace users;
create unique index strelem3 on str_elems (parent_id, child_id, str_name_lov);
create public synonym str_elems for str_elems;

alter table str_elems add ( primary key (id) );

grant select on  str_elems to plannerreports;

create or replace view str_elems_v
(id, parent_id, child_id, str_name_lov, child_dsp, 
 parent_dsp)
as 
select 
  str_elems.id,str_elems.parent_id,str_elems.child_id,str_elems.str_name_lov
  ,(select name from resources where id = child_id) child_dsp 
  ,(select name from resources where id = parent_id) parent_dsp
  from str_elems
/

insert into str_elems
select * from lec_str_elems
union 
select * from gro_str_elems
union 
select * from res_str_elems;

drop view lec_str_elems_v;
drop view gro_str_elems_v;
drop view res_str_elems_v;

drop table lec_str_elems;
drop table gro_str_elems;
drop table res_str_elems;

drop public synonym lec_str_elems;
drop public synonym gro_str_elems;
drop public synonym res_str_elems;

create index groups_i1 on groups ( ATTRIBS_01 );

commit;

UPDATE SYSTEM_PARAMETERS SET VALUE = '3.7' WHERE NAME = 'PLANOWANIE.VERSION_INFO';

COMMIT;


