SPOOL Version322.log

connect planner/planner@planning.world

CREATE OR REPLACE PACKAGE PLANNER_UTILS IS

   /*****************************************************************************************************************************
   |* Planowanie toolkit
   |*****************************************************************************************************************************
   | Maciej Szymczak
   | 2004.11.21 Usuniecie problemu zwiazanego z nie dodawaniem rezerwacji dla sali
   \*-----------------------------------------------------------------------------------------------------------------------------*/


  PROCEDURE insertClasses(ADAY      DATE
                         ,AHOUR     NUMBER
						 ,AFILL     NUMBER
						 ,ASUB_ID   NUMBER
						 ,AFOR_ID   NUMBER
						 ,AOWNER    VARCHAR2
						 ,Lecturers VARCHAR2
						 ,Groups    VARCHAR2
						 ,Resources VARCHAR2
						);
						
  PROCEDURE UPDATE_LGRS;
						
END;
/

CREATE OR REPLACE PACKAGE BODY PLANNER_UTILS IS
 
  PROCEDURE UPDATE_LGR(CLA_ID NUMBER);

  PROCEDURE insertClasses(ADAY      DATE
                         ,AHOUR     NUMBER
						 ,AFILL     NUMBER
						 ,ASUB_ID   NUMBER
						 ,AFOR_ID   NUMBER
						 ,AOWNER    VARCHAR2
						 ,Lecturers VARCHAR2
						 ,Groups    VARCHAR2
						 ,Resources VARCHAR2
						) is
    CLA_SEQ_NEXTVAL NUMBER;
	T               NUMBER;
  BEGIN
    SELECT CLA_SEQ.NEXTVAL
	  INTO CLA_SEQ_NEXTVAL 
	  FROM DUAL;

    INSERT INTO CLASSES (ID,DAY,HOUR,FILL,SUB_ID,FOR_ID,OWNER) VALUES (CLA_SEQ_NEXTVAL,ADAY ,AHOUR ,AFILL ,ASUB_ID ,AFOR_ID ,AOWNER);

	FOR T IN 1 .. XXMSZ_TOOLS.wordCount(Lecturers, '|') LOOP
	  INSERT INTO LEC_CLA (ID, LEC_ID, CLA_ID) VALUES (LECCLA_SEQ.NEXTVAL,xxmsz_tools.extractWord(T,Lecturers,'|'),CLA_SEQ_NEXTVAL);
	END LOOP;
	
	FOR T IN 1 .. XXMSZ_TOOLS.wordCount(Groups, '|') LOOP
	  INSERT INTO GRO_CLA (ID, GRO_ID, CLA_ID) VALUES (GROCLA_SEQ.NEXTVAL,xxmsz_tools.extractWord(T,Groups,'|'),CLA_SEQ_NEXTVAL);
	END LOOP;

	FOR T IN 1 .. XXMSZ_TOOLS.wordCount(Resources, '|') LOOP
	  INSERT INTO ROM_CLA (ID, ROM_ID, CLA_ID) VALUES (ROMCLA_SEQ.NEXTVAL,xxmsz_tools.extractWord(T,Resources,'|'),CLA_SEQ_NEXTVAL);
	END LOOP;
	
    UPDATE_LGR(CLA_SEQ_NEXTVAL);
  END;
    
  PROCEDURE UPDATE_LGRS IS
    CURSOR CUR IS SELECT ID FROM CLASSES;
  BEGIN
    FOR REC IN CUR LOOP
     UPDATE_LGR(REC.ID);
     COMMIT;
    END LOOP;
  END;

  PROCEDURE UPDATE_LGR(CLA_ID NUMBER) IS
  CURSOR CUR_L(ACLA_ID NUMBER) IS
    SELECT abbreviation X, ID
    FROM   LECTURERS
    WHERE  ID IN (SELECT LEC_ID FROM LEC_CLA WHERE CLA_ID = ACLA_ID) ORDER BY X;
  CURSOR CUR_G(ACLA_ID NUMBER) IS
    SELECT abbreviation X, ID
    FROM   GROUPS
    WHERE  ID IN (SELECT GRO_ID FROM GRO_CLA WHERE CLA_ID = ACLA_ID) ORDER BY X;
  CURSOR CUR_R(ACLA_ID NUMBER) IS
    SELECT NAME||' '||BUILDING X, ID
    FROM   ROOMS
    WHERE  ID IN (SELECT ROM_ID FROM ROM_CLA WHERE CLA_ID = ACLA_ID) ORDER BY X;
  L VARCHAR2(500);
  G VARCHAR2(500);
  R VARCHAR2(500);
  L_ID VARCHAR2(500);
  G_ID VARCHAR2(500);
  R_ID VARCHAR2(500);
  BEGIN
    L    := '';
    L_ID := '';
    FOR REC_L IN CUR_L(CLA_ID) LOOP
     L    := xxmsz_tools.MERGE(L   , REC_L.X , '; ');
     L_ID := xxmsz_tools.MERGE(L_ID, REC_L.ID, ';');
    END LOOP;
    G    := '';
    G_ID := '';
    FOR REC_G IN CUR_G(CLA_ID) LOOP
     G    := xxmsz_tools.MERGE(G   , REC_G.X , '; ');
     G_ID := xxmsz_tools.MERGE(G_ID, REC_G.ID, ';');
    END LOOP;
    R    := '';
    R_ID := '';
    FOR REC_R IN CUR_R(CLA_ID) LOOP
     R    := xxmsz_tools.MERGE(R   , REC_R.X , '; ');
     R_ID := xxmsz_tools.MERGE(R_ID, REC_R.ID, ';');
    END LOOP;
    UPDATE CLASSES
    SET    CALC_LECTURERS = L,
           CALC_GROUPS    = G,
           CALC_ROOMS     = R,
           CALC_LEC_IDS   = L_ID,
           CALC_GRO_IDS   = G_ID,
           CALC_ROM_IDS   = R_ID
    WHERE ID = CLA_ID;
  END;

END;
/

show errors;

CREATE OR REPLACE PACKAGE xxmsz_tools AS


    /*-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*
     | Procedury i funkcje narzedziowe
     | Dokumentacja zmian
     |   Maciej Szymczak      01.40 AmountInWords -> zaokraglanie Kwoty do dwoch miejsc po przecinku
     |                        02.08 Dodanie pseudoobiektu do zawijania wierszy tekstowych
     |                              Poprawienie dzia�ania procedury wordWrap ( problem select xxmsz_tools.WordWrap('Ala|ma|kot|ala ma kota',2,0) from dual -> Al|ma|ko|al|a |ma| k|ot|a
     |                                                              problem chr(10))
     |                        02.14 Funkcje formatIBAN, formatNIP
     |                              Poprawienie dzia�ania procedury wordWrap ( problem select xxmsz_tools.WordWrap('A.1.2-21.12.13-10.00-00.01 |PAPIER TERMOCZU�Y', length(' A.1.2-21.12.13-10.00-00.01'),0) from dual)
     |                        02.18 WordWrap - usuniecie problemu powodujacego zawieszanie sie procedury (select xxmsz_tools.WordWrap('SZYMA�CZYK-KRZYNA, JOANNA',13,0) from dual)
     |                        03.02 dodanie funkcji boolToYN
     |                        03.04 dodanie funkcji erasePolishHooks
     |                              optymalizacja procedur Minimum i maksimum
     |                              zmiana w procedurze formatNIP
     |                        03.20 dodanie funkcji strToNumber
     |                        04.11 wymiana funkcji zwracaj�c� kwote slownie w jezyku polskim (
     |                              ( poprzednia funkcja t�umaczy�a niekt�re kwoty niezgodnie z gramatyk� j.polskiego, ponadto obecna funkcja tlumaczy kwoty rzedu trylion�w, poprzednia rzedu milionow)
     |                        04.24 funkcja replaceWord
     |                        04.30 funkcje pushLastWord, popLastWord
     |                              funkcje wstawiania rekord�w do dziennika zdarze�
     |                        06.03 dodanie parametru TokenSeparator VARCHAR2 DEFAULT '|' do procedury wordWrapInit
     |                        06.07 funkcja iif
     |                        06.18 dodanie funkcji fop%
     |                              usuniecie b�edu w procedurze WordCount
     |                        06.23 usuniecie bledu w podInsertText
     |                        07.02 dodanie stalych fopMarkOn, fopMarkOff
     |                              zmiany w procedurach fop
     |                        07.20 poprawienie opisu funkcji fop
     |                        07.22 uzupelnienie opisu funkcji fop
     |                        07.22 usuni�cie b��du w funkcji amountInWords podczas wyznaczania liczby groszy dla kwot > 1000000000 w wer. polskiej
     |                        07.26 drobne poprawki edycyjne
     |                        07.30 funkcje ascToStr i strToAsc
     |                        08.05 zmiany w opisach
     |                        2004.09.01 Zmiana w procedurze pasteStr
     |                        2004.09.29 Tamounts - dodano  kolejne 4 kwoty ( 8 kwot, np. podsumowania w innych walutach)
     |                                   uzupelniono dokumentacje
     |**********************************************************************************************************************
     |  do poprawienia: select xxmsz_tools.wordwrap('alamakota|ala',3,0) from dual oraz
     |               select xxmsz_tools.wordwrap('alamakotaala',3,0) from dual
     |                zawracaj� t� sam� warto�� a nie powinno tak by�
     |
     \select xxmsz_tools.extractWord(3,'ala||ma|kota||trzeci','||') from dual zwraca "|trzeci" w powinien zwrocic "trzeci"
      ------------------------------------------------------------------------------------------------------------------------------------------------*/

  -- ***********************************************************************************************************************
  -- * Operacje na �a�cuchach
  -- ***********************************************************************************************************************

  left   integer := 0;
  right  integer := 1;
  middle integer := 2;

  fopMarkOn  varchar2(50) := '<fo:inline font-size="from-parent(font-size) + 2">';
  fopMarkOff varchar2(50) := '</fo:inline>';

  FUNCTION Center (S VARCHAR2, LEN NUMBER) RETURN VARCHAR2;
  -- otacza tak� sam� liczb� spacji tekst z przodu i z ty�u, dlugosc zwracanego lancucha = len
  FUNCTION trimSpaces ( S VARCHAR2 ) RETURN VARCHAR;
  -- usuwa skrajne spacje oraz usuwa wielokrotne spacje z ci�gu i zastepuje je pojedynczymi
  FUNCTION makeStr(s VARCHAR2, len NUMBER) RETURN VARCHAR2;
  -- zwraca ciag utworzony z wielokrotnego skonkatenowania s o dlugosci len
  FUNCTION extractWord  (poz NUMBER, words VARCHAR, sep VARCHAR := '|') RETURN VARCHAR;
  -- wyodr�bnia poz-ty podci�g z podci�g�w rozdzielonych znakiem Sep z ci�gu Words
  --    np. ExtractFileName(2, 'Ala|Ma|Kota','|') -> Ma
  FUNCTION wordCount(  words VARCHAR2, separator  IN     VARCHAR2 := '|') RETURN NUMBER;
  -- zlicza liczb� podci�g�w rozdzielonych znakiem Separator w ci�gu Words
  FUNCTION replaceWord(poz NUMBER, replaceWith varchar2, words VARCHAR, sep VARCHAR := '|') return varchar2;
  -- zamienia poz-ty podci�g w ci�gu na ci�g replaceWith
  function pushLastWord(pushWord varchar2, words varchar2, sep VARCHAR := '|') return varchar2;
  --k�adzie s�owo na koniec
  function popLastWord(words varchar2, sep VARCHAR := '|') return varchar2;
  --zabiera s�owo z ko�ca
  FUNCTION merge(S1 VARCHAR2, S2 VARCHAR2, SEP VARCHAR2 DEFAULT NULL) RETURN VARCHAR2;
  -- ��czy ci�gi S1 i S2 za pomoc� separatora SEP
  -- u�yteczna podczas sk�adania warunk�w WHERE warunek1 AND warunek2 AND ... oraz podczas dodawania �a�cuchow (NULL || 'any' = NULL ...)
  --    np. Merge('A','B',',', -> 'A,B')
  --        Merge('A','' ,',', -> 'A')
  --       Merge('','B' ,',', -> 'B')
  FUNCTION wordWrap( wrappedString VARCHAR2, columnWidth NUMBER, getTokenNr NUMBER DEFAULT 0, completeWithSpaces BOOLEAN DEFAULT TRUE, TokenSeparator VARCHAR2 DEFAULT '|') RETURN VARCHAR2;
  -- dzieli ci�g S na fragmenty o d�ugosci columnWidth i zwraca token o numerze getTokenNr ( 0 oznacza, ze zostana zwrocone wszystkie tokeny, rozdzielone znakami |)
  -- jezeli w ciagu wejsciowym sa znaki |, to zostana one potraktowane jako znaki konca wiersza
  FUNCTION pasteStr( Str VARCHAR2, pastedStr VARCHAR2, fromPos NUMBER, toPos NUMBER, align NUMBER ) RETURN VARCHAR2;
  -- wkleja pastedStr do Str od pozycji fromPos do pozycji toPos align = 1-od prawej 0-od lewej
  FUNCTION erasePolishHooks(S VARCHAR2) RETURN VARCHAR2;
  -- zastepuje polskie znaki ich odpowiednikami bez ogonkow np. ��ko -> lozko
  FUNCTION withoutPolishSigns (S IN VARCHAR2) RETURN VARCHAR2;
  -- odpowiednik poprzedniej funkcji
  PROCEDURE addPercent ( V IN OUT VARCHAR2 );
  -- dodaje % na koncu stringa, chyba, ze juz jest % w stringu
  FUNCTION isSubsetOf (Set1 VARCHAR2, Set2 VARCHAR2) RETURN VARCHAR2;
  -- zwraca TRUE jesli SET1 jest podzbiorem SET2. Elementy sa rozdzdzielone znakiem ;
  --   select substr(xxmsz_tools.issubsetof('third;first','first;second;third'),1,3) from dual -> Y
  --   select substr(xxmsz_tools.issubsetof('fourth;first','first;second;third'),1,3) from dual -> N

  FUNCTION tolatin2 (tekst IN VARCHAR2) RETURN VARCHAR2;
  -- konwertuje ciag na standard Latin2
  FUNCTION hasPolishSigns(S IN OUT VARCHAR2) RETURN VARCHAR2;
  -- sprawdza, czy string zawiera polskie znaki -> N,Y
  function strToNumber ( str varchar2 ) return number;
  -- konwertuje ci�g do liczby. Cz�ci ca�kowita i u�amkowa mog� by� rozdzielone przecinkiem lub kropk�, separator tysi�cy nie mo�e wyst�powa�

  -- *********************************************************************************
  -- * Biznesowe operacje na ci�gach
  -- *********************************************************************************
  FUNCTION amountInWords(aamount NUMBER, language_code VARCHAR2 DEFAULT 'PL', currency_code1 VARCHAR2 DEFAULT 'z�', acurrency_code2 VARCHAR2 DEFAULT 'gr') RETURN VARCHAR2;
  -- zwraca kwote slownie w jezyku okreslonym przez paramert language_code (PL/END)
  FUNCTION strToDate( p_dat VARCHAR2) RETURN DATE;
  -- konwertuje string na date, dopasowujac odpowiednia maske formatu
  FUNCTION peselIsOK ( PESEL  VARCHAR2 ) RETURN  VARCHAR2;
  -- sprawdza PESEL i zwraca Y/N
  FUNCTION nipIsOk ( NIP  VARCHAR2 ) RETURN  VARCHAR2;
  -- sprawdza NIP i zwraca Y/N
  FUNCTION regonIsOk ( REGON  VARCHAR2 ) RETURN  VARCHAR2;
  -- sprawdza REGON (9- lub 14-znakowy )i zwraca Y/N
  FUNCTION ynToBool ( S VARCHAR2, resultIfEmpty BOOLEAN DEFAULT FALSE ) RETURN BOOLEAN;
  -- konwertuje wartosc Str na bool
  FUNCTION boolToYN ( bool boolean, trueValue varchar2 default 'Y', falseValue varchar2 default 'N' ) RETURN varchar2;
  -- konwertuje wartosc bool na Str
  FUNCTION formatIBAN ( inS VARCHAR2, numberOfSignsInSection number default 4, formatOnlyWhenDivisible varchar2 default 'N' ) RETURN VARCHAR2;
  -- formatuje rachunek bankowy do postaci iban ( 9999 9999 9999 99 )
  FUNCTION formatNIP  ( inS VARCHAR2 ) RETURN VARCHAR2;
  -- formatuje ci�g do postaci 999-999-99-99 je�li nie zawiera my�lnik�w w przyciwnym wypadku zwracany jest ci�g oryginalny
  --  select xxmsz_tools.formatNIP('9441733423') from dual --> 944-173-34-23
  --  select xxmsz_tools.formatNIP('944-17-33-423') from dual --> 944-17-33-423
  --  select xxmsz_tools.formatNIP('9-4-4-1-7-3-3-4-2-3') from dual --> 9-4-4-1-7-3-3-4-2-3

  -- *********************************************************************************
  -- * Dziennik zdarzen
  -- *********************************************************************************

  /*
  Aby korzystac z funkcji dziennia zdarzen, nalezy utworzyc nastepujace: tabele i sekwencje.
  Dziennik zdarzen jest wspolny dla wielu aplikacji - uzyj kwalifikatora hierarchicznego dla rozr�nienia, kt�re komunikaty dotycz� kt�rej aplikacji - zob. pole moduleName

   create sequence xxmsztools_eventlog_seq;

   create table xxmsztools_eventlog (
     id number(11)
	,module_name   varchar2(200)
	,message       varchar2(200)
	,message_type  varchar2(10)
	,created       date default sysdate
   );

  */

  procedure setModuleName ( moduleName varchar2 );
  -- ustawia nazwe modu�u ( zob. opis parametru moduleName w procedurze insertIntoEventLog )
  procedure pushModuleName ( moduleName varchar2 );
  -- dodaje nowy cz�on do nazwy modu�u - zwykle wywo�ywane na pocz�tku procedury
  procedure popModuleName;
  -- usuwa cz�on z nazwy modu�u - zwykle wywo�ywane przed wyjsciem z procedury
  procedure insertIntoEventLog ( message varchar2, messageType varchar2 default null, moduleName varchar2 default null, writeMessage varchar2 default 'Yes', raiseExceptions varchar2 default 'No');
  -- dodaje wiersz do tabeli xxmsztools_eventlog
  -- message         komunikat do zapisania
  -- messageType     typ komunikatu : I=Info E=Error W=Warning
  -- moduleName      hierarchiczne okrelsenie miejsce wywo�ania. Cz�ony rozdzielone kropk� np Package001.WYDRUK_FAKTURY.FETCH_INVOICES.FETCH_INVOICE
  -- writeMessage    flaga okreslajaca, czy dodac rekord ( moze np. byc sterowana zmienna okreslajaca, czy prowadzic sledzenie )
  -- raiseExceptions wywolaj wyjatek w razie bledu

  -- *********************************************************************************
  -- * Inne operacje
  -- *********************************************************************************
  function strToAsc ( strString varchar2 ) return varchar2;
  -- konwertuje ci�g znak�w do ci�gu znak�w ascii
  -- np. select strToAsc('przyk�adowy tekst') from dual ->  112,114,122,121,107,179,97,100,111,119,121,32,116,101,107,115,116
  function AscToStr ( ascString varchar2 ) return varchar2;
  -- konwertuje ci�g znak�w ascii do ci�gu znak�w
  -- np. select asctostr('112,114,122,121,107,179,97,100,111,119,121,32,116,101,107,115,116') from dual -> przyk�adowy tekst
  FUNCTION extractFileName(S  IN VARCHAR2)  RETURN VARCHAR2;
  -- wyodr�bnia ze �cie�ki nazw� pliku
  --     np. ExtractFileName('c:\Program Files\Joasia.xls') -> Joasia.xls
  FUNCTION extractPath (S  IN VARCHAR2)  RETURN VARCHAR2;
  -- wyodr�bnia ze �cie�ki �cie�k� bez nazwy pliku
  --     np. ExtractFileName('c:\Program Files\Joasia.xls') -> c:\Program Files\
  FUNCTION getBanknotes( wydaj VARCHAR2 ) RETURN VARCHAR2;
  -- zwraca kwote w banknotach i bilonach
  function iif( cond boolean, str1 varchar2, str2 varchar2 ) return varchar2;
  -- zwraca str1 jesli cond, w przeciwnyym przypadku zwraca str2
  -- funkcja uzyteczna przy formatowaniu warunkowym
  PROCEDURE dbms_outputPut_line (
      str         IN   VARCHAR2,
      len         IN   INTEGER := 254,
      expand_in   IN   BOOLEAN := TRUE
   );
   -- wykonuje dbms_output.put_line dzielac ciag znakow na podlancuchy o dlugosci len
   -- w razie potrzeby rozszerza bufor za pomoca polecenia dbms_output.enable
  -- *********************************************************************************
  -- * funkcje bazodanowe
  -- *********************************************************************************
  valueifempty VARCHAR2(100) := 'NULL';

  FUNCTION getSQLValues(SQLText VARCHAR2, exceptifempty CHAR DEFAULT 'Y', Sep VARCHAR2 DEFAULT '|', maxsizeofres NUMBER DEFAULT 30000) RETURN VARCHAR2;
  -- zwraca wynik zapytania z pierwszej kolumny rozdzielony znakami Sep (dla wygody stosuj znak ^ zamiast ')
  --     np. KON.XXMSZ_TOOLS.GetSQLValues ( 'select column_name from sys.all_tab_columns where table_name = ^ALL_OBJECTS^ and owner = ^SYS^ order by column_name' ) -> OWNER|OBJECT_NAME| itd.
  FUNCTION getSQLValue(SQLText VARCHAR2, exceptifempty CHAR DEFAULT 'Y') RETURN VARCHAR2;
  -- zwraca wartosc zapytania z pierszego wiersza z pierwszej kolumny

  -- ponizej funkcje przekszta�ace dane do postaci akceptowanej przez polecenia DML
  FUNCTION formatDate(Word VARCHAR2) RETURN VARCHAR2;
  FUNCTION formatDateTime(Word VARCHAR2) RETURN VARCHAR2;
  FUNCTION formatFloat(Word VARCHAR2) RETURN VARCHAR2;
  FUNCTION formatString(Word VARCHAR2) RETURN VARCHAR2;

  -- Implemantacja stosu - w trakcie opracowywania
  TYPE tStrStack IS RECORD (
   Elements      VARCHAR2(100),
   COUNT         NUMBER
  );

   /*****************************************************************************************************************************
   |* Zawijanie wierszy tekstowych
   |*****************************************************************************************************************************
   |  set serveroutput on;
   |  declare
   |    WordWrap xxmsz_tools.tWordWrap;
   |    procedure insertLines ( WordWrap in out xxmsz_tools.tWordWrap ) is
   |      i number;
   |    begin
   |      if WordWrap.errorMessage is not null then xxmsz_tools.dbms_outputPut_line (WordWrap.errorMessage); end if;
   |      for i in 1..xxmsz_tools.wordWrapGetNumberOfLines(WordWrap) loop
   |        xxmsz_tools.dbms_outputPut_line ( xxmsz_tools.wordWrapGetLine(WordWrap,i) );
   |      end loop;
   |    end;
   |  begin
   |    xxmsz_tools.wordWrapInit (WordWrap,'|aaaaaaaaaaaaa|bbbbbbbbbbbbb|ccccccccccccc|');
   |    xxmsz_tools.wordWrapPrepareColumn(WordWrap, 'Przyk�adowy tekst Przyk�adowy tekst Przyk�adowy tekst', 'aaaaaaaaaaaaa', xxmsz_tools.left);
   |    xxmsz_tools.wordWrapPrepareColumn(WordWrap, 'Przyk�adowy tekst Przyk�adowy tekst Przyk�adowy tekst', 'bbbbbbbbbbbbb', xxmsz_tools.right);
   |    xxmsz_tools.wordWrapPrepareColumn(WordWrap, 'Przyk�adowy tekst Przyk�adowy tekst Przyk�adowy tekst', 'ccccccccccccc', xxmsz_tools.middle);
   |    insertLines ( WordWrap );
   |  end;
   |  /
   |
   \*-----------------------------------------------------------------------------------------------------------------------------*/

  TYPE tWordWraplinesPastedStr IS  TABLE  OF VARCHAR2(5000) INDEX  BY  BINARY_INTEGER;
  TYPE tWordWraplinesFromPos   IS  TABLE  OF NUMBER         INDEX  BY  BINARY_INTEGER;
  TYPE tWordWraplinesToPos     IS  TABLE  OF NUMBER         INDEX  BY  BINARY_INTEGER;
  TYPE tWordWraplinesAlign     IS  TABLE  OF NUMBER         INDEX  BY  BINARY_INTEGER;
  -- zamiast kilku tabel PL/SQL powinna byc jedna z typem rekordowym, ale sk�adnia jezyka na to nie pozwala ( PLS-00511: rekord nie mo�e zawiera� tabeli PL/SQL rekord�w )
  -- PL/SQL nie pozwala predefiniowac typu LongStr = VARCHAR2(5000), szkoda
  type tWordWrap is record (
          defaultStr varchar2(2000)
         ,linesPastedStr tWordWraplinesPastedStr
         ,linesFromPos tWordWraplinesFromPos
         ,linesToPos tWordWraplinesToPos
         ,linesAlign tWordWraplinesAlign
         ,resultLineNum number default -1-- numer zwracanej linii
		 ,errorMessage varchar2(1000) default null
		 ,tokenSeparator VARCHAR2(1) DEFAULT '|' --znak przejscia do nastepnej linii
       );

  procedure wordWrapInit (aWordWrap in out tWordWrap,adefaultStr varchar2, TokenSeparator VARCHAR2 DEFAULT '|'); -- defaultStr musi zawiera� placeholdery
                                                                            -- moze on tak�e zawiera� inne elementy jak ramki, znaki formatuj�ce html itp.
  procedure wordWrapPrepareColumn(aWordWrap in out tWordWrap, pastedStr VARCHAR2, placeHolder varchar2, align NUMBER );
  function  wordWrapGetNumberOfLines(aWordWrap in out tWordWrap) return number; -- zwraca liczbe linii
  function  wordWrapGetLine(aWordWrap tWordWrap,lineNum number) return varchar2; -- zwraca linie o podanym numerze

  -- ***********************************************************************************
  -- * Zastosowanie procedur przedstawionych ponizej:
  -- *  - Zliczanie kwot wg r�nych stawek podatku vat, walut itd. (zob. wydruk fakury)
  -- *  - Wyznaczanie poczatkowego i koncowego numeru strony ( zob. pakiet wzorcowy plsqlrep)
  -- *
  -- *  przykladowy skrypt:
  -- *  declare
  -- *        SumTotal               xxmsz_tools.TAmounts;
  -- *  begin
  -- *    xxmsz_tools.AmountsInit ( SumTotal          , xxmsz_tools.giAdd );
  -- * 	  xxmsz_tools.AmountsAdd  ( SumTotal          ,  '7%', 10, 20, 30);
  -- * 	  xxmsz_tools.AmountsAdd  ( SumTotal          ,  '7%', 10, 20, 30);
  -- * 	  xxmsz_tools.AmountsAdd  ( SumTotal          ,  '7%', 10, 20, 30);
  -- * 	  xxmsz_tools.AmountsAdd  ( SumTotal          , '22%', 10, 20, 30);
  -- * 	  xxmsz_tools.AmountsAdd  ( SumTotal          , '22%', 10, 20, 30);
  -- *    amountsGetExample2      ( SumTotal );
  -- *  end;
  -- *
  -- *  wynik dzialania przykladowego skryptu:
  -- *
  -- *  7%    30  60  90
  -- *  22%   20  40  60
  -- *  ================
  -- *  TOTAL 50 100 150
  -- ***********************************************************************************

  -- poniewaz w PLSQL nie mozna programowac obiektowo, udostepniane sa ponizsze typy i procedury uzywajace tych typow
   giAdd INTEGER := 0; -- gi = group function information
   giMax INTEGER := 1;
   giMin INTEGER := 2;

   TYPE tTAmounts         IS  TABLE  OF  NUMBER        INDEX  BY  BINARY_INTEGER;
   TYPE tTGroupIndicators IS  TABLE  OF  VARCHAR2(100) INDEX  BY  BINARY_INTEGER;
   TYPE tAmounts IS RECORD (
       amounts1        TTAmounts,         -- kolumna 1 do zsumowania np. wartosc netto
       amounts2        TTAmounts,         -- kolumna 2 do zsumowania np. kwota vat
       amounts3        TTAmounts,         -- kolumna 3 do zsumowania np. wartosc brutto
       amounts4        TTAmounts,         -- kolumna 4 do zsumowania np. wartosc brutto bez rabatu
       amounts5        TTAmounts,         -- kolumna 5 do zsumowania np. wartosc netto w przeliczeniu na EUR
       amounts6        TTAmounts,         -- kolumna 6 do zsumowania np. wartosc vat w przeliczeniu na EUR
       amounts7        TTAmounts,         -- kolumna 7 do zsumowania
       amounts8        TTAmounts,         -- kolumna 8 do zsumowania
	   groupIndicators TTGroupIndicators, -- wskaznik grupowania, np. stawka vat albo waluta
       count  INTEGER,
	   groupOperator INTEGER -- giAdd   (defualt) : AmountsAdd dodaje wartosci
	                         -- giMax             : AmountsAdd oznacza max
							 -- giMin             : jw min
     );
   PROCEDURE amountsInit (Amounts IN OUT tAmounts, agroupOperator INTEGER DEFAULT 0);
   PROCEDURE amountsAdd(Amounts IN OUT tAmounts, aGroupIndicator VARCHAR2, amount1 NUMBER, amount2 NUMBER DEFAULT 0, amount3 NUMBER DEFAULT 0, amount4 NUMBER DEFAULT 0, amount5 NUMBER DEFAULT 0, amount6 NUMBER DEFAULT 0, amount7 NUMBER DEFAULT 0, amount8 NUMBER DEFAULT 0);
   -- W PLSQL nie ma typu proceduralnego... skopiuj zatem AmountsGet z dostosuj do wlasnych potrzeb
   PROCEDURE amountsGetExample1(Amounts IN OUT tAmounts);
   -- wyswietla kwoty dla poszczegolnych wskaznikow grupowania, w tym total
   PROCEDURE amountsGetExample2(Amounts IN OUT tAmounts);
   -- wyswietla kwoty dla poszczegolnych wskaznikow grupowania oraz - o ile liczba wskaznikow grupowania >1 , rowniez total
   FUNCTION amountsGetByIndicator(amounts IN OUT tAmounts, aGroupIndicator VARCHAR2, amountIndex NUMBER) RETURN NUMBER;

  function maximum(
     number1  number
   , number2  number
   , number3  number default null
   , number4  number default null
   , number5  number default null
   , number6  number default null
   , number7  number default null
   , number8  number default null
   , number9  number default null
   , number10 number default null
   , number11 number default null
   , number12 number default null
   , number13 number default null
   , number14 number default null
   , number15 number default null
   , number16 number default null
   , number17 number default null
   , number18 number default null
   , number19 number default null
   , number20 number default null
   , number21 number default null
   , number22 number default null
   , number23 number default null
   , number24 number default null
   , number25 number default null
   , number26 number default null
   , number27 number default null
   , number28 number default null
   , number29 number default null
   , number30 number default null
  ) return number;

  function minimum(
     number1  number
   , number2  number
   , number3  number default  null
   , number4  number default  null
   , number5  number default  null
   , number6  number default  null
   , number7  number default  null
   , number8  number default  null
   , number9  number default  null
   , number10 number default  null
   , number11 number default  null
   , number12 number default  null
   , number13 number default  null
   , number14 number default  null
   , number15 number default  null
   , number16 number default  null
   , number17 number default  null
   , number18 number default  null
   , number19 number default  null
   , number20 number default  null
   , number21 number default  null
   , number22 number default  null
   , number23 number default  null
   , number24 number default  null
   , number25 number default  null
   , number26 number default  null
   , number27 number default  null
   , number28 number default  null
   , number29 number default  null
   , number30 number default  null
  ) return number;

  -- ***************************************************************************************
  -- * funkcje u�atwiaj�ce tworzenie typowego pliku dla fop
  -- *        Ten zestaw procedur powstal w celu zapewnienia szybkiego utworzenia dokumentu pdf zawierajacego
  -- *        podstawowe elementy graficzne, jak logo, tekst o roznej wielkosci czcionki, tabela, naglowek, stopke.
  -- *        Uzycie tych procedur nie wymaga znajomosci formatu fop.
  -- *        FOP posiada o wiele wieksze mozliwosci w zakresie generowania dokumentow pdf, jak np.
  -- *        wielowierszowe naglowki tabel, wielopoziomowe zagniezdzanie obiektow.
  -- *        Aby zapoznac sie z wszystkimi mozliwosciami fop, zapoznaj sie z dokumentacja i przykladowymi plikami *.fo
  -- *        dostepnymi w podstawowym pakiecie.
  -- * Uwagi ogolne:
  -- *       1. wygenerowany plik *.fo odwo�uje sie do czcionki courier-new, ktorej standardowo nie ma w katalogu fop
  -- *          pobierz katalog fop z ..\PPL\tasks\ra\NAL-W-006.Wydruk_faktury\Wersja_instalacyjna\wydruk_graficzny_instalka\fop
  -- *       2. nie zapomnij u�ywa� jednostek miar podczas podawania wartosci atrybutow, np. 1pt, 1cm, 20%, w innym przypadku fop zignoruje atrybut
  -- *       3. jezeli chcesz wymusic przejscie do nowego wiersza, uzywaj znaku chr(10) np. xxmsz_tools.fopInsertStndTableHeader('linia 1'||chr(10)||'linia 2'||chr(10)||'linia 3|druga|trzecia');
  -- *          powyzsze dotyczy rowniez systemu Windows ( wystarczy #10 zamiast #13#10 )
  -- *       4. aby przekszta�ci� otrzymany za pomoc� tych funkcji plik .fo do postaci .pdf u�yj polecenia
  -- *          fop.sh  -c $FOP/conf/userconfig.xml -fo $DB_OUT/$fo_file -pdf $FOP/$pdf_file (UNIX)
  -- *          fop.bat -c c:\userconfig.xml -fo c:\fo_file -pdf c:\pdf_file.pdf             (WINDOWS)
  -- ***************************************************************************************

 /*  przyk�adowy skrypt generujacy plik fop

    begin
      delete from xxmsztools_eventlog;
      commit;
      --xxmsz_tools.fopOpen('','','Y', 'xxmsztools_eventlog','^'); -- pisz do tabeli xxmsztools_eventlog lub
      xxmsz_tools.fopOpen('c:\fop-0.20.5','test.fo','Y','file','^'); -- pisz do pliku
	  -- pamietaj, zeby w pliku init.ora dodac parametr utl_file_dir  = c:\bufor,fop-0.20.5
        xxmsz_tools.fopOpenStndDocument('1','Strona','pierwszy dokument');
          xxmsz_tools.fopInsertText('Hello World !','center','-2pt');
          xxmsz_tools.fopInsertText('Hello World !','center','-1pt');
          xxmsz_tools.fopInsertText('Hello World !','center');
          xxmsz_tools.fopInsertText('Hello World !','center','1pt');
          xxmsz_tools.fopInsertText('Hello World !','center','20pt');
        xxmsz_tools.fopCloseDocument;
        xxmsz_tools.fopOpenStndDocument('2','Strona','drugi dokument');
          xxmsz_tools.fopInsertText( xxmsz_tools.fopMarkOn || 'Marked text' || xxmsz_tools.fopMarkOff || ' normal text');
          xxmsz_tools.fopInsertPicture ('graph/sygnatura.gif','50%');
          xxmsz_tools.fopOpenStndTable('5cm^5cm^5cm', 'solid');
            xxmsz_tools.fopInsertStndTableHeader('pierwsza^druga^trzecia');
            xxmsz_tools.fopInsertStndTableBody('pierwsza#left#AAAAAA^druga#right#BBBBBB^trzecia#center');
            -- label#text-align#background-color#border-style#addCellAttrs
    	    -- fragment dla zaawansowanych - sklejanie kolumn w wierszu i tabela zagnie�d�ona {
    	    xxmsz_tools.fopInsertRawText('<fo:table-row >');
    	    xxmsz_tools.fopInsertRawText('<fo:table-cell border-width="0.5pt" border-color="black" border-style="solid" background-color="#AAAAAA">');
    	    xxmsz_tools.fopInsertRawText('<fo:block text-align="left" vertical-align="middle">pierwsza</fo:block>');
    	    xxmsz_tools.fopInsertRawText('</fo:table-cell>');
    	    xxmsz_tools.fopInsertRawText('<fo:table-cell number-columns-spanned="2" border-width="0.5pt" border-color="black" border-style="solid" background-color="#AAAAAA">');
    	    xxmsz_tools.fopInsertText;
            xxmsz_tools.fopOpenStndTable('2cm^2cm^2cm', 'solid');
              xxmsz_tools.fopInsertStndTableHeader('pierwsza^druga^trzecia');
              xxmsz_tools.fopInsertStndTableBody('pierwsza#left#AAAAAA^druga#right#BBBBBB^trzecia#center');
            xxmsz_tools.fopCloseStndTable;
    	    xxmsz_tools.fopInsertText('');
    	    xxmsz_tools.fopInsertRawText('</fo:table-cell>');
    	    xxmsz_tools.fopInsertRawText('</fo:table-row>');
    	    -- }
          xxmsz_tools.fopCloseStndTable;
        xxmsz_tools.fopCloseDocument;
      xxmsz_tools.fopClose;
    end;

    select message from xxmsztools_eventlog order by id


	wynik dzialania skryptu

     <?xml version="1.0" encoding="ISO-8859-2"?>
     <fo:root xmlns:fo="http://www.w3.org/1999/XSL/Format">
        <fo:layout-master-set>
           <fo:simple-page-master master-name="first" margin-right="1cm" margin-left="1cm" margin-bottom="0cm" margin-top="0cm" page-width="21cm" page-height="29.7cm">
              <fo:region-body margin-top="1cm" margin-bottom="2cm"/>
              <fo:region-before extent="0cm"/>
              <fo:region-after extent="2cm"/>
           </fo:simple-page-master>
        </fo:layout-master-set>
        <fo:page-sequence font-family="courier-new" font-size="6pt" font-weight="normal" master-reference="first" initial-page-number="1" force-page-count="no-force">
           <fo:static-content flow-name="xsl-region-before">
              <fo:block/>
           </fo:static-content>
           <fo:static-content flow-name="xsl-region-after">
              <fo:block flow-name="xsl-region-body" text-align="start" line-height="1em + 2pt">
                 <fo:leader leader-pattern="rule" rule-thickness="1.0pt" leader-length="19cm"/>
                  Strona
                 <fo:page-number/>/
                 <fo:page-number-citation ref-id="1"/>
                 pierwszy dokument
              </fo:block>
           </fo:static-content>
           <fo:flow flow-name="xsl-region-body" white-space-treatment="preserve" white-space-collapse="false">
              <fo:block font-size="from-parent(font-size) + -2pt" text-align="center">Hello World !</fo:block>
              <fo:block font-size="from-parent(font-size) + -1pt" text-align="center">Hello World !</fo:block>
              <fo:block text-align="center">Hello World !</fo:block>
              <fo:block font-size="from-parent(font-size) + 1pt" text-align="center">Hello World !</fo:block>
              <fo:block font-size="from-parent(font-size) + 20pt" text-align="center">Hello World !</fo:block>
              <fo:block id="1"/>
           </fo:flow>
        </fo:page-sequence>
        <fo:page-sequence font-family="courier-new" font-size="6pt" font-weight="normal" master-reference="first" initial-page-number="1" force-page-count="no-force">
           <fo:static-content flow-name="xsl-region-before">
              <fo:block/>
           </fo:static-content>
           <fo:static-content flow-name="xsl-region-after">
              <fo:block flow-name="xsl-region-body" text-align="start" line-height="1em + 2pt">
                 <fo:leader leader-pattern="rule" rule-thickness="1.0pt" leader-length="19cm"/>
                  Strona
                 <fo:page-number/>/
                 <fo:page-number-citation ref-id="2"/>
                 drugi dokument
              </fo:block>
           </fo:static-content>
           <fo:flow flow-name="xsl-region-body" white-space-treatment="preserve" white-space-collapse="false">
              <fo:block>
                 <fo:inline font-size="from-parent(font-size) + 2">Marked text</fo:inline>
                  normal text
              </fo:block>
              <fo:external-graphic src="url(graph/sygnatura.gif)" width="50%"/>
              <fo:table table-layout="fixed" text-align="left" vertical-align="top">
                 <fo:table-column column-width="5cm"/>
                 <fo:table-column column-width="5cm"/>
                 <fo:table-column column-width="5cm"/>
                 <fo:table-header>
                    <fo:table-row>
                       <fo:table-cell background-color="#BBBBBB" border-width="0.5pt" border-color="black" border-style="solid">
                          <fo:block text-align="center" vertical-align="middle">pierwsza</fo:block>
                       </fo:table-cell>
                       <fo:table-cell background-color="#BBBBBB" border-width="0.5pt" border-color="black" border-style="solid">
                          <fo:block text-align="center" vertical-align="middle">druga</fo:block>
                       </fo:table-cell>
                       <fo:table-cell background-color="#BBBBBB" border-width="0.5pt" border-color="black" border-style="solid">
                          <fo:block text-align="center" vertical-align="middle">trzecia</fo:block>
                       </fo:table-cell>
                    </fo:table-row>
                 </fo:table-header>
                 <fo:table-body>
                    <fo:table-row>
                       <fo:table-cell border-width="0.5pt" border-color="black" border-style="solid" background-color="#AAAAAA">
                          <fo:block text-align="left" vertical-align="middle">pierwsza</fo:block>
                       </fo:table-cell>
                       <fo:table-cell border-width="0.5pt" border-color="black" border-style="solid" background-color="#BBBBBB">
                          <fo:block text-align="right" vertical-align="middle">druga</fo:block>
                       </fo:table-cell>
                       <fo:table-cell border-width="0.5pt" border-color="black" border-style="solid">
                          <fo:block text-align="center" vertical-align="middle">trzecia</fo:block>
                       </fo:table-cell>
                    </fo:table-row>
                    <fo:table-row>
                       <fo:table-cell border-width="0.5pt" border-color="black" border-style="solid" background-color="#AAAAAA">
                          <fo:block text-align="left" vertical-align="middle">pierwsza</fo:block>
                       </fo:table-cell>
                       <fo:table-cell number-columns-spanned="2" border-width="0.5pt" border-color="black" border-style="solid" background-color="#AAAAAA">
                          <fo:block space-after="from-parent(font-size) + 0pt"/>
                          <fo:table table-layout="fixed" text-align="left" vertical-align="top">
                             <fo:table-column column-width="2cm"/>
                             <fo:table-column column-width="2cm"/>
                             <fo:table-column column-width="2cm"/>
                             <fo:table-header>
                                <fo:table-row>
                                   <fo:table-cell background-color="#BBBBBB" border-width="0.5pt" border-color="black" border-style="solid">
                                      <fo:block text-align="center" vertical-align="middle">pierwsza</fo:block>
                                   </fo:table-cell>
                                   <fo:table-cell background-color="#BBBBBB" border-width="0.5pt" border-color="black" border-style="solid">
                                      <fo:block text-align="center" vertical-align="middle">druga</fo:block>
                                   </fo:table-cell>
                                   <fo:table-cell background-color="#BBBBBB" border-width="0.5pt" border-color="black" border-style="solid">
                                      <fo:block text-align="center" vertical-align="middle">trzecia</fo:block>
                                   </fo:table-cell>
                                </fo:table-row>
                             </fo:table-header>
                             <fo:table-body>
                                <fo:table-row>
                                   <fo:table-cell border-width="0.5pt" border-color="black" border-style="solid" background-color="#AAAAAA">
                                      <fo:block text-align="left" vertical-align="middle">pierwsza</fo:block>
                                   </fo:table-cell>
                                   <fo:table-cell border-width="0.5pt" border-color="black" border-style="solid" background-color="#BBBBBB">
                                      <fo:block text-align="right" vertical-align="middle">druga</fo:block>
                                   </fo:table-cell>
                                   <fo:table-cell border-width="0.5pt" border-color="black" border-style="solid">
                                      <fo:block text-align="center" vertical-align="middle">trzecia</fo:block>
                                   </fo:table-cell>
                                </fo:table-row>
                             </fo:table-body>
                          </fo:table>
                          <fo:block space-after="from-parent(font-size) + 0pt"/>
                       </fo:table-cell>
                    </fo:table-row>
                 </fo:table-body>
              </fo:table>
              <fo:block id="2"/>
           </fo:flow>
        </fo:page-sequence>
     </fo:root>

   */


  procedure fopOpen(dir varchar2, fileName varchar2, addStndLayoutMasterSet char default 'Y', outputType varchar2 default 'file', charsDelimiter char default chr(9));
  -- otwiera plik fop
  -- dir, filename - katalog i nazwa pliku np. dir := '/dbout/PPL4',   fileName := 'o'||p_file||'.xml';
  -- OutputType = file, xxmsztools_eventlog
  -- charsDelimiter - znak rozdzielajacy kolumny - zob. funkcje fop wstawiajace tabele

  -- uwagi:
  -- do pliku init<nazwa instancji>.ora nale�y doda� parametr np. utl_file_dir  = C:\fop-0.20.5
  --                                                              utl_file_dir  = /dbout/PPL4
  -- jezeli chcesz miec dostep do kilku katalogow, to rozdziel katalogi przecinkami np. utl_file_dir=/dbout/PPL4,/u05/apps1159/ppl4/ppl4db/9.2.0/appsutil/outbound/PPL4_oratest
  -- OutputType = xxmsztools_eventlog zostalo opracowane dla celow awaryjno-diagnostycznych (np. jesli chcesz pracowac, a nie masz mozliwosci dopisania do pliku init.ora parametru utl_file_dir)
  -- jesli wyrano OutputType = xxmsztools_eventlog, to pamietaj, ze
  --  1. tabela xxmsztools_eventlog powinna byc utworzona (zob. opis w tym pakiecie)
  --  2. wowczas wartosci parametro dir i filename sa bez znaczenia

  procedure fopClose;
  -- zamyka plik fop
  procedure fopInsertRawText (text varchar2);
  -- dodaje dowolne polecenie dla fop
  procedure fopInsertStndLayoutMasterSet;
  -- wstawia standardowy opis strony ( marginesy itd. )
  procedure fopOpenStndDocument (documentId varchar2, pageText varchar2 default 'Strona : ', footerText varchar2 default null, addPageAttrs varchar2 default 'font-family="courier-new" font-size="7pt" font-weight="normal" master-reference="first" initial-page-number="1" force-page-count="no-force"' );
  -- wstawia dokument ( w jednym pliku fop moze byc zdefiniowanych wiele dokumentow, np. faktura, kopia faktury, zalacznik do faktury)
  -- w standardowym dokumencie zaimplementowano:
  -- stopka z numeracja stron x / y - w jednym pliku moze byc wiele dokumentow numerowanych niezaleznie
  -- nie sa odcinane spacje
  -- force-page-count="no-force"
  procedure fopCloseDocument;
  -- zamyka dokument
  procedure fopInsertText (t varchar2 default null, textAlign varchar2 default null, fontSizeChange varchar2 default '0pt', AddAttrs varchar2 default null);
  -- dodaje pojedyncza linie tekstu
  -- fontSizeChange - zmiana wielkosci czcionki w stosunku do standardowego rozmiaru (akceptuje rowniez liczby ujemne)
  -- textAlign      - null|center|right|left
  -- AddAttrs     - czcionka. Jezeli chcesz uzyskac bold, to musisz u�yc osobnych czcionek, np. font-family="courier-new" (normal) oraz font-family="courier-new-bold" (bold)
  procedure fopInsertPicture (filePath varchar2 default 'graph/sygnatura.gif', width varchar2 default null, addAttrs varchar2 default null);
  -- wstawia obraz z pliku
  -- filePath: scie�ka - moze byc zapisana w konwencji Windows lub Unix ( nie wa�ne w kt�ra strone beda znaki shlash)
  -- width   : rozmiar pliku, np. 100pt, 50%, 10cm. wysokosc skalowana jest proporcjonalnie.
  procedure fopOpenStndTable(columnWidths varchar2, borderStyle varchar2, addTableAttrs varchar2 default 'table-layout="fixed" text-align="left" vertical-align="top"');
  -- wstawia tabele
  -- columnWidths : format wprowadzania danych - wartoci rozdzielone znakiem zdefiniowanym podczas wywolania procedury fopOpen (domyslnie chr(9) ) , np: 1cm|1.5cm|2cm
  -- borderStyle  : solid|none
  procedure fopInsertStndTableHeader(ColumnLabels varchar2);
  -- wstawia naglowek tabeli
  -- wstawienie nag��wka tabeli nie jest wymagane
  -- np: Kolumna 1|Kolumna 2|Kolumna 3
  -- mozna rowniez uzyc formatu jak dla fopInsertStndTableBody
  procedure fopInsertStndTableBody(ColumnLabels varchar2, addRowAtts varchar2 default null);
  -- wstawia wiersz do tabeli
  -- nadaj addRowAtts wartosc  keep-with-previous="always" dla wierszy podsumowan
  -- ColumnLabels - wartosci komorek w formacie wartosc, justowanie, kolor tla, styl ramki, dod.attr.komorki label#text-align#background-color#border-style#addCellAttrs np: Kolumna 1#left##BBBBBB|Kolumna 2#right|Kolumna 3#center
  -- nadaj addCellAttrs wartosc number-columns-spanned="<liczba, jesli do konca to wpisz 65000>" jesli chcesz laczyc komorki w pionie i pamietaj, ze w kolejnych wierszach wstawic liczbe komorek zmiejszona o 1
  -- np: Kolumna 1#left#BBBBBB|Kolumna 2#right|Kolumna 3#center
  procedure fopCloseStndTable;
  -- zamyka tabele


---------------------------------------------------------------------------- military trainig ground -------------------------------------------------
/*
  procedure fopOpen(dir varchar2, fileName varchar2, addStndLayoutMasterSet char default 'Y', outputType varchar2 default 'file', charsDelimiter char default chr(9));
  -- otwiera plik fop
  -- dir, filename - katalog i nazwa pliku np. dir := '/dbout/PPL4',   fileName := 'o'||p_file||'.xml';
  -- OutputType = file, xxmsztools_eventlog
  -- charsDelimiter - znak rozdzielajacy kolumny - zob. funkcje fop wstawiajace tabele

  -- uwagi:
  -- do pliku init<nazwa instancji>.ora nale�y doda� parametr np. utl_file_dir  = C:\fop-0.20.5
  --                                                              utl_file_dir  = /dbout/PPL4
  -- jezeli chcesz miec dostep do kilku katalogow, to rozdziel katalogi przecinkami np. utl_file_dir=/dbout/PPL4,/u05/apps1159/ppl4/ppl4db/9.2.0/appsutil/outbound/PPL4_oratest
  -- OutputType = xxmsztools_eventlog zostalo opracowane dla celow awaryjno-diagnostycznych (np. jesli chcesz pracowac, a nie masz mozliwosci dopisania do pliku init.ora parametru utl_file_dir)
  -- jesli wyrano OutputType = xxmsztools_eventlog, to pamietaj, ze
  --  1. tabela xxmsztools_eventlog powinna byc utworzona (zob. opis w tym pakiecie)
  --  2. wowczas wartosci parametro dir i filename sa bez znaczenia

  /*
  procedure openStndTable(columnWidths varchar2, borderStyle varchar2, addTableAttrs varchar2 default 'table-layout="fixed" text-align="left" vertical-align="top"');
  -- wstawia tabele
  -- columnWidths : format wprowadzania danych - wartoci rozdzielone znakiem zdefiniowanym podczas wywolania procedury fopOpen (domyslnie chr(9) ) , np: 1cm|1.5cm|2cm
  -- borderStyle  : solid|none
  procedure insertStndTableHeader(ColumnLabels varchar2);
  -- wstawia naglowek tabeli
  -- wstawienie nag��wka tabeli nie jest wymagane
  -- np: Kolumna 1|Kolumna 2|Kolumna 3
  -- mozna rowniez uzyc formatu jak dla fopInsertStndTableBody
  procedure insertStndTableBody(ColumnLabels varchar2, addRowAtts varchar2 default null);
  -- wstawia wiersz do tabeli
  -- nadaj addRowAtts wartosc  keep-with-previous="always" dla wierszy podsumowan
  -- ColumnLabels - wartosci komorek w formacie wartosc, justowanie, kolor tla, styl ramki, dod.attr.komorki label#text-align#background-color#border-style#addCellAttrs np: Kolumna 1#left##BBBBBB|Kolumna 2#right|Kolumna 3#center
  -- nadaj addCellAttrs wartosc number-columns-spanned="<liczba, jesli do konca to wpisz 65000>" jesli chcesz laczyc komorki w pionie i pamietaj, ze w kolejnych wierszach wstawic liczbe komorek zmiejszona o 1
  -- np: Kolumna 1#left#BBBBBB|Kolumna 2#right|Kolumna 3#center
  procedure closeStndTable;
  -- zamyka tabele

  problem kierowania strumienia
  przykladowa procedura ( przechodzenie naglowka na nowa strone)
  problem podsumowania w srodku i na koncu
  rozne typy ramek

    begin
      delete from xxmsztools_eventlog;
      commit;
          xxmsz_tools.OpenTable('5^5^5', 'solid'); --fop/txt
          xxmsz_tools.InsertTableHeader('pierwsza^druga^trzecia');
          xxmsz_tools.InsertTableBody('pierwsza#left#AAAAAA^druga#right#BBBBBB^trzecia#center');
		  --zaawansowane: ##FFFFFF#none~##FFFFFF#none~##FFFFFF#none~##FFFFFF#none~##FFFFFF#none~~Warto�� netto~VAT%~Kwota VAT~Warto�� brutto~Rabat
                          -- label#text-align#background-color#border-style#addCellAttrs
          ???xxmsz_tools.InsertTableSummary('pierwsza#left#AAAAAA^druga#right#BBBBBB^trzecia#center');
          xxmsz_tools.fopCloseStndTable;
    end;
    select message from xxmsztools_eventlog order by id

*/
-------------------------------------------------------------------------------------------------------------------------------------------------------



  -- kody sterujace drukarek
  /* wersja dla HP LaserJet 1200 Series
  prtBold_on       VARCHAR2(500) := CHR(27) || '[1m';
  prtBold_off      VARCHAR2(500) := CHR(27) || '[0m';
  prtUnderline_on  VARCHAR2(500) := CHR(27) || '[3m';
  prtUnderline_off VARCHAR2(500) := CHR(27) || '[2m';
  */

  prtBold_on       VARCHAR2(500) := CHR(27) || 'E';
  prtBold_off      VARCHAR2(500) := CHR(27) || 'F';
  prtUnderline_on  VARCHAR2(500) := CHR(27) || CHR(45) || CHR(1);
  prtUnderline_off VARCHAR2(500) := CHR(27) || CHR(45) || CHR(0);

  PRAGMA RESTRICT_REFERENCES(center         , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(trimSpaces     , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(makeStr        , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(extractWord    , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(wordCount      , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(merge          , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(wordWrap       , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(pasteStr       , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(erasePolishHooks, WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(addPercent     , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(isSubsetOf     , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(withoutPolishSigns, WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(tolatin2       , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(hasPolishSigns , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(extractFileName, WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(extractPath    , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(getBanknotes   , WNPS, WNDS, RNPS, WNPS);
  --PRAGMA RESTRICT_REFERENCES(amountInWords  , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(strToDate      , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(peselIsOK      , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(nipIsOk        , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(regonIsOk      , WNPS, WNDS, RNPS, WNPS);
  --PRAGMA RESTRICT_REFERENCES(getSQLValues   , WNPS, WNDS, RNPS, WNPS);
  --PRAGMA RESTRICT_REFERENCES(getSQLValue    , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(formatDate     , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(formatDateTime , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(formatFloat    , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(formatString   , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(maximum   , WNPS, WNDS, RNPS, WNPS);
  PRAGMA RESTRICT_REFERENCES(minimum   , WNPS, WNDS, RNPS, WNPS);

END;
/

CREATE OR REPLACE PACKAGE BODY xxmsz_tools AS

  moduleNameForEventLog  varchar2(200);
  fopDocumentId          varchar2(100);
  fopCurrentBorderStyle  varchar2(20);
  fopTableBodyFirstEntry boolean;
  fopFileHandler         utl_file.file_type;
  fopOutputType          varchar2(20); -- file, xxmsztools_eventlog
  fopCharsDelimiter      char;

  procedure fopOpen(dir varchar2, fileName varchar2, addStndLayoutMasterSet char default 'Y', outputType varchar2 default 'file', CharsDelimiter char default chr(9)) is
  begin
    fopCharsDelimiter := CharsDelimiter;
    fopOutputType := upper( outputType );

	if fopOutputType = 'FILE' then
      if utl_file.is_open (fopFileHandler) then --jesli plik otwarty to zamkniecie
        utl_file.fclose (fopFileHandler); -- zamkniecie
      else -- w pozostalym przypadku otwarcie
        --begin
           fopFileHandler := utl_file.fopen (dir, fileName, 'w', 32767);
        --exception
        -- when others then
        --   xxmsz_tools.insertIntoEventLog ( TO_CHAR (SQLCODE) || ' ' || SQLERRM, 'E', 'xxmsz_tools.fopOpen');
        --	  raise;
        -- end;
       end if;
    end if;

   --fopInsertRawText ( chr(239) || chr(187) || chr(191) || '<?xml version="1.0" encoding="UTF-8"?>');
   fopInsertRawText ( '<?xml version="1.0" encoding="ISO-8859-2"?>');
    -- kodowanie ISO-8859-2 jest w�asciwe dla plikow generowanych przez Oracle Applications
   fopInsertRawText ( '<fo:root xmlns:fo="http://www.w3.org/1999/XSL/Format">');
   if xxmsz_tools.ynToBool (addStndLayoutMasterSet) then
     fopInsertStndLayoutMasterSet;
   end if;

  end;

  procedure fopClose is
  begin
    fopInsertRawText ( '</fo:root>');
    if fopOutputType = 'FILE' then
      utl_file.fclose (fopFileHandler);
    end if;
  end;

  procedure fopInsertRawText (text varchar2) is
  begin
   if fopOutputType = 'FILE' then
     utl_file.put_line(fopFileHandler, text );
   else
     xxmsz_tools.insertIntoEventLog ( text, 'I', 'xxmsz_tools.fopInsertRawText');
	 --Fnd_File.put_line(Fnd_File.output, NVL(text,' ')); -- dla celow testowych mozna wstawic nastepujacy fragment
   end if;
  end;

  procedure fopInsertStndLayoutMasterSet is
  begin
   fopInsertRawText ( '<fo:layout-master-set> ');
   fopInsertRawText ( '   <fo:simple-page-master master-name="first" margin-right="0.75cm" margin-left="1cm" margin-bottom="0cm" margin-top="0cm" page-width="21cm" page-height="29.7cm">');
   fopInsertRawText ( '      <fo:region-body margin-top="1cm" margin-bottom="2cm"/>');
   fopInsertRawText ( '      <fo:region-before extent="0cm"/>');
   fopInsertRawText ( '      <fo:region-after extent="2cm"/>');
   fopInsertRawText ( '   </fo:simple-page-master>');
   fopInsertRawText ( '</fo:layout-master-set>');
  end;

  procedure fopOpenStndDocument (documentId varchar2, pageText varchar2 default 'Strona : ', footerText varchar2 default null, addPageAttrs varchar2 default 'font-family="courier-new" font-size="7pt" font-weight="normal" master-reference="first" initial-page-number="1" force-page-count="no-force"' ) is
  begin
   fopDocumentId := documentId;

   fopInsertRawText ( '   <fo:page-sequence '|| addPageAttrs ||'>');
   fopInsertRawText ( '      <fo:static-content flow-name="xsl-region-before">');
   fopInsertRawText ( '         <fo:block/>');
   fopInsertRawText ( '      </fo:static-content>');
   fopInsertRawText ( '      <fo:static-content flow-name="xsl-region-after">');
   fopInsertRawText ( '         <fo:block flow-name="xsl-region-body" text-align="start" line-height="1em + 2pt">');
   fopInsertRawText ( '            <fo:leader leader-pattern="rule" rule-thickness="1.0pt" leader-length="19cm"/>');
   fopInsertRawText ( '             ' || pageText);
   fopInsertRawText ( '            <fo:page-number/>');
   fopInsertRawText ( '            / ');
   fopInsertRawText ( '            <fo:page-number-citation ref-id="' || documentId  || '"/>');
   fopInsertRawText ( '            ' || footerText  || '   ');
   fopInsertRawText ( '         </fo:block>');
   fopInsertRawText ( '      </fo:static-content>');
   fopInsertRawText ( '      <fo:flow flow-name="xsl-region-body" white-space-treatment="preserve" white-space-collapse="false">');
  end;

  procedure fopCloseDocument is
  begin
   fopInsertRawText ( '         <fo:block id="' || fopDocumentId || '"></fo:block>');
   fopInsertRawText ( '      </fo:flow>');
   fopInsertRawText ( '   </fo:page-sequence>');
  end;

  procedure fopInsertText (t varchar2 default null, textAlign varchar2 default null, fontSizeChange varchar2 default '0pt', AddAttrs varchar2 default null) is
    fontSizeAtt  varchar2(100);
    textAlignAtt varchar2(100);
  begin
    if t is null then
      fopInsertRawText( '<fo:block ' || AddAttrs || ' space-after="from-parent(font-size) + ' || fontSizeChange || '"></fo:block>');
 	 -- pusta linia o szerokosci tekstu
    else

      if fontSizeChange <> '0pt' then
        fontSizeAtt := 'font-size="from-parent(font-size) + ' || fontSizeChange || '"';
      else
        fontSizeAtt := '';
      end if;

      if textAlign is not null then
        textAlignAtt := 'text-align="' || textAlign || '"';
      else
        textAlignAtt := '';
      end if;

      fopInsertRawText ( '<fo:block ' || fontSizeAtt || ' ' || textAlignAtt || '>' || t || '</fo:block>' );
    end if;
  end;

  procedure fopInsertPicture (filePath varchar2 default 'graph/sygnatura.gif', width varchar2 default null, addAttrs varchar2 default null) is
   widthAtt varchar2(100);
  begin
     if width is not null then
	   widthAtt := 'width="' || width || '"';
	 else
	   widthAtt := null;
	 end if;

     fopInsertRawText( '<fo:external-graphic src="url(' || filePath || ')" ' || widthAtt || ' '|| addAttrs ||'/>');
  end;

  procedure fopOpenStndTable(columnWidths varchar2, borderStyle varchar2, addTableAttrs varchar2 default 'table-layout="fixed" text-align="left" vertical-align="top"') is
    i number;
  begin
   fopInsertRawText ( '         <fo:table ' || addTableAttrs || '>');
   fopCurrentBorderStyle := borderStyle;

   for i in 1..xxmsz_tools.wordCount(columnWidths,fopCharsDelimiter) loop
     fopInsertRawText ( '            <fo:table-column column-width="' || xxmsz_tools.extractWord(i,columnWidths,fopCharsDelimiter) || '"/>');
   end loop;

   foptableBodyfirstEntry := true;
  end;

  procedure fopInsertStndTableHeader(ColumnLabels varchar2) is
    i                    number;
	textAlignValue       varchar2(50);
	BackgroundColorValue varchar2(30);
	LabelAtt             varchar2(5000);
	BackgroundColorAtt   varchar2(40);
	borderStyle          varchar2(40);
	AddCellAtts          varchar2(300);
  begin
     fopInsertRawText ( '            <fo:table-header>');
     fopInsertRawText ( '               <fo:table-row>');
   for i in 1..xxmsz_tools.wordCount(ColumnLabels,fopCharsDelimiter) loop
	 LabelAtt            := xxmsz_tools.extractWord(1, xxmsz_tools.extractWord(i,ColumnLabels,fopCharsDelimiter), '#');
	 textAlignValue      := xxmsz_tools.extractWord(2, xxmsz_tools.extractWord(i,ColumnLabels,fopCharsDelimiter), '#');
	 BackgroundColorValue:= xxmsz_tools.extractWord(3, xxmsz_tools.extractWord(i,ColumnLabels,fopCharsDelimiter), '#');
     borderStyle         := xxmsz_tools.extractWord(4, xxmsz_tools.extractWord(i,ColumnLabels,fopCharsDelimiter), '#');
	 AddCellAtts         := xxmsz_tools.extractWord(5, xxmsz_tools.extractWord(i,ColumnLabels,fopCharsDelimiter), '#');

	 if BackgroundColorValue is not null then
	   BackgroundColorAtt := 'background-color="#' || BackgroundColorValue || '"';
	 else
	   BackgroundColorAtt := '';
	 end if;

     fopInsertRawText ( '                  <fo:table-cell background-color="#'|| nvl(BackgroundColorValue, 'BBBBBB') ||'" border-width="0.5pt" border-color="black" border-style="' || nvl(borderStyle, fopCurrentBorderStyle) || '" ' || AddCellAtts || ' >');
     fopInsertRawText ( '                     <fo:block text-align="'|| nvl(textAlignValue, 'center') ||'" vertical-align="middle" >' || LabelAtt || '</fo:block>');
     fopInsertRawText ( '                  </fo:table-cell>');
   end loop;
     fopInsertRawText ( '               </fo:table-row>');
     fopInsertRawText ( '            </fo:table-header>');
  end;

  procedure fopInsertStndTableBody(ColumnLabels varchar2, addRowAtts varchar2 default null) is
    i                    number;
	textAlignValue       varchar2(50);
	BackgroundColorValue varchar2(30);
	LabelAtt             varchar2(5000);
	textAlignAtt         varchar2(50);
	BackgroundColorAtt   varchar2(40);
	borderStyle          varchar2(40);
	AddCellAtts          varchar2(300);
  begin
     if foptableBodyfirstEntry then
       fopInsertRawText ( '            <fo:table-body>');
	   foptableBodyfirstEntry := false;
	 end if;

     fopInsertRawText ( '               <fo:table-row ' || addRowAtts || '>');
   for i in 1..xxmsz_tools.wordCount(ColumnLabels,fopCharsDelimiter) loop
	 LabelAtt            := xxmsz_tools.extractWord(1, xxmsz_tools.extractWord(i,ColumnLabels,fopCharsDelimiter), '#');
	 textAlignValue      := xxmsz_tools.extractWord(2, xxmsz_tools.extractWord(i,ColumnLabels,fopCharsDelimiter), '#');
	 BackgroundColorValue:= xxmsz_tools.extractWord(3, xxmsz_tools.extractWord(i,ColumnLabels,fopCharsDelimiter), '#');
     borderStyle         := xxmsz_tools.extractWord(4, xxmsz_tools.extractWord(i,ColumnLabels,fopCharsDelimiter), '#');
	 AddCellAtts         := xxmsz_tools.extractWord(5, xxmsz_tools.extractWord(i,ColumnLabels,fopCharsDelimiter), '#');
	 if textAlignValue is not null then
	   textAlignAtt := 'text-align="' || textAlignValue || '"';
	 else
	   textAlignAtt := '';
	 end if;

	 if BackgroundColorValue is not null then
	   BackgroundColorAtt := 'background-color="#' || BackgroundColorValue || '"';
	 else
	   BackgroundColorAtt := '';
	 end if;

     fopInsertRawText ( '                  <fo:table-cell border-width="0.5pt" border-color="black" border-style="' || nvl(borderStyle, fopCurrentBorderStyle) || '" ' || BackgroundColorAtt || ' '|| AddCellAtts ||'>');
     fopInsertRawText ( '                     <fo:block ' || textAlignAtt || ' vertical-align="middle">' || LabelAtt || '</fo:block>');
     fopInsertRawText ( '                  </fo:table-cell>');
   end loop;

     fopInsertRawText ( '               </fo:table-row>');
  end;

  procedure fopCloseStndTable is
  begin
   fopInsertRawText ( '            </fo:table-body>');
   fopInsertRawText ( '         </fo:table>');
  end;

  function iif( cond boolean, str1 varchar2, str2 varchar2 ) return varchar2 is
  begin
    if cond then return str1;
    else return str2; end if;
  end;

  FUNCTION center (S VARCHAR2, LEN NUMBER) RETURN VARCHAR2 IS
    L NUMBER;
    SPACES VARCHAR2(500);
  BEGIN
    L := ROUND ( (LEN -  LENGTH(S))  / 2 );
    SPACES := SUBSTR('                                                                                                           ',1,L);
    RETURN SUBSTR( SPACES || S || SPACES, 1, len );
  END;

   FUNCTION extractWord  (poz NUMBER, words VARCHAR, sep VARCHAR := '|') RETURN VARCHAR IS
     word VARCHAR2(5000):='';
     word2 VARCHAR2(5000);
     str2 VARCHAR2(5000):= words || sep;
   BEGIN
     FOR i IN 1..poz LOOP
      IF i = 1 THEN
       word:=SUBSTR(str2,1,INSTR(str2,sep,poz)-1);
       word2:=str2;
      ELSE
       word2 := SUBSTR(word2,LENGTH(word2)+2-LENGTH(SUBSTR(word2,INSTR(word2,sep,1))));
       word  := SUBSTR(word2,1,INSTR(word2,sep,1)-1);
      END IF;
     END LOOP;
     RETURN Word;
   END;

  FUNCTION wordCount(  Words      VARCHAR2,
                       Separator  IN     VARCHAR2 := '|') RETURN NUMBER IS
  --------------------------------------------------------------------------------------
  -- Nazwa          : WordCount
  --
  -- Opis           : Funkcja zlicza liczb� podci�g�w rozdzielonych znakiem Separator
  --                  w ci�gu Words
  --
  -- Parametry      : Words - ci�g
  --                  Separator - znak rozdzielaj�cy podci�gi
  --
  -- Autor          : Maciej Szymczak, 17.10.2000
  --                  2004.06.18 - poprawka
  --------------------------------------------------------------------------------------
  N       NUMBER(9);
  Counter NUMBER(9);
  temp   VARCHAR2(30000);
  begin
	temp := words;
  	counter := 0;
  	for n in 1..length(temp) loop
  		 if substr(temp,n,1) = separator then
  		 	 counter := counter + 1;
  		 end if;
  	end loop;

  	return counter+1;
  exception
   when others then
    return 0;
  end;

  FUNCTION replaceWord(poz NUMBER, replaceWith varchar2, words VARCHAR, sep VARCHAR := '|') return varchar2 is
    res VARCHAR2(32000) := null;
	numberOfWords number(10);
  BEGIN
    numberOfWords := wordCount(Words, Sep);
	if numberOfWords < poz then
	 raise_application_error(-20000,'invalid poz parameter: cant be greather than numerOfWords');
	end if;
    FOR i IN 1..numberOfWords LOOP
	  if i <> poz then  res := merge(res,extractWord(i,Words,sep),sep);
	              else  res := merge(res,replaceWith,sep); end if;
	END LOOP;
	return res;
  END;

  function pushLastWord(pushWord varchar2, words varchar2, sep VARCHAR := '|') return varchar2 is --po��
  begin
    return xxmsz_tools.merge(words, pushWord, sep);
  end;

  function popLastWord(words varchar2, sep VARCHAR := '|') return varchar2 is --zabierz
    res VARCHAR2(32000) := null;
	numberOfWords number(10);
  BEGIN
    numberOfWords := wordCount(Words, Sep);
	if numberOfWords < 1 then
	 raise_application_error(-20000,'words is empty - cannot pop word');
	end if;
    FOR i IN 1..numberOfWords-1 LOOP
	  res := merge(res,extractWord(i,Words,sep),sep);
	END LOOP;
	return res;
  END;

  FUNCTION amountInWords(aamount NUMBER, language_code VARCHAR2 DEFAULT 'PL', currency_code1 VARCHAR2 DEFAULT 'z�', acurrency_code2 VARCHAR2 DEFAULT 'gr') RETURN VARCHAR2 IS
    Wart    VARCHAR2(2000);
    currency_code2 VARCHAR2(10);
    amount  NUMBER := round ( aamount, 2); -- np. 11.115 -> 11.12 ( if you would like to receive 11.11 call trunc(., 2) function before using AmountInWord

      FUNCTION engAmountInWords(amount NUMBER, language_code VARCHAR2 DEFAULT 'PL', currency_code1 VARCHAR2 DEFAULT 'z�', currency_code2 VARCHAR2 DEFAULT 'gr') RETURN VARCHAR2 IS
        value  NUMBER;
        value1  NUMBER;
        value2  NUMBER;
        DECIMAL NUMBER;
        i       NUMBER;
        S_SAY   VARCHAR2(2000);
        ratunek NUMBER;
      BEGIN
        ratunek := 1;
        S_SAY:='';
        i:=10;
        DECIMAL:=NVL(ABS(amount-TRUNC(amount)),0);
        value:=NVL(ABS(amount),0);
        LOOP
          value1:= TRUNC(value/i,1);
          value2:=(value1 - TRUNC(value1))*10;

          IF value1=0 AND value2*10=0 THEN S_SAY:=S_SAY || TO_CHAR(ROUND(DECIMAL,2)*100) || '/100* ' || currency_code1; EXIT; END IF;
          IF ratunek = 100            THEN S_SAY:=S_SAY || TO_CHAR(ROUND(DECIMAL,2)*100) || '0 / 100* ' || currency_code1; EXIT; END IF;--ratunek
          IF value2=1 THEN S_SAY:='one*' || S_SAY; END IF;
          IF value2=2 THEN S_SAY:='two*' || S_SAY; END IF;
          IF value2=3 THEN S_SAY:='three*' || S_SAY; END IF;
          IF value2=4 THEN S_SAY:='four*' || S_SAY; END IF;
          IF value2=5 THEN S_SAY:='five*' || S_SAY; END IF;
          IF value2=6 THEN S_SAY:='six*' || S_SAY; END IF;
          IF value2=7 THEN S_SAY:='seven*' || S_SAY; END IF;
          IF value2=8 THEN S_SAY:='eight*' || S_SAY; END IF;
          IF value2=9 THEN S_SAY:='nine*' || S_SAY; END IF;
          IF value2=0 THEN S_SAY:='zero*' || S_SAY; END IF;
          i:=i*10;
          ratunek := ratunek + 1;
        END LOOP;
      RETURN S_SAY;
      END;

    FUNCTION slownie( L VARCHAR2 ) RETURN VARCHAR2 IS
    	V VARCHAR2( 1000 ) := '';
    	V1 VARCHAR2( 100 ) := '';

    	R VARCHAR2( 1000 );
    	AKT VARCHAR2( 3 );
    	K INTEGER := 0;
    	STOP BOOLEAN := FALSE;


            function LICZEBNIK(
                K NUMBER,
                L1 VARCHAR2,
                L2 VARCHAR2,
                L5 VARCHAR2 )  RETURN VARCHAR2 IS
            BEGIN
                if K = 0 then
            	return L5;
                elsif K = 1 then
            	return L1;
                else
            	if K > 10 and K < 20 then
            	    return L5;
            	else
            	    declare
            		CH VARCHAR2( 40 );
            		L  NUMBER;
            	    begin
            		CH := TO_CHAR ( K );
            		L := TO_NUMBER ( SUBSTR( CH, NVL(LENGTH( CH ), 0) ) );
            		if L = 0 or L = 1 then
            		     return L5;
            		elsif L > 1 and L < 5 then
            		     return L2;
            		else
            		    return L5;
            		end if;
            	    end;
            	end if;
                end if;
            RETURN NULL; END;



            FUNCTION SLOWNIE3( L VARCHAR2 ) RETURN varchar2 IS
            	V VARCHAR2( 1000 ) :='';
            	NASCIE VARCHAR2( 1 ) := 'N';
            BEGIN
            	if NVL(LENGTH( L ), 0) > 2 then
            		if SUBSTR( L, 1, 1 )  = '1' then
            			V := 'sto ';
            		elsif SUBSTR( L, 1 , 1 ) = '2' then
            			V := 'dwie�cie ';
            	  	elsif SUBSTR( L,( 1 ), 1 ) = '3' then
            			V := 'trzysta ';
              		elsif SUBSTR( L,( 1 ), 1 ) = '4' then
            			V := 'czterysta ';
            	  	elsif SUBSTR( L,( 1 ), 1 ) = '5' then
            			V := 'pi��set ';
            	  	elsif SUBSTR( L,( 1 ), 1 ) = '6' then
            			V := 'sze��set ';
            	  	elsif SUBSTR( L,( 1 ), 1 ) = '7' then
            			V := 'siedemset ';
            	  	elsif SUBSTR( L,( 1 ), 1 ) = '8' then
            			V := 'osiemset ';
            	  	elsif SUBSTR( L,( 1 ), 1 ) = '9' then
            			V := 'dziewi��set ';
            		end if;
            	end if;
            	if NVL(LENGTH( L ), 0) > 1 then
            		if SUBSTR( L, ( NVL(LENGTH( L ), 0) - 1 ), 1 ) = '1' then
            			NASCIE := 'T';
            			if SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '0' then
            				V := V || 'dziesi�� ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '1' then
            				V := V || 'jedena�cie ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '2' then
            				V := V || 'dwana�cie ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '3' then
            				V := V || 'trzyna�cie ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '4' then
            				V := V || 'czterna�cie ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '5' then
            				V := V || 'pi�tna�cie ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '6' then
            				V := V || 'szesna�cie ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '7' then
            				V := V || 'siedemna�cie ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '8' then
            				V := V || 'osiemna�cie ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '9' then
            				V := V || 'dziewi�tna�cie ';
            			end if;
            		elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) - 1 ), 1 ) = '2' then
            			V := V || 'dwadzie�cia ';
            		elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) - 1 ), 1 ) = '3' then
            			V := V || 'trzydzie�ci ';
            		elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) - 1 ), 1 ) = '4' then
            			V := V || 'czterdzie�ci ';
            		elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) - 1 ), 1 ) = '5' then
            			V := V || 'pi��dziesi�t ';
            		elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) - 1 ), 1 ) = '6' then
            			V := V || 'sze��dziesi�t ';
            		elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) - 1 ), 1 ) = '7' then
            			V := V || 'siedemdziesi�t ';
            		elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) - 1 ), 1 ) = '8' then
            			V := V || 'osiemdziesi�t ';
            		elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) - 1 ), 1 ) = '9' then
            			V := V || 'dziewi��dziesi�t ';
            		end if;
            	end if;
            	if NVL(LENGTH( L ), 0) > 0 then
            		if NASCIE = 'N' then
            			if SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '1' then
            				V := V || 'jeden ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '2' then
            				V := V || 'dwa ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '3' then
            				V := V || 'trzy ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '4' then
            				V := V || 'cztery ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '5' then
            				V := V || 'pi�� ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '6' then
            				V := V || 'sze�� ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '7' then
            				V := V || 'siedem ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '8' then
            				V := V || 'osiem ';
            			elsif SUBSTR( L, ( NVL(LENGTH( L ), 0) ), 1 ) = '9' then
            				V := V || 'dziewi�� ';
            			end if;
            		end if;
            		if NVL(LENGTH( L ), 0) = 1 and SUBSTR ( L, 1, 1 ) = '0' then
            			V := 'zero ';
            		end if;
            	end if;
            	return V;
            END;



    BEGIN

    	LOOP
    		k := k + 1;
    		IF k > NVL(LENGTH( L ), 0) then
    			EXIT;
    		end if;
    		if SUBSTR( L, K, 1 ) <> '0' then
    		    R := SUBSTR( L, K, NVL(LENGTH( L ), 0) - K + 1 );
    		    exit;
    		end if;
    	end loop;
    	K := 0;
    	loop
    		if NVL(LENGTH( R ), 0) > 3 then
    			AKT := SUBSTR( R, NVL(LENGTH( R ), 0)- 2 , 3 );
    			R := SUBSTR( R, 1, NVL(LENGTH( R ), 0) - 3 );
    			V1 := SLOWNIE3( AKT );
    			K := K + 1;
    		else
    			STOP := TRUE;
    			AKT := R;
    			R := '';
    			V1 := SLOWNIE3( AKT );
    			K := K + 1;
    		end if;
    		if NVL(LENGTH( V1 ), 0) > 1 then
    			if K = 2 then
    				V1 := V1 ||
    					LICZEBNIK(
    						TO_NUMBER( AKT ),
    						'tysi�c ',
    						'tysi�ce ',
    						'tysi�cy ' );
    			elsif K = 3 then
    				V1 := V1 ||
    					LICZEBNIK(
    						TO_NUMBER( AKT ),
    						'milion ',
    						'miliony ',
    						'milion�w ' );
    			elsif K = 4 then
    				V1 := V1 ||
    					LICZEBNIK(
    						TO_NUMBER( AKT ),
    						'miliard ',
    						'miliardy ',
    						'miliard�w ' );
    			elsif K = 5 then
    				V1 := V1 ||
    					LICZEBNIK(
    						TO_NUMBER( AKT ),
    						'bilion ',
    						'biliony ',
    						'bilion�w ' );
    			elsif K = 6 then
    				V1 := V1 ||
    					LICZEBNIK(
    						TO_NUMBER( AKT ),
    						'trylion ',
    						'tryliony ',
    						'trylion�w ' );
    			end if;
    			V := V1 || V;
    		END IF;
    		exit when STOP;
    	end loop;
    	return V;

    END;


  BEGIN
    currency_code2 := acurrency_code2;
    IF currency_code1 <> 'z�' AND currency_code2 = 'gr' THEN
      currency_code2 := NULL;
    END IF;

    IF language_code <> 'PL' THEN
     RETURN EngAmountInWords(amount, language_code, currency_code1, currency_code2);
    END IF;

	DECLARE
	 MinusHolder VARCHAR2(1);
	BEGIN
	  MinusHolder := '';
      IF amount < 0 THEN
	   MinusHolder := '-';
	  END IF;

       Wart := slownie (trunc(abs(amount))) || currency_code1 || ' ';
       -- tutaj dodaj grosze
       IF TRUNC( ABS(amount), 2) - TRUNC( ABS(amount), 2)  >= 0 THEN
           Wart := Wart ||SUBSTR( TO_CHAR( TRUNC( ABS(amount), 2), '99999999999999999999.00' ), -2 ) ||'/100 ' || currency_code2;
       END IF;
      RETURN Merge ( MinusHolder, Wart);
	END;
  END;

  FUNCTION merge(S1 VARCHAR2, S2 VARCHAR2, SEP VARCHAR2 DEFAULT NULL) RETURN VARCHAR2 IS
  BEGIN
   IF S1 IS NULL THEN
      RETURN S2;
   ELSE
      IF S2 IS NULL THEN
       RETURN S1;
      ELSE
        RETURN S1 || Sep || S2;
      END IF;
   END IF;
  END;

  PROCEDURE addPercent ( V IN OUT VARCHAR2 ) IS
  BEGIN
    IF INSTR(V, '%') = 0 OR V IS NULL THEN
      V := MERGE ( V, '%', '');
    END IF;
  END;

  FUNCTION strToDate
  ( p_dat VARCHAR2 ) RETURN DATE AS
    v_dat VARCHAR2(1000);
    v_buf DATE := NULL;
  BEGIN
    v_dat := UPPER(p_dat);
    IF v_dat IS NOT NULL THEN
      IF INSTR(v_dat,'STY')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'STY')-1)||'01'||SUBSTR(v_dat,INSTR(v_dat,'STY')+3);
      END IF;
      IF INSTR(v_dat,'LUT')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'LUT')-1)||'02'||SUBSTR(v_dat,INSTR(v_dat,'LUT')+3);
      END IF;
      IF INSTR(v_dat,'MAR')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'MAR')-1)||'03'||SUBSTR(v_dat,INSTR(v_dat,'MAR')+3);
      END IF;
      IF INSTR(v_dat,'KWI')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'KWI')-1)||'04'||SUBSTR(v_dat,INSTR(v_dat,'KWI')+3);
      END IF;
      IF INSTR(v_dat,'MAJ')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'MAJ')-1)||'05'||SUBSTR(v_dat,INSTR(v_dat,'MAJ')+3);
      END IF;
      IF INSTR(v_dat,'CZE')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'CZE')-1)||'06'||SUBSTR(v_dat,INSTR(v_dat,'CZE')+3);
      END IF;
      IF INSTR(v_dat,'LIP')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'LIP')-1)||'07'||SUBSTR(v_dat,INSTR(v_dat,'LIP')+3);
      END IF;
      IF INSTR(v_dat,'SIE')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'SIE')-1)||'08'||SUBSTR(v_dat,INSTR(v_dat,'SIE')+3);
      END IF;
      IF INSTR(v_dat,'WRZ')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'WRZ')-1)||'09'||SUBSTR(v_dat,INSTR(v_dat,'WRZ')+3);
      END IF;
      IF INSTR(v_dat,'PA')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'PA')-1)||'10'||SUBSTR(v_dat,INSTR(v_dat,'PA')+3);
      END IF;
      IF INSTR(v_dat,'LIS')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'LIS')-1)||'11'||SUBSTR(v_dat,INSTR(v_dat,'LIS')+3);
      END IF;
      IF INSTR(v_dat,'GRU')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'GRU')-1)||'12'||SUBSTR(v_dat,INSTR(v_dat,'GRU')+3);
      END IF;
      IF INSTR(v_dat,'JAN')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'JAN')-1)||'01'||SUBSTR(v_dat,INSTR(v_dat,'JAN')+3);
      END IF;
      IF INSTR(v_dat,'FEB')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'FEB')-1)||'02'||SUBSTR(v_dat,INSTR(v_dat,'FEB')+3);
      END IF;
      IF INSTR(v_dat,'MAR')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'MAR')-1)||'03'||SUBSTR(v_dat,INSTR(v_dat,'MAR')+3);
      END IF;
      IF INSTR(v_dat,'APR')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'APR')-1)||'04'||SUBSTR(v_dat,INSTR(v_dat,'APR')+3);
      END IF;
      IF INSTR(v_dat,'MAY')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'MAY')-1)||'05'||SUBSTR(v_dat,INSTR(v_dat,'MAY')+3);
      END IF;
      IF INSTR(v_dat,'JUN')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'JUN')-1)||'06'||SUBSTR(v_dat,INSTR(v_dat,'JUN')+3);
      END IF;
      IF INSTR(v_dat,'JUL')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'JUL')-1)||'07'||SUBSTR(v_dat,INSTR(v_dat,'JUL')+3);
      END IF;
      IF INSTR(v_dat,'AUG')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'AUG')-1)||'08'||SUBSTR(v_dat,INSTR(v_dat,'AUG')+3);
      END IF;
      IF INSTR(v_dat,'SEP')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'SEP')-1)||'09'||SUBSTR(v_dat,INSTR(v_dat,'SEP')+3);
      END IF;
      IF INSTR(v_dat,'NOV')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'NOV')-1)||'10'||SUBSTR(v_dat,INSTR(v_dat,'NOV')+3);
      END IF;
      IF INSTR(v_dat,'OCT')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'OCT')-1)||'11'||SUBSTR(v_dat,INSTR(v_dat,'OCT')+3);
      END IF;
      IF INSTR(v_dat,'DEC')>0 THEN
        v_dat := SUBSTR(v_dat,1,INSTR(v_dat,'DEC')-1)||'12'||SUBSTR(v_dat,INSTR(v_dat,'DEC')+3);
      END IF;
    END IF;
    -- data nie moze zawierac liter i musi zawierac cyfry
    IF  NVL(TRANSLATE(v_dat,'0ABCDEFGHIJKLMNOPQRSTUVWXYZ��ʣ�ӌ������󳜟�','0'),'0') = v_dat
    AND NOT NVL(TRANSLATE(v_dat,' 0123456789', ' '),' ') = v_dat
      THEN
      BEGIN
        v_buf := TO_DATE(v_dat,'DD-MM-YY'); -- jesli w dobrym formacie to zostaw
      EXCEPTION
        WHEN OTHERS THEN
        BEGIN
          v_buf := TO_DATE(v_dat,'YYYY/MM/DD'); --'D-M-YYYY'
        EXCEPTION
          WHEN OTHERS THEN
          BEGIN
            v_buf := TO_DATE(v_dat,'YYYY/MM/DD HH24:MI:SS');
          EXCEPTION
            WHEN OTHERS THEN
            BEGIN
              v_buf := TO_DATE(v_dat,'D-M-YY');
            EXCEPTION
              WHEN OTHERS THEN
              BEGIN
                v_buf := TO_DATE(v_dat,'YY-M-D');
              EXCEPTION
                WHEN OTHERS THEN
                BEGIN
                  v_buf := TO_DATE(v_dat,'M-D-YYYY');
                EXCEPTION
                  WHEN OTHERS THEN
                  BEGIN
                    v_buf := TO_DATE(v_dat,'M-DM-YY');
                  EXCEPTION
                    WHEN OTHERS THEN
                    BEGIN
                      v_buf := TO_DATE(v_dat,'YY-D-M');
                    EXCEPTION
                      WHEN OTHERS THEN
                      BEGIN
                        v_buf := TO_DATE(v_dat,'YYYY-D-M');
                      EXCEPTION
                        WHEN OTHERS THEN
                        BEGIN
                          v_buf := TO_DATE(v_dat,'DDMMYYYY');
                        EXCEPTION
                          WHEN OTHERS THEN
                          BEGIN
                            v_buf := TO_DATE(v_dat,'DDMMYY');
                          EXCEPTION
                            WHEN OTHERS THEN
                            BEGIN
                              v_buf := TO_DATE(v_dat,'MMDDYYYY');
                            EXCEPTION
                              WHEN OTHERS THEN
                              BEGIN
                                v_buf := TO_DATE(v_dat,'MMDDYY');
                              EXCEPTION
                                WHEN OTHERS THEN
                                BEGIN
                                  v_buf := TO_DATE(v_dat, 'YYYY-M-D');
                                EXCEPTION
                                  WHEN OTHERS THEN
                                  BEGIN
                                    v_buf := TO_DATE(v_dat);
                                  EXCEPTION
                                    WHEN OTHERS THEN v_buf := NULL;
                                  END;
                                END;
                              END;
                            END;
                          END;
                        END;
                      END;
                    END;
                  END;
                END;
              END;
            END;
          END;
        END;
      END;
    END IF;
    RETURN v_buf;
    --if v_buf is not null then
    --  return('D');
    --else
    --  return('V:'||v_dat);
    --end if;
  END;

  
  FUNCTION isSubsetOf (Set1 VARCHAR2, Set2 VARCHAR2) RETURN VARCHAR2 IS
    T INTEGER;
    NOT_FOUND BOOLEAN;
    ELEMENT VARCHAR2(100);
	workSet2 VARCHAR2(5000);
  BEGIN
    workSet2 := ';' || set2 || ';';
    NOT_FOUND := FALSE;
    T := 1;
    ELEMENT := EXTRACTWORD(1,SET1,';');
    WHILE (NVL(ELEMENT,'<EMPTY>') <> '<EMPTY>') AND (NOT_FOUND = FALSE) LOOP
      IF INSTR(workSet2, ';' || ELEMENT || ';') = 0 THEN
        NOT_FOUND := TRUE;
      END IF;
      T := T + 1;
      ELEMENT := EXTRACTWORD(T,SET1,';');
    END LOOP;
    IF NOT_FOUND THEN
       RETURN 'N';
    ELSE
       RETURN 'Y';
    END IF;
  END;

  FUNCTION peselIsOK ( PESEL  VARCHAR2 ) RETURN  VARCHAR2
    IS
  TYPE  TPesel  IS  TABLE  OF  NUMBER  INDEX  BY  BINARY_INTEGER;
  CPesel          TPESEL;
  TempPESEL       NUMBER;
  L               BINARY_INTEGER;
  CyfraKontrolna  NUMBER;

  BEGIN
  IF LENGTH( PESEL ) <> 11 THEN
    RETURN 'N';
  ELSE
   TempPESEL := TO_NUMBER ( PESEL );
   FOR L IN REVERSE 1..11 LOOP
  	 CPesel(L) := MOD(TempPESEL,10);
  	 TempPESEL := FLOOR(TempPesel/10);
   END LOOP;

   CyfraKontrolna := MOD(10 - MOD(
     MOD(CPesel( 1) * 1,10) +
     MOD(CPesel( 2) * 3,10) +
     MOD(CPesel( 3) * 7,10) +
     MOD(CPesel( 4) * 9,10) +
     MOD(CPesel( 5) * 1,10) +
     MOD(CPesel( 6) * 3,10) +
     MOD(CPesel( 7) * 7,10) +
     MOD(CPesel( 8) * 9,10) +
     MOD(CPesel( 9) * 1,10) +
     MOD(CPesel(10) * 3,10),10),10);

   IF (CyfraKontrolna = CPesel(11)) THEN
    RETURN 'Y';
   ELSE
    RETURN 'N';
   END IF;

  END IF;

  EXCEPTION
  	WHEN OTHERS THEN
  		RETURN 'N';
  END;

  FUNCTION nipIsOk ( NIP  VARCHAR2 ) RETURN  VARCHAR2
    IS
   /* ********************************************************************** */
  /* Funkcja sprawdza czy NIP jest dobry                                    */
  /* Zwraca Y/N
  /* ********************************************************************** */
    TYPE  TNip  IS  TABLE  OF  NUMBER  INDEX  BY  BINARY_INTEGER;
    CNIP            TNip;
    TempNIP         NUMBER;
    L               BINARY_INTEGER;
    CyfraKontrolna  NUMBER;
   BEGIN
  IF LENGTH( NIP ) <> 10 THEN
    RETURN 'N';
  ELSE
   TempNIP := TO_NUMBER ( NIP );
   IF TempNIP = 0 THEN RETURN 'N'; END IF;
   FOR L IN REVERSE 1..10 LOOP
  	 CNIP(L) := MOD(TempNIP,10);
  	 TempNIP := FLOOR(TempNIP/10);
   END LOOP;
   CyfraKontrolna :=
     MOD(
     CNIP( 1) * 6 +
     CNIP( 2) * 5 +
     CNIP( 3) * 7 +
     CNIP( 4) * 2 +
     CNIP( 5) * 3 +
     CNIP( 6) * 4 +
     CNIP( 7) * 5 +
     CNIP( 8) * 6 +
     CNIP( 9) * 7,11);
   IF (CyfraKontrolna = CNIP(10))	THEN
     RETURN 'Y';
   ELSE
     RETURN 'N';
   END IF;
  END IF;
  EXCEPTION
   WHEN OTHERS THEN
        RETURN 'N';
  END;

  FUNCTION regonIsOk ( REGON  VARCHAR2 ) RETURN  VARCHAR2
    IS
   CyfraKontrolna     NUMBER;
      c1                 NUMBER;
      c2                 NUMBER;
      c3                 NUMBER;
      c4                 NUMBER;
      c5                 NUMBER;
      c6                 NUMBER;
      c7                 NUMBER;
      c8                 NUMBER;
      c9                 NUMBER;
     BEGIN
     IF LENGTH(regon) <> 9 AND  LENGTH(regon) <> 14 THEN RETURN 'N'; END IF;
     IF TO_NUMBER(regon) = 0 THEN RETURN 'N'; END IF;

     c1 := TO_NUMBER(SUBSTR(regon,1,1));
     c2 := TO_NUMBER(SUBSTR(regon,2,1));
     c3 := TO_NUMBER(SUBSTR(regon,3,1));
     c4 := TO_NUMBER(SUBSTR(regon,4,1));
     c5 := TO_NUMBER(SUBSTR(regon,5,1));
     c6 := TO_NUMBER(SUBSTR(regon,6,1));
     c7 := TO_NUMBER(SUBSTR(regon,7,1));
     c8 := TO_NUMBER(SUBSTR(regon,8,1));
     c9 := TO_NUMBER(SUBSTR(regon,9,1));

     CyfraKontrolna := MOD(
    (c1 * 8 +
     C2 * 9 +
     C3 * 2 +
     C4 * 3 +
     C5 * 4 +
     C6 * 5 +
     C7 * 6 +
     C8 * 7),11);

     IF CyfraKontrolna = c9 THEN RETURN 'Y';
     ELSE RETURN 'N';
     END IF;
  EXCEPTION
  	WHEN OTHERS THEN
  		RETURN 'N';
  END;

  FUNCTION formatDate(Word VARCHAR2) RETURN VARCHAR2 IS
  --------------------------------------------------------------------------------------
  -- Nazwa          : FormatDate
  --
  -- Opis           : Funkcja przekaszta�aca date do postaci akceptowanej przez polecenie DML
  --
  -- Autor          : Maciej Szymczak, 17.10.2000
  --------------------------------------------------------------------------------------
  BEGIN
    IF LENGTH(Word) <> 0 THEN
    	RETURN 'TO_DATE('''||Word||''',''dd.mm.yyyy'')';
    ELSE
    	RETURN 'NULL';
    END IF;
  END;

  FUNCTION formatDateTime(Word VARCHAR2) RETURN VARCHAR2 IS
  --------------------------------------------------------------------------------------
  -- Nazwa          : FormatDateTime
  --
  -- Opis           : Funkcja przekaszta�aca si� do postaci akceptowanej przez
  --                  polecenie DML
  --
  -- Autor          : Maciej Szymczak, 17.10.2000
  --------------------------------------------------------------------------------------
  BEGIN
    IF LENGTH(Word) <> 0 THEN
    	RETURN 'TO_DATE('''||Word||''',''dd.mm.yyyy HH24:MI'')';
    ELSE
    	RETURN 'NULL';
    END IF;
  END;

  FUNCTION formatFloat(Word VARCHAR2) RETURN VARCHAR2 IS
  --------------------------------------------------------------------------------------
  -- Nazwa          : FormatFloat
  --
  -- Opis           : Funkcja przekaszta�aca si� do postaci akceptowanej przez
  --                  polecenie DML
  --
  -- Autor          : Maciej Szymczak, 17.10.2000
  --------------------------------------------------------------------------------------
  BEGIN
    IF LENGTH(Word) <> 0 THEN
    	RETURN Word;
    ELSE
    	RETURN 'NULL';
    END IF;
  END;

  FUNCTION formatString(Word VARCHAR2) RETURN VARCHAR2 IS
  --------------------------------------------------------------------------------------
  -- Nazwa          : FormatString
  --
  -- Opis           : Funkcja przekaszta�aca si� do postaci akceptowanej przez
  --                  polecenie DML
  --
  -- Autor          : Maciej Szymczak, 17.10.2000
  --------------------------------------------------------------------------------------
  BEGIN
    RETURN ''''||REPLACE(Word,'''','''''')||'''';
  END;

  FUNCTION toLatin2 (tekst IN VARCHAR2) RETURN VARCHAR2 IS
    STR_ROB VARCHAR2(1024);
  BEGIN
      str_rob := tekst;
      str_rob := REPLACE(str_rob, '�', CHR(164));
      str_rob := REPLACE(str_rob, '�', CHR(141));
      str_rob := REPLACE(str_rob, '�', CHR(143));
      str_rob := REPLACE(str_rob, '�', CHR(168));
      str_rob := REPLACE(str_rob, '�', CHR(157));
      str_rob := REPLACE(str_rob, '�', CHR(227));
      str_rob := REPLACE(str_rob, '�', CHR(224));
      str_rob := REPLACE(str_rob, '�', CHR(151));
      str_rob := REPLACE(str_rob, '�', CHR(189));
      str_rob := REPLACE(str_rob, '�', CHR(165));
      str_rob := REPLACE(str_rob, '�', CHR(134));
      str_rob := REPLACE(str_rob, '�', CHR(169));
      str_rob := REPLACE(str_rob, '�', CHR(136));
      str_rob := REPLACE(str_rob, '�', CHR(228));
      str_rob := REPLACE(str_rob, '�', CHR(162));
      str_rob := REPLACE(str_rob, '�', CHR(152));
      str_rob := REPLACE(str_rob, '�', CHR(171));
      str_rob := REPLACE(str_rob, '�', CHR(190));
      RETURN(str_rob);
  END;

  FUNCTION hasPolishSigns(S IN OUT VARCHAR2) RETURN VARCHAR2 IS
  	S2 VARCHAR2(500);
  BEGIN
  	S := UPPER(S);
  	S2 := S;
    S := REPLACE(S,'�','');
    S := REPLACE(S,'�','');
    S := REPLACE(S,'�','');
    S := REPLACE(S,'�','');
    S := REPLACE(S,'�','');
    S := REPLACE(S,'�','');
    S := REPLACE(S,'�','');
    S := REPLACE(S,'�','');
    S := REPLACE(S,'�','');

    IF S <> S2 THEN RETURN 'Y'; ELSE RETURN 'N'; END IF;
  END;

  FUNCTION extractFileName(S  IN VARCHAR2)  RETURN VARCHAR2  IS
  -- Opis           : Funkcja wyodr�bnia ze �cie�ki nazw� pliku
  --                  np. ExtractFileName('c:\Program Files\Joasia.xls') -> Joasia.xls
  -- Autor          : Maciej Szymczak, 17.10.2000
  --------------------------------------------------------------------------------------
    POS   NUMBER;
  BEGIN
    POS := INSTR(S, '\', -1, 1);
    IF POS = 0 THEN
        POS := INSTR(S, '/', -1, 1);
    END IF;
    RETURN SUBSTR(S, POS+1 );
  END;

  FUNCTION extractPath (S  IN VARCHAR2)  RETURN VARCHAR2  IS
  -- Opis           : Funkcja wyodr�bnia ze �cie�ki �cie�k� bez nazwy pliku
  --                  np. ExtractFileName('c:\Program Files\Joasia.xls') -> c:\Program Files\
  -- Autor          : Maciej Szymczak, 17.10.2000
  --------------------------------------------------------------------------------------
    POS   NUMBER;
  BEGIN
    POS := INSTR(S, '\', -1, 1);
    IF POS = 0 THEN
        POS := INSTR(S, '/', -1, 1);
    END IF;
    RETURN SUBSTR(S, 1, POS );
  END;

  FUNCTION getBanknotes( Wydaj VARCHAR2 ) RETURN VARCHAR2 IS
  -- Opis   : Kwota podana w banknotach i bilonach
  -- Autor	: Adam P�andowski 2001.03.10
  	W1000 VARCHAR2(20);
  	W200  VARCHAR2(20);
  	W100  VARCHAR2(20);
  	W50   VARCHAR2(20);
  	W20   VARCHAR2(20);
  	W10   VARCHAR2(20);
  	W5    VARCHAR2(20);
  	W2    VARCHAR2(20);
    W1    VARCHAR2(20);
    Wgr   VARCHAR2(20);
  	tekst VARCHAR2(250);
  	Wynik NUMBER(16,2);
  BEGIN
  -- Sprawd� d�ugo�� kwoty dla setek 1000 z�
  IF TRUNC(wydaj)<0 THEN
  RETURN	Tekst||' ???? ';
  ELSE
     IF NVL(LENGTH( TRUNC(Wydaj) ), 0)>3 THEN
     	-- Dla 1000
     --	 IF Trunc(Wydaj/200)>=5 THEN
         IF TRUNC(Wydaj/200)>=5 THEN
     	 	  W200:=TRUNC(Wydaj/200)||'*200';
          Wynik:=Wydaj-TRUNC(Wydaj/200)*200;
      IF Wynik>=100 THEN
      	W100:=',100';
     END IF;
  	  IF SUBSTR(Wynik,INSTR(Wynik,',')-2,1)=9 THEN
        W50:=',50';
        W20:=',20,20';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-2,1)=8 THEN
        W50:=',50';
        W20:=',20';
        W10:=',10';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-2,1)=7 THEN
        W50:=',50';
        W20:=',20';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-2,1)=6 THEN
        W50:=',50';
        W10:=',10';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-2,1)=5 THEN
        W50:=',50';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-2,1)=4 THEN
        W20:=',20,20';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-2,1)=3 THEN
        W20:=',20';
        W10:=',10';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-2,1)=2 THEN
        W20:=',20';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-2,1)=1 THEN
        W20:=',10';
      END IF;
    IF SUBSTR(Wynik,INSTR(Wynik,',')-1,1)=9 THEN
      	W5:=',5';
      	W2:=',2,2';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-1,1)=8 THEN
        W5:=',5';
      	W2:=',2';
      	W1:=',1';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-1,1)=7 THEN
        W5:=',5';
      	W2:=',2';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-1,1)=6 THEN
        W5:=',5';
      	W1:=',1';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-1,1)=5 THEN
        W5:=',5';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-1,1)=4 THEN
        W2:=',2,2';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-1,1)=3 THEN
        W2:=',2';
      	W1:=',1';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-1,1)=2 THEN
        W2:=',2';
      ELSIF SUBSTR(Wynik,INSTR(Wynik,',')-1,1)=1 THEN
        W1:=',1';
      END IF;

    END IF;
       --
  -- Sprawd� d�ugo�� kwoty dla setek do 999 z�
     ELSIF NVL(LENGTH( TRUNC(Wydaj) ), 0)=3 THEN
  	   IF TRUNC(Wydaj/100) >=9 THEN
  	   		 W200:='4*200';
  	   		 W100:=',100';
  	   		 Wynik:=Wydaj-TRUNC(Wydaj/100)*100;
  	   -- Warto�ci poni�ej 100
  	     IF TRUNC(Wynik/50)=1 THEN
  	   	 	  W50:=',50';
  	   	 	  Wynik:=Wynik-50;
  	   	 END IF;
  	   	 IF TRUNC(Wynik/20)=2  THEN
  	     	 	W20:=',20,20';
  	     	 	Wynik:=Wynik-40;
  	     END IF;
  	     IF TRUNC(Wynik/20)=1 THEN
  	     	 	W20:=',20';
  	     	 	Wynik:=Wynik-20;
  	     END IF;
  	     IF TRUNC(Wynik/10)=1 THEN
  	     	  W10:=',10';
  	     END IF;
  	 -- Wydaj 800
  		 ELSIF TRUNC(Wydaj/100)=8 THEN
  			    W200:='4*200';
  			 Wynik:=Wydaj-800;
  	     IF TRUNC(Wynik/50)=1 THEN
  	   	 	  W50:=',50';
  	   	 	  Wynik:=Wynik-50;
  	   	 END IF;
  	   	 IF TRUNC(Wynik/20)=2  THEN
  	     	 	W20:=',20,20';
  	     	 	Wynik:=Wynik-40;
  	     END IF;
  	     IF TRUNC(Wynik/20)=1 THEN
  	     	 	W20:=',20';
  	     	 	Wynik:=Wynik-20;
  	     END IF;
  	     IF TRUNC(Wynik/10)=1 THEN
  	     	  W10:=',10';
  	     END IF;
  	 -- Wydaj 700
  		 ELSIF TRUNC(Wydaj/100)=7 THEN
  			    W200:='3*200';
  			    W100:=',100';
  			 Wynik:=Wydaj-700;
  	     IF TRUNC(Wynik/50)=1 THEN
  	   	 	  W50:=',50';
  	   	 	  Wynik:=Wynik-50;
  	   	 END IF;
  	   	 IF TRUNC(Wynik/20)=2  THEN
  	     	 	W20:=',20,20';
  	     	 	Wynik:=Wynik-40;
  	     END IF;
  	     IF TRUNC(Wynik/20)=1 THEN
  	     	 	W20:=',20';
  	     	 	Wynik:=Wynik-20;
  	     END IF;
  	     IF TRUNC(Wynik/10)=1 THEN
  	     	  W10:=',10';
  	     END IF;
  	 -- Wydaj 600
  		 ELSIF TRUNC(Wydaj/100)=6 THEN
  			    W200:='3*200';
  			 Wynik:=Wydaj-600;
  	     IF TRUNC(Wynik/50)=1 THEN
  	   	 	  W50:=',50';
  	   	 	  Wynik:=Wynik-50;
  	   	 END IF;
  	   	 IF TRUNC(Wynik/20)=2  THEN
  	     	 	W20:=',20,20';
  	     	 	Wynik:=Wynik-40;
  	     END IF;
  	     IF TRUNC(Wynik/20)=1 THEN
  	     	 	W20:=',20';
  	     	 	Wynik:=Wynik-20;
  	     END IF;
  	     IF TRUNC(Wynik/10)=1 THEN
  	     	  W10:=',10';
  	     END IF;
  	 -- Wydaj 500
  		 ELSIF TRUNC(Wydaj/100)=5 THEN
  			    W200:='200,200';
  			    W100:=',100';
  			 Wynik:=Wydaj-500;
  	     IF TRUNC(Wynik/50)=1 THEN
  	   	 	  W50:=',50';
  	   	 	  Wynik:=Wynik-50;
  	   	 END IF;
  	   	 IF TRUNC(Wynik/20)=2  THEN
  	     	 	W20:=',20,20';
  	     	 	Wynik:=Wynik-40;
  	     END IF;
  	     IF TRUNC(Wynik/20)=1 THEN
  	     	 	W20:=',20';
  	     	 	Wynik:=Wynik-20;
  	     END IF;
  	     IF TRUNC(Wynik/10)=1 THEN
  	     	  W10:=',10';
  	     END IF;
  	 -- Wydaj 400
  		 ELSIF TRUNC(Wydaj/100)=4 THEN
  			    W200:='200,200';
  			 Wynik:=Wydaj-400;
  	     IF TRUNC(Wynik/50)=1 THEN
  	   	 	  W50:=',50';
  	   	 	  Wynik:=Wynik-50;
  	   	 END IF;
  	   	 IF TRUNC(Wynik/20)=2  THEN
  	     	 	W20:=',20,20';
  	     	 	Wynik:=Wynik-40;
  	     END IF;
  	     IF TRUNC(Wynik/20)=1 THEN
  	     	 	W20:=',20';
  	     	 	Wynik:=Wynik-20;
  	     END IF;
  	     IF TRUNC(Wynik/10)=1 THEN
  	     	  W10:=',10';
  	     END IF;
  	 -- Wydaj 300
  		 ELSIF TRUNC(Wydaj/100)=3 THEN
  			    W200:='200';
  			    W100:=',100';
  			 Wynik:=Wydaj-300;
  	     IF TRUNC(Wynik/50)=1 THEN
  	   	 	  W50:=',50';
  	   	 	  Wynik:=Wynik-50;
  	   	 END IF;
  	   	 IF TRUNC(Wynik/20)=2  THEN
  	     	 	W20:=',20,20';
  	     	 	Wynik:=Wynik-40;
  	     END IF;
  	     IF TRUNC(Wynik/20)=1 THEN
  	     	 	W20:=',20';
  	     	 	Wynik:=Wynik-20;
  	     END IF;
  	     IF TRUNC(Wynik/10)=1 THEN
  	     	  W10:=',10';
  	     END IF;
  	 -- Wydaj 200
  		 ELSIF TRUNC(Wydaj/100)=2 THEN
  			    W200:='200';
  			 Wynik:=Wydaj-200;
  	     IF TRUNC(Wynik/50)=1 THEN
  	   	 	  W50:=',50';
  	   	 	  Wynik:=Wynik-50;
  	   	 END IF;
  	   	 IF TRUNC(Wynik/20)=2  THEN
  	     	 	W20:=',20,20';
  	     	 	Wynik:=Wynik-40;
  	     END IF;
  	     IF TRUNC(Wynik/20)=1 THEN
  	     	 	W20:=',20';
  	     	 	Wynik:=Wynik-20;
  	     END IF;
  	     IF TRUNC(Wynik/10)=1 THEN
  	     	  W10:=',10';
  	     END IF;
  		 -- Wydaj 100
  		 ELSIF TRUNC(Wydaj/100)=1 THEN
  			    W100:='100';
  			    Wynik:=Wydaj-100;
  	     IF TRUNC(Wynik/50)=1 THEN
  	   	 	  W50:=',50';
  	   	 	  Wynik:=Wynik-50;
  	   	 END IF;
  	   	 IF TRUNC(Wynik/20)=2  THEN
  	     	 	W20:=',20,20';
  	     	 	Wynik:=Wynik-40;
  	     END IF;
  	     IF TRUNC(Wynik/20)=1 THEN
  	     	 	W20:=',20';
  	     	 	Wynik:=Wynik-20;
  	     END IF;
  	     IF TRUNC(Wynik/10)=1 THEN
  	     	  W10:=',10';
  	     END IF;
  	 	  END IF;
      IF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=9 THEN
      	W5:=',5';
      	W2:=',2,2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=8 THEN
        W5:=',5';
      	W2:=',2';
      	W1:=',1';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=7 THEN
        W5:=',5';
      	W2:=',2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=6 THEN
        W5:=',5';
      	W1:=',1';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=5 THEN
        W5:=',5';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=4 THEN
        W2:=',2,2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=3 THEN
        W2:=',2';
      	W1:=',1';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=2 THEN
        W2:=',2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=1 THEN
        W1:=',1';
      END IF;
     -- Sprawd� d�ugo�� kwoty dla dziesi�tek
    ELSIF NVL(LENGTH( TRUNC(Wydaj) ), 0)=2 THEN
    	IF SUBSTR(Wydaj,INSTR(Wydaj,',')-2,1)=9 THEN
        W50:='50';
        W20:=',20,20';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-2,1)=8 THEN
        W50:='50';
        W20:=',20';
        W10:=',10';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-2,1)=7 THEN
        W50:='50';
        W20:=',20';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-2,1)=6 THEN
        W50:='50';
        W10:=',10';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-2,1)=5 THEN
        W50:='50';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-2,1)=4 THEN
        W20:='20,20';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-2,1)=3 THEN
        W20:='20';
        W10:=',10';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-2,1)=2 THEN
        W20:='20';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-2,1)=1 THEN
        W20:='10';
      END IF;
      IF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=9 THEN
      	W5:=',5';
      	W2:=',2,2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=8 THEN
        W5:=',5';
      	W2:=',2';
      	W1:=',1';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=7 THEN
        W5:=',5';
      	W2:=',2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=6 THEN
        W5:=',5';
      	W1:=',1';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=5 THEN
        W5:=',5';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=4 THEN
        W2:=',2,2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=3 THEN
        W2:=',2';
      	W1:=',1';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=2 THEN
        W2:=',2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=1 THEN
        W1:=',1';
      END IF;
    --Sprawd� z�ot�wki
    ELSIF NVL(LENGTH( TRUNC(Wydaj) ), 0)=1 THEN
    IF REPLACE((SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)),',','0')=0 THEN
    	 W1:='0';
    ELSE
    	IF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=9 THEN
        W50:='5';
        W20:=',2,2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=8 THEN
        W5:='5';
        W2:=',2';
        W1:=',1';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=7 THEN
        W5:='5';
        W2:=',2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=6 THEN
        W5:='5';
        W1:=',1';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=5 THEN
        W5:='5';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=4 THEN
        W2:='2,2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=3 THEN
        W2:='2';
        W1:=',1';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=2 THEN
        W2:='2';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=1 THEN
        W1:='1';
      ELSIF SUBSTR(Wydaj,INSTR(Wydaj,',')-1,1)=',' THEN
        W1:='0';
      END IF;
     END IF;
    END IF;
   -- Sprawd� doa��cz grosze
    IF SUBSTR( TO_CHAR( TRUNC( Wydaj, 2), '999999999.00' ), -2 )<>'XX' THEN
    	Wgr:=','||SUBSTR( TO_CHAR( TRUNC( Wydaj, 2), '999999999.00' ), -2 )||'/100';
    END IF;
    RETURN Tekst||'('||W1000||W200||W100||W50||W20||W10||W5||W2||W1||' z� '||Wgr||' gr'||')';
    END IF;
  END;

  FUNCTION getSQLV(SQLText VARCHAR2, exceptifempty CHAR, Sep VARCHAR2 DEFAULT '|', maxsizeofres NUMBER DEFAULT 30000, singlevaluemode BOOLEAN) RETURN VARCHAR2 IS
    select_cursor   NUMBER;
    n_buffer        VARCHAR2(2000);
	counter         NUMBER;
	result          VARCHAR2(32000);
  BEGIN
    BEGIN
	  result:= '';
      select_cursor:=dbms_sql.open_cursor;
      dbms_sql.parse(select_cursor, SQLText, dbms_sql.v7);
      dbms_sql.define_column(select_cursor,1,n_buffer,2000);
      --dbms_sql.bind_variable(select_cursor,':TOKEN_NUMBER_FIELD',n_number_of_policy);
      counter:=dbms_sql.EXECUTE(select_cursor);

     LOOP
        IF DBMS_SQL.FETCH_ROWS(select_cursor)>0 THEN
          DBMS_SQL.COLUMN_VALUE(select_cursor, 1, n_buffer);
          --dbms_output.put_line ( n_buffer );
		  result := Merge (result, n_buffer, Sep);
		  IF singlevaluemode THEN EXIT; END IF;
		  IF LENGTH( result ) > maxsizeofres THEN EXIT; END IF;
        ELSE
          EXIT;
        END IF;
      END LOOP;
      DBMS_SQL.CLOSE_CURSOR(select_cursor);
	  IF exceptifempty = 'Y' AND result IS NULL THEN RAISE NO_DATA_FOUND; END IF;
	  RETURN NVL(result,valueifempty);
    EXCEPTION
      WHEN OTHERS THEN
        IF DBMS_SQL.IS_OPEN(select_cursor) THEN
          DBMS_SQL.CLOSE_CURSOR(select_cursor);
        END IF;
        RAISE;
    END;
  END;

  FUNCTION getSQLValues(SQLText VARCHAR2, exceptifempty CHAR DEFAULT 'Y', Sep VARCHAR2 DEFAULT '|', maxsizeofres NUMBER DEFAULT 30000) RETURN VARCHAR2 IS
  BEGIN
   RETURN getSQLV(REPLACE(SQLText,'^',''''), exceptifempty, Sep, maxsizeofres, FALSE);
  END;

  FUNCTION getSQLValue(SQLText VARCHAR2, exceptifempty CHAR DEFAULT 'Y') RETURN VARCHAR2 IS
  BEGIN
   RETURN getSQLV(REPLACE(SQLText,'^',''''), exceptifempty, '|', 2000, TRUE);
  END;

  procedure wordWrapInit (aWordWrap in out tWordWrap,adefaultStr varchar2, tokenSeparator VARCHAR2 DEFAULT '|') is
  begin
    aWordWrap.defaultStr := adefaultStr;
	aWordWrap.linesPastedStr.delete;
	aWordWrap.linesFromPos.delete;
	aWordWrap.linesToPos.delete;
	aWordWrap.linesAlign.delete;
	awordWrap.resultLineNum := -1;
	aWordWrap.errorMessage  := null;
	aWordWrap.tokenSeparator  := tokenSeparator;
  end;

  procedure wordWrapPrepareColumn(aWordWrap in out tWordWrap, pastedStr VARCHAR2, placeHolder varchar2, align NUMBER) is
   fromPos number;
   toPos   number;

   tempStr varchar2(2000);
   tempfromPos number;
  begin
   if aWordWrap.errorMessage is not null then return; end if;
   fromPos := inStr(aWordWrap.defaultStr,placeHolder);
   toPos   := fromPos + length(placeHolder)-1;
   if fromPos = 0 then
    aWordWrap.errorMessage := 'Error: Placeholder '||nvl(PlaceHolder,'<empty>')|| ' not found in defaultStr';
	return;
   end if;

   tempStr     := PasteStr(aWordWrap.defaultStr,'.',fromPos,toPos,0);
   tempfromPos := inStr(tempStr,placeHolder);
   if tempfromPos <> 0 then
    aWordWrap.errorMessage := 'Error: Two or more occurences of placeholder '||nvl(PlaceHolder,'<empty>')|| ' in defaultStr';
	return;
   end if;

   -- takie dziwol�gi, bo w plsql nie ma polecenia With
   aWordWrap.linesPastedStr ( aWordWrap.linesPastedStr.count ) := pastedStr;
   aWordWrap.linesfromPos   ( aWordWrap.linesfromPos.count   ) := fromPos;
   aWordWrap.linestoPos     ( aWordWrap.linestoPos.count     ) := toPos;
   aWordWrap.linesalign     ( aWordWrap.linesalign.count     ) := align;
  end;

  function  wordWrapGetNumberOfLines(aWordWrap in out tWordWrap) return number is
  i number;
  maxValue number;

      FUNCTION SingleMax ( N1 NUMBER, N2 NUMBER) RETURN NUMBER IS
      BEGIN
    	IF N1 >= N2 THEN RETURN N1;
    	            ELSE RETURN N2; END IF;
      END;

  begin
    if aWordWrap.errorMessage is not null then return -1; end if;
    i := aWordWrap.linesPastedStr.FIRST;
    maxValue := -99999999999999999999999999999999999;
    WHILE i IS NOT NULL LOOP
      maxValue := SingleMax ( maxValue, WordCount( WordWrap( aWordWrap.linesPastedStr (I), aWordWrap.linestoPos(I) - aWordWrap.linesFromPos(I) + 1, 0, false, aWordWrap.tokenSeparator),aWordWrap.tokenSeparator) );
      --FUNCTION WordWrap( S VARCHAR2, columnWidth NUMBER, getTokenNr NUMBER DEFAULT 0, completeWithSpaces BOOLEAN DEFAULT TRUE, TokenSeparator VARCHAR2 DEFAULT '|') RETURN VARCHAR2
      i := aWordWrap.linesPastedStr.NEXT(i);
    END LOOP;
	awordWrap.resultLineNum := maxValue;
    RETURN maxValue;
  end;

  function  wordWrapGetLine(aWordWrap tWordWrap,lineNum number) return varchar2 is
    returnedStr varchar2(2000);
	i number;
  begin
   if aWordWrap.errorMessage is not null then return aWordWrap.errorMessage; end if;
    if awordWrap.resultLineNum = -1 then -- obiekt nie zosta� prawid�owo zainicjowany
	  return 'funkcja wordWrapGetLine - obiekt nie zosta� prawid�owo zainicjowany';
	end if;

	returnedStr := aWordWrap.defaultStr;
	i := aWordWrap.linesPastedStr.FIRST;
    WHILE i IS NOT NULL LOOP
	  returnedStr:= PasteStr (
	                  returnedStr
	                 ,WordWrap( aWordWrap.linesPastedStr (i), aWordWrap.linestoPos(i) - aWordWrap.linesFromPos(i) + 1, lineNum, false, aWordWrap.tokenSeparator)
                     ,aWordWrap.linesFromPos(i)
                     ,aWordWrap.linesToPos(i)
                     ,aWordWrap.linesAlign(i) );
      i := aWordWrap.linesPastedStr.NEXT(i);
    END LOOP;
	return returnedStr;
  end;

  PROCEDURE amountsInit (amounts IN OUT tAmounts, agroupOperator INTEGER DEFAULT 0) IS
  BEGIN
   Amounts.COUNT := 0;
   Amounts.groupOperator := agroupOperator;
  END;

  PROCEDURE amountsAdd(amounts IN OUT tAmounts, aGroupIndicator VARCHAR2, amount1 NUMBER, amount2 NUMBER DEFAULT 0, amount3 NUMBER DEFAULT 0, amount4 NUMBER DEFAULT 0, amount5 NUMBER DEFAULT 0, amount6 NUMBER DEFAULT 0, amount7 NUMBER DEFAULT 0, amount8 NUMBER DEFAULT 0) IS
    t      INTEGER;
	c      INTEGER;
    FOUND  BOOLEAN;
    groupIndicator  VARCHAR2(100);
  BEGIN
   groupIndicator := aGroupIndicator;
   IF groupIndicator <> 'TOTAL' THEN
     amountsAdd(Amounts, 'TOTAL', amount1, amount2, amount3, amount4, amount5, amount6, amount7, amount8);
   END IF;
   FOUND := FALSE;
   IF groupIndicator IS NULL THEN groupIndicator := '-'; END IF;
   FOR c IN 1..amounts.COUNT LOOP
    IF amounts.groupIndicators(c) = groupIndicator THEN FOUND := TRUE; t:= c; EXIT; END IF;
   END LOOP;

   if found then
    if amounts.groupOperator = 0 then
     amounts.amounts1(t) := amounts.amounts1(t) + nvl(amount1,0);
     amounts.amounts2(t) := amounts.amounts2(t) + nvl(amount2,0);
     amounts.amounts3(t) := amounts.amounts3(t) + nvl(amount3,0);
     amounts.amounts4(t) := amounts.amounts4(t) + nvl(amount4,0);
     amounts.amounts5(t) := amounts.amounts5(t) + nvl(amount5,0);
     amounts.amounts6(t) := amounts.amounts6(t) + nvl(amount6,0);
     amounts.amounts7(t) := amounts.amounts7(t) + nvl(amount7,0);
     amounts.amounts8(t) := amounts.amounts8(t) + nvl(amount8,0);
	elsif amounts.groupOperator = 1 then
     amounts.amounts1(t) := maximum (amounts.amounts1(t) , nvl(amount1,0));
     amounts.amounts2(t) := maximum (amounts.amounts2(t) , nvl(amount2,0));
     amounts.amounts3(t) := maximum (amounts.amounts3(t) , nvl(amount3,0));
     amounts.amounts4(t) := maximum (amounts.amounts4(t) , nvl(amount4,0));
     amounts.amounts5(t) := maximum (amounts.amounts5(t) , nvl(amount5,0));
     amounts.amounts6(t) := maximum (amounts.amounts6(t) , nvl(amount6,0));
     amounts.amounts7(t) := maximum (amounts.amounts7(t) , nvl(amount7,0));
     amounts.amounts8(t) := maximum (amounts.amounts8(t) , nvl(amount8,0));
	elsif amounts.groupOperator = 2 then
     amounts.amounts1(t) := minimum (amounts.amounts1(t) , nvl(amount1,0));
     amounts.amounts2(t) := minimum (amounts.amounts2(t) , nvl(amount2,0));
     amounts.amounts3(t) := minimum (amounts.amounts3(t) , nvl(amount3,0));
     amounts.amounts4(t) := minimum (amounts.amounts4(t) , nvl(amount4,0));
     amounts.amounts5(t) := minimum (amounts.amounts5(t) , nvl(amount5,0));
     amounts.amounts6(t) := minimum (amounts.amounts6(t) , nvl(amount6,0));
     amounts.amounts7(t) := minimum (amounts.amounts7(t) , nvl(amount7,0));
     amounts.amounts8(t) := minimum (amounts.amounts8(t) , nvl(amount8,0));
    end if;
   else
    amounts.count := amounts.count + 1;
    amounts.amounts1(amounts.count)         := nvl(amount1,0);
    amounts.amounts2(amounts.count)         := nvl(amount2,0);
    amounts.amounts3(amounts.count)         := nvl(amount3,0);
    amounts.amounts4(amounts.count)         := nvl(amount4,0);
    amounts.amounts5(amounts.count)         := nvl(amount5,0);
    amounts.amounts6(amounts.count)         := nvl(amount6,0);
    amounts.amounts7(amounts.count)         := nvl(amount7,0);
    amounts.amounts8(amounts.count)         := nvl(amount8,0);
    amounts.groupIndicators(amounts.count) := groupIndicator;
   end if;
  end;

   PROCEDURE amountsGetExample1(Amounts IN OUT TAmounts) IS
     t INTEGER;
     PROCEDURE wout ( s VARCHAR2 ) IS BEGIN dbms_output.put_line ( s ); END;

   BEGIN
    FOR t IN 1..Amounts.COUNT LOOP
     wout ( Amounts.amounts1(t) || ' ' || Amounts.amounts2(t) || ' ' || Amounts.amounts3(t) || ' ' || Amounts.amounts4(t) || ' ' || Amounts.GroupIndicators(t));
    END LOOP;
   END;

	procedure amountsGetExample2 (amounts in out TAmounts) is
     PROCEDURE wout ( s VARCHAR2 ) IS BEGIN dbms_output.put_line ( s ); END;
	begin
	  for L in 2..amounts.count loop -- no 1 is "TOTAL"
	    wout ( amounts.groupIndicators(L)
			|| ' ' || amounts.amounts1(L)
			|| ' ' || amounts.amounts2(L)
			|| ' ' || amounts.amounts3(L) );
	  end loop;

	  if amounts.count-1 > 1 then
	    wout  ('========================================');
	    wout ( amounts.groupIndicators(1)
			|| ' ' || xxmsz_tools.AmountsGetByIndicator (amounts, 'TOTAL', 1)
			|| ' ' || xxmsz_tools.AmountsGetByIndicator (amounts, 'TOTAL', 2)
			|| ' ' || xxmsz_tools.AmountsGetByIndicator (amounts, 'TOTAL', 3)	);
	  end if;
	end;

  FUNCTION amountsGetByIndicator(Amounts IN OUT TAmounts, aGroupIndicator VARCHAR2, AmountIndex NUMBER) RETURN NUMBER IS
    t      INTEGER;
	c      INTEGER;
    FOUND  BOOLEAN;
    GroupIndicator  VARCHAR2(100);
  BEGIN
   GroupIndicator := aGroupIndicator;
   FOUND := FALSE;
   IF GroupIndicator IS NULL THEN GroupIndicator := '-'; END IF;
   FOR c IN 1..Amounts.COUNT LOOP
    IF Amounts.GroupIndicators(c) = GroupIndicator THEN FOUND := TRUE; t:= c; EXIT; END IF;
   END LOOP;

   IF FOUND THEN
     IF amountIndex = 1 THEN RETURN amounts.amounts1(t); END IF;
     IF amountIndex = 2 THEN RETURN amounts.amounts2(t); END IF;
     IF amountIndex = 3 THEN RETURN amounts.amounts3(t); END IF;
     IF amountIndex = 4 THEN RETURN amounts.amounts4(t); END IF;
     IF amountIndex = 5 THEN RETURN amounts.amounts5(t); END IF;
     IF amountIndex = 6 THEN RETURN amounts.amounts6(t); END IF;
     IF amountIndex = 7 THEN RETURN amounts.amounts7(t); END IF;
     IF amountIndex = 8 THEN RETURN amounts.amounts8(t); END IF;
   ELSE
     RETURN 0;
   END IF;
  END;

  function maximum(
     number1  number
   , number2  number
   , number3  number default null
   , number4  number default null
   , number5  number default null
   , number6  number default null
   , number7  number default null
   , number8  number default null
   , number9  number default null
   , number10 number default null
   , number11 number default null
   , number12 number default null
   , number13 number default null
   , number14 number default null
   , number15 number default null
   , number16 number default null
   , number17 number default null
   , number18 number default null
   , number19 number default null
   , number20 number default null
   , number21 number default null
   , number22 number default null
   , number23 number default null
   , number24 number default null
   , number25 number default null
   , number26 number default null
   , number27 number default null
   , number28 number default null
   , number29 number default null
   , number30 number default null  ) return number is
    type  tnumbers is  table  of  number  index  by  binary_integer;
	numbers tnumbers;
	res     number;
	i       number;
        function singlemax ( n1 in out number, n2 in out number) return number is
    	begin
    	 n1 := nvl( n1, -99999999999999999999999999999999999);
    	 n2 := nvl( n2, -99999999999999999999999999999999999);
    	 if n1 >= n2 then return n1;
    	             else return n2; end if;
    	end;
  begin
     numbers ( 1) := number1;
     numbers ( 2) := number2;
     numbers ( 3) := number3;
     numbers ( 4) := number4;
     numbers ( 5) := number5;
     numbers ( 6) := number6;
     numbers ( 7) := number7;
     numbers ( 8) := number8;
     numbers ( 9) := number9;
     numbers (10) := number10;
     numbers (11) := number11;
     numbers (12) := number12;
     numbers (13) := number13;
     numbers (14) := number14;
     numbers (15) := number15;
     numbers (16) := number16;
     numbers (17) := number17;
     numbers (18) := number18;
     numbers (19) := number19;
     numbers (20) := number20;
     numbers (21) := number21;
     numbers (22) := number22;
     numbers (23) := number23;
     numbers (24) := number24;
     numbers (25) := number25;
     numbers (26) := number26;
     numbers (27) := number27;
     numbers (28) := number28;
     numbers (29) := number29;
     numbers (30) := number30;

	 res := -99999999999999999999999999999999999;
	 for i in 1..30 loop
          if numbers (i) is null then exit; end if;
	  res := singlemax ( res, numbers (i) );
	 end loop;
    return res;
  end;

  function minimum(
     number1  number
   , number2  number
   , number3  number default null
   , number4  number default null
   , number5  number default null
   , number6  number default null
   , number7  number default null
   , number8  number default null
   , number9  number default null
   , number10 number default null
   , number11 number default null
   , number12 number default null
   , number13 number default null
   , number14 number default null
   , number15 number default null
   , number16 number default null
   , number17 number default null
   , number18 number default null
   , number19 number default null
   , number20 number default null
   , number21 number default null
   , number22 number default null
   , number23 number default null
   , number24 number default null
   , number25 number default null
   , number26 number default null
   , number27 number default null
   , number28 number default null
   , number29 number default null
   , number30 number default null  ) return number is
    type  tnumbers is  table  of  number  index  by  binary_integer;
	numbers tnumbers;
	res     number;
	i       number;

        function singlemin ( n1 in out number, n2 in out number) return number is
    	begin
    	 n1 := nvl( n1, 99999999999999999999999999999999999);
    	 n2 := nvl( n2, 99999999999999999999999999999999999);
    	 if n1 <= n2 then return n1;
    	             else return n2; end if;
    	end;
  begin
     numbers ( 1) := number1;
     numbers ( 2) := number2;
     numbers ( 3) := number3;
     numbers ( 4) := number4;
     numbers ( 5) := number5;
     numbers ( 6) := number6;
     numbers ( 7) := number7;
     numbers ( 8) := number8;
     numbers ( 9) := number9;
     numbers (10) := number10;
     numbers (11) := number11;
     numbers (12) := number12;
     numbers (13) := number13;
     numbers (14) := number14;
     numbers (15) := number15;
     numbers (16) := number16;
     numbers (17) := number17;
     numbers (18) := number18;
     numbers (19) := number19;
     numbers (20) := number20;
     numbers (21) := number21;
     numbers (22) := number22;
     numbers (23) := number23;
     numbers (24) := number24;
     numbers (25) := number25;
     numbers (26) := number26;
     numbers (27) := number27;
     numbers (28) := number28;
     numbers (29) := number29;
     numbers (30) := number30;

	 res := 99999999999999999999999999999999999;
	 for i in 1..30 loop
          if numbers (i) is null then exit; end if;
	  res := singlemin ( res, numbers (i) );
	 end loop;
    return res;
  end;

  FUNCTION trimSpaces ( S VARCHAR2 ) RETURN VARCHAR IS
    lenBefore NUMBER;
	lenAfter  NUMBER;
	Res       VARCHAR2(30000);
  BEGIN
  IF LENGTH ( S ) > 30000 THEN
    RETURN 'sorry, string too long';
  END IF;
  Res := Trim ( S );
  LOOP
   lenBefore := LENGTH ( Res );
   Res := REPLACE ( Res, '  ', ' ');
   lenAfter := LENGTH ( Res );
   EXIT WHEN lenBefore = lenAfter;
  END LOOP;
  RETURN Res;
  END;

  FUNCTION withoutPolishSigns (S IN VARCHAR2) RETURN VARCHAR2 IS
    res VARCHAR2(1024);
  BEGIN
      res := S;
      res := REPLACE(res, '�', 'A');
      res := REPLACE(res, '�', 'Z');
      res := REPLACE(res, '�', 'C');
      res := REPLACE(res, '�', 'E');
      res := REPLACE(res, '�', 'L');
      res := REPLACE(res, '�', 'N');
      res := REPLACE(res, '�', 'O');
      res := REPLACE(res, '�', 'S');
      res := REPLACE(res, '�', 'Z');
      res := REPLACE(res, '�', 'a');
      res := REPLACE(res, '�', 'c');
      res := REPLACE(res, '�', 'e');
      res := REPLACE(res, '�', 'l');
      res := REPLACE(res, '�', 'n');
      res := REPLACE(res, '�', 'o');
      res := REPLACE(res, '�', 's');
      res := REPLACE(res, '�', 'z');
      res := REPLACE(res, '�', 'z');
      RETURN(res);
  END;

  FUNCTION wordWrap( wrappedString VARCHAR2, columnWidth NUMBER, getTokenNr NUMBER DEFAULT 0, completeWithSpaces BOOLEAN DEFAULT TRUE, TokenSeparator VARCHAR2 DEFAULT '|') RETURN VARCHAR2 IS
   Rest      VARCHAR2(30000);
   Token     VARCHAR2(1000);
   outString VARCHAR2(30000);
   S         VARCHAR2(30000);
   Sentry    number;
  BEGIN
    Sentry := 0;
    S := Replace ( wrappedString, chr(10), TokenSeparator); -- ch(10) jest zawsze separatorem linii

    IF LENGTH ( S ) > 30000 THEN
      RETURN 'sorry, string too long';
    END IF;
   outString := '';
   Rest := S;

   LOOP
     Sentry := Sentry + 1;
	 if INSTR( rest, TokenSeparator ) <> 0                     --   je�eli znaleziono znak ko�ca wiersza
	   and INSTR( rest, TokenSeparator )-1 <= columnWidth then -- i jesli pierwszy wiersz bez znaku konca wiersza zmiesci sie w kolumnie, to go wez
       Token := SUBSTR( rest, 1, INSTR( rest, TokenSeparator )-1); -- to wez
       Rest  := SUBSTR( rest,    INSTR( rest, TokenSeparator )+1, 30000);
     else
       Token := SUBSTR( rest, 1, columnWidth); -- w przeciwnym wypadku wez to co zmiesci sie w pierwszej kolumnie
       Rest  := SUBSTR( rest,    columnWidth + 1, 30000);

       -- to jeszcze nie jest ostateczny podzial na token i rest.
	   -- moze nastapic odciecie czesci tokena po spacji lub myslniku i doklejenie go z powrotem do rest
       -- dfdgdfgdf dfgdfgd|fgd-- jesli ostatni znak tokena i pierwszy znak reszty sa literami* to jesli w tokenie jest spacja/myslnik, to znajdz piersza od konca i przytnij token
	   --    * - dok�adnie: jest innym znakiem niz spacja, myslnik, kropka, znak konca wiersza
       IF SUBSTR( token, LENGTH(token), 1) not in (' ','-','.',TokenSeparator) AND SUBSTR(rest, 1, 1) not in ( ' ','-','.',TokenSeparator) THEN
	     IF REPLACE(REPLACE( REPLACE(SUBSTR(token,2,30000),' ',''), '-', ''),'.', '')  <> SUBSTR(token,2,30000) THEN -- jest spacja/myslnik czyli mozna zawijac
	       DECLARE
		    spacePos1 NUMBER;
		    spacePos2 NUMBER;
		    spacePos3 NUMBER;
		    spacePos  NUMBER;
		    newToken  VARCHAR2(1000);
		    restToken VARCHAR2(1000);
		   BEGIN
		     spacePos1  := INSTR(token,' ',-1);
		     spacePos2  := INSTR(token,'-',-1);
		     spacePos3  := INSTR(token,'.',-1);
		     spacePos   := Maximum (spacePos1, spacePos2,spacePos3); -- pierwszy od konca myslnik lub spacja
	         newToken   := SUBSTR(token, 1, spacePos);
		     restToken  := SUBSTR(token, spacePos+1, 30000);
		     --dbms_output.put_line('newToken='||newToken);
		     --dbms_output.put_line('restToken='||restToken);
		     Token := newToken;
		     Rest := Merge( restToken, Rest, ''); --doklejenie z powrotem fragmentu tokenu to pozosta�ej czesci
		   END;
	     END IF;
	   END IF;

	 end if;

	 IF completeWithSpaces THEN
       outString := Merge ( outString, SUBSTR(merge(Token, MakeStr(' ',columnWidth)),1,columnWidth), TokenSeparator);
	 ELSE
       outString := Merge ( outString, SUBSTR(Token,1,columnWidth), TokenSeparator);
	 END IF;
     EXIT WHEN (rest IS NULL) or (Sentry = 1000);
   END LOOP;
   If Sentry = 1000 then
    RETURN 'Error in WordWrap';
   ELSE
     IF getTokenNr = 0 THEN RETURN outString;
                       ELSE RETURN ExtractWord(getTokenNr, outString, TokenSeparator); END IF;
   END IF;
  END;

  FUNCTION makeStr(s VARCHAR2, len NUMBER) RETURN VARCHAR2 IS
    res VARCHAR2(30000);
  BEGIN
   IF s IS NULL OR len < 1 THEN
     RETURN 'input data error';
   END IF;
   res := s;
   LOOP
     res := merge(res,s);
     EXIT WHEN LENGTH(res) >= len;
   END LOOP;
   RETURN SUBSTR(res,1,len);
  END;

  FUNCTION pasteStr( Str VARCHAR2, pastedStr VARCHAR2, fromPos NUMBER, toPos NUMBER, align NUMBER ) RETURN VARCHAR2 IS
   aPastedStr VARCHAR2(30000);
  BEGIN
   IF align = 0 THEN aPastedStr := RPAD(NVL(PastedStr,' '), toPos - fromPos + 1, ' '); END IF;
   IF align = 1 THEN aPastedStr := LPAD(NVL(PastedStr,' '), toPos - fromPos + 1, ' '); END IF;
   IF align = 2 THEN aPastedStr := Center (pastedStr, toPos - fromPos + 1); END IF;
   RETURN SUBSTR(str,1,fromPos-1) || aPastedStr || SUBSTR(str,toPos+1, 30000);
  END;

  FUNCTION ynToBool ( S VARCHAR2, resultIfEmpty BOOLEAN DEFAULT FALSE ) RETURN BOOLEAN IS
  BEGIN
   IF S IS NULL THEN RETURN resultIfEmpty; ELSE
     RETURN UPPER(S) IN ('TAK','YES','T','Y');
   END IF;
  END;

  FUNCTION erasePolishHooks(S VARCHAR2) RETURN VARCHAR2 IS
  	S2 VARCHAR2(3000);
  BEGIN
    S2 := S;
    S2 := REPLACE(S2,'�','E');
    S2 := REPLACE(S2,'�','O');
    S2 := REPLACE(S2,'�','A');
    S2 := REPLACE(S2,'�','S');
    S2 := REPLACE(S2,'�','L');
    S2 := REPLACE(S2,'�','Z');
    S2 := REPLACE(S2,'�','Z');
    S2 := REPLACE(S2,'�','C');
    S2 := REPLACE(S2,'�','N');
    S2 := REPLACE(S2,'�','e');
    S2 := REPLACE(S2,'�','o');
    S2 := REPLACE(S2,'�','a');
    S2 := REPLACE(S2,'�','s');
    S2 := REPLACE(S2,'�','l');
    S2 := REPLACE(S2,'�','z');
    S2 := REPLACE(S2,'�','z');
    S2 := REPLACE(S2,'�','c');
    S2 := REPLACE(S2,'�','n');

    RETURN S2;
  END;

  FUNCTION boolToYN ( bool boolean, trueValue varchar2 default 'Y', falseValue varchar2 default 'N' ) RETURN varchar2 is
  begin
   if bool then return trueValue;
           else return falseValue; end if;
  end;

  FUNCTION formatIBAN ( inS VARCHAR2, numberOfSignsInSection number default 4, formatOnlyWhenDivisible varchar2 default 'N' ) RETURN VARCHAR2 IS
  res VARCHAR2(500);
  n INTEGER;
  S VARCHAR2(500);
  BEGIN
    s := REPLACE(inS,' ','');
    if YNToBool ( formatOnlyWhenDivisible ) then
      IF LENGTH(s) MOD numberOfSignsInSection <> 0 THEN RETURN s; END IF;
    end if;

    n := 0;
    LOOP
      EXIT WHEN NVL(LENGTH(SUBSTR(s,1 + n * numberOfSignsInSection ,numberOfSignsInSection)),0) = 0;
      res := Xxmsz_Tools.merge( res, SUBSTR(s,1 + n * numberOfSignsInSection ,numberOfSignsInSection), ' ');
      n := n + 1;
    END LOOP;
    RETURN res;
  END;

  FUNCTION formatNIP  ( inS VARCHAR2 ) RETURN VARCHAR2 is
  S VARCHAR2(100);
  BEGIN
    if inS is null then return null; end if;
    s := REPLACE(inS,' ','');
    s := REPLACE(inS,'-','');
    if inS <> s then return inS ;
                else RETURN SUBSTR(s,1,3) || '-' || SUBSTR(s,4,3) || '-' || SUBSTR(s,7,2) || '-' || SUBSTR(s,9,2); end if;
  END;

  function strToNumber ( str varchar2 ) return number is
   res number;
  begin
   begin
     res := to_number (nvl(str,'0')); -- konwertuj na liczbe
   exception
    when others then
	 begin
       res := to_number (nvl(replace(str,',','.'),'0')); -- a jesli sie nie udalo, to zamien ,->. i konweruj na liczbe
	 exception
	   when others then
         res := to_number (nvl(replace(str,'.',','),'0')); -- a jesli sie nie udalo, to zamien .->, i konweruj na liczbe
		                                                   -- a jesli sie nie udalo, to blad
	 end;
   end;
   return res;
  end;

  procedure pushModuleName ( moduleName varchar2 ) is
  begin
    moduleNameForEventLog := pushLastWord(moduleName,moduleNameForEventLog, '.');
  end;

  procedure popModuleName is
  begin
    moduleNameForEventLog := popLastWord(moduleNameForEventLog,'.');
  end;

  procedure setModuleName ( moduleName varchar2 ) is
  begin
    moduleNameForEventLog := moduleName;
  end;

  procedure insertIntoEventLog ( message varchar2, messageType varchar2 default null, moduleName varchar2 default null, writeMessage varchar2 default 'Yes', raiseExceptions varchar2 default 'No') is
  pragma autonomous_transaction;
  begin
   if not xxmsz_tools.ynToBool ( writeMessage , true) then return; end if;
   begin
     execute immediate 'insert into xxmsztools_eventlog (id, module_name, message, message_type) values (xxmsztools_eventlog_seq.nextval, '''|| NVL(moduleName,moduleNameForEventLog) || ''',''' || message || ''',''' ||  messageType || ''')';
     commit;
   exception
     when others then
	   if xxmsz_tools.ynToBool ( raiseExceptions, false ) then raise; end if;
   end;
  end;

  PROCEDURE dbms_outputPut_line (
      str         IN   VARCHAR2,
      len         IN   INTEGER := 254,
      expand_in   IN   BOOLEAN := TRUE
   )
   IS
      v_len   PLS_INTEGER     := LEAST (len, 255);
      v_str   VARCHAR2 (2000);
   BEGIN
      IF LENGTH (str) > v_len
      THEN
         v_str := SUBSTR (str, 1, v_len);
         DBMS_OUTPUT.put_line (v_str);
         dbms_outputPut_line (SUBSTR (str, len   + 1), v_len,expand_in);
      ELSE
         v_str := str;
         DBMS_OUTPUT.put_line (v_str);
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         IF expand_in
         THEN
            DBMS_OUTPUT.ENABLE (1000000);
            DBMS_OUTPUT.put_line (v_str);
         ELSE
            RAISE;
         END IF;
   END;

function strToAsc ( strString varchar2 ) return varchar2 is
 res varchar2(30000);
begin
  res := null;
  for i in 1..length( strString ) loop
    res :=  xxmsz_tools.merge(res, ascii( substr(strString,i,1) ),',');
  end loop;
  return res;
end;

function ascToStr ( ascString varchar2 ) return varchar2 is
 res varchar2(30000);
begin
  res := null;
  for i in 1..xxmsz_tools.wordCount (AscString, ',') loop
    res :=  res || chr( xxmsz_tools.extractWord(i, AscString, ',') );
  end loop;
  return res;
end;


END;
/

CREATE OR REPLACE FUNCTION "ISSUBSETOF" (Set1 VARCHAR2, Set2 VARCHAR2) return VARCHAR2 is
    T INTEGER;
    NOT_FOUND BOOLEAN;
    ELEMENT VARCHAR2(100);
	workSet2 VARCHAR2(5000);
  BEGIN
    workSet2 := ';' || set2 || ';';
    NOT_FOUND := FALSE;
    T := 1;
    ELEMENT := EXTRACTWORD(1,SET1,';');
    WHILE (NVL(ELEMENT,'<EMPTY>') <> '<EMPTY>') AND (NOT_FOUND = FALSE) LOOP
      IF INSTR(workSet2, ';' || ELEMENT || ';') = 0 THEN
        NOT_FOUND := TRUE;
      END IF;
      T := T + 1;
      ELEMENT := EXTRACTWORD(T,SET1,';');
    END LOOP;
    IF NOT_FOUND THEN
       RETURN 'N';
    ELSE
       RETURN 'Y';
    END IF;
  END;
/

show errors;

commit;
spool off
