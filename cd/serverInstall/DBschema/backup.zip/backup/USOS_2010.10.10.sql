grant select on sys.cdef$ to usos_prod_tab;
grant select on sys.con$ to usos_prod_tab;
grant select on sys.obj$ to usos_prod_tab;
grant select on sys.user$  to usos_prod_tab;
 
grant select on sys.cdef$ to Adminrol;
grant select on sys.con$ to Adminrol;
grant select on sys.obj$ to Adminrol;
grant select on sys.user$  to Adminrol;


alter table DZ_BUDYNKI                  add ( feeder_system_name varchar2(60) );       
alter table DZ_BUDYNKI_JED_ORG          add ( feeder_system_name varchar2(60) );      
alter table DZ_CYKLE_DYDAKTYCZNE        add ( feeder_system_name varchar2(60) );   
alter table DZ_ELEM_GRUP_PRZEDMIOTOW    add ( feeder_system_name varchar2(60) );   
alter table DZ_GRUPY                    add ( feeder_system_name varchar2(60) );
alter table DZ_GRUPY_PRZEDMIOTOW        add ( feeder_system_name varchar2(60) );           
alter table DZ_JEDNOSTKI_ORGANIZACYJNE  add ( feeder_system_name varchar2(60) );        
alter table DZ_OSOBY                    add ( feeder_system_name varchar2(60) );      
alter table DZ_PRACOWNICY               add ( feeder_system_name varchar2(60) );           
alter table DZ_PRZEDMIOTY               add ( feeder_system_name varchar2(60) );   
alter table DZ_PRZEDMIOTY_CYKLI         add ( feeder_system_name varchar2(60) );
alter table DZ_SALE                     add ( feeder_system_name varchar2(60) );            
alter table DZ_TERMINY                  add ( feeder_system_name varchar2(60) );      
alter table DZ_TERMINY_GRUP             add ( feeder_system_name varchar2(60) );
alter table DZ_TERMINY_GRUP_SPTK        add ( feeder_system_name varchar2(60) );
alter table DZ_TYPY_PROTOKOLOW          add ( feeder_system_name varchar2(60) );
alter table DZ_TYPY_ZAJEC               add ( feeder_system_name varchar2(60) );          
alter table DZ_ZAJECIA_CYKLI            add ( feeder_system_name varchar2(60) );

alter table DZ_BUDYNKI                  add ( feeder_system_ref varchar2(20) );       
alter table DZ_BUDYNKI_JED_ORG          add ( feeder_system_ref varchar2(20) );      
alter table DZ_CYKLE_DYDAKTYCZNE        add ( feeder_system_ref varchar2(20) );   
alter table DZ_ELEM_GRUP_PRZEDMIOTOW    add ( feeder_system_ref varchar2(20) );   
alter table DZ_GRUPY                    add ( feeder_system_ref varchar2(20) );
alter table DZ_GRUPY_PRZEDMIOTOW        add ( feeder_system_ref varchar2(20) );           
alter table DZ_JEDNOSTKI_ORGANIZACYJNE  add ( feeder_system_ref varchar2(20) );        
alter table DZ_OSOBY                    add ( feeder_system_ref varchar2(20) );      
alter table DZ_PRACOWNICY               add ( feeder_system_ref varchar2(20) );           
alter table DZ_PRZEDMIOTY               add ( feeder_system_ref varchar2(20) );   
alter table DZ_PRZEDMIOTY_CYKLI         add ( feeder_system_ref varchar2(20) );
alter table DZ_SALE                     add ( feeder_system_ref varchar2(20) );            
alter table DZ_TERMINY                  add ( feeder_system_ref varchar2(20) );      
alter table DZ_TERMINY_GRUP             add ( feeder_system_ref varchar2(20) );
alter table DZ_TERMINY_GRUP_SPTK        add ( feeder_system_ref varchar2(20) );
alter table DZ_TYPY_PROTOKOLOW          add ( feeder_system_ref varchar2(20) );
alter table DZ_TYPY_ZAJEC               add ( feeder_system_ref varchar2(20) );          
alter table DZ_ZAJECIA_CYKLI            add ( feeder_system_ref varchar2(20) );

comment on column DZ_BUDYNKI.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';
comment on column DZ_BUDYNKI_JED_ORG.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';     
comment on column DZ_CYKLE_DYDAKTYCZNE.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES'; 
comment on column DZ_ELEM_GRUP_PRZEDMIOTOW.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';  
comment on column DZ_GRUPY.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';
comment on column DZ_GRUPY_PRZEDMIOTOW.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';        
comment on column DZ_JEDNOSTKI_ORGANIZACYJNE.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';       
comment on column DZ_OSOBY.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';  
comment on column DZ_PRACOWNICY.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';           
comment on column DZ_PRZEDMIOTY.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';  
comment on column DZ_PRZEDMIOTY_CYKLI.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';
comment on column DZ_SALE.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';         
comment on column DZ_TERMINY.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';     
comment on column DZ_TERMINY_GRUP.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';
comment on column DZ_TERMINY_GRUP_SPTK.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';
comment on column DZ_TYPY_PROTOKOLOW.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';
comment on column DZ_TYPY_ZAJEC.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';         
comment on column DZ_ZAJECIA_CYKLI.feeder_system_name is 'Nazwa zewn�trznego systemu, kt�ry wstawi� ten rekord w formacie system.nazwa tabeli np. PLAN.CLASSES';

comment on column DZ_BUDYNKI.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';
comment on column DZ_BUDYNKI_JED_ORG.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';     
comment on column DZ_CYKLE_DYDAKTYCZNE.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord'; 
comment on column DZ_ELEM_GRUP_PRZEDMIOTOW.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';  
comment on column DZ_GRUPY.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';
comment on column DZ_GRUPY_PRZEDMIOTOW.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';        
comment on column DZ_JEDNOSTKI_ORGANIZACYJNE.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';       
comment on column DZ_OSOBY.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';  
comment on column DZ_PRACOWNICY.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';           
comment on column DZ_PRZEDMIOTY.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';  
comment on column DZ_PRZEDMIOTY_CYKLI.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';
comment on column DZ_SALE.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';         
comment on column DZ_TERMINY.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';     
comment on column DZ_TERMINY_GRUP.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';
comment on column DZ_TERMINY_GRUP_SPTK.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';
comment on column DZ_TYPY_PROTOKOLOW.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';
comment on column DZ_TYPY_ZAJEC.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';         
comment on column DZ_ZAJECIA_CYKLI.feeder_system_ref is 'Id rekordu z zewn�trznego systemu, kt�ry wstawi� ten rekord';


--2010.10.27 Ten techniczny budynek juz nie jest potrzebny, poprawiono procedur� importuj�c�
insert into dz_budynki
( 
  kod                            --kod                           |varchar2:60    |REQ|Kod lokalizacji               |                                        
, nazwa                          --nazwa                         |varchar2:300   |REQ|Nazwa lokalizacji             |                                        
, szerokosc_geo                  --szerokosc_geo                 |number:22      |OPT|Szeroko�� geograficzna budynku|                                        
, dlugosc_geo                    --dlugosc_geo                   |number:22      |OPT|D�ugo�� geograficzna budynku (|                                        
, kamp_kod                       --kamp_kod                      |varchar2:60    |OPT|Kod kampusu, do kt�rego nale�y|fk dz_kampusy.kod                       
, feeder_system_name             --feeder_system_name            |varchar2:60    |OPT|                                        
, feeder_system_ref              --feeder_system_name            |varchar2:60    |OPT|
, utw_data,utw_id,mod_data,mod_id
) 
values 
( 
  'PLANNER'                      --kod                           |varchar2:60    |REQ|Kod lokalizacji               |                                        
, 'PLANNER'                      --nazwa                         |varchar2:300   |REQ|Nazwa lokalizacji             |                                        
, NULL                           --szerokosc_geo                 |number:22      |OPT|Szeroko�� geograficzna budynku|                                        
, NULL                           --dlugosc_geo                   |number:22      |OPT|D�ugo�� geograficzna budynku (|                                        
, NULL                           --kamp_kod                      |varchar2:60    |OPT|Kod kampusu, do kt�rego nale�y|fk dz_kampusy.kod                       
, 'PLAN'                         --feeder_system_name            |varchar2:60    |OPT|                                        
, '-1'                           --feeder_system_name            |varchar2:60    |OPT|
, sysdate,'PLANNER',sysdate,'PLANNER'
) 
/


insert into dz_budynki_jed_org
( 
  bud_kod                        --bud_kod                       |varchar2:60    |REQ|Kod budynku                   |fk dz_budynki.kod                       
, jed_org_kod                    --jed_org_kod                   |varchar2:60    |REQ|Kod jednostki                 |fk dz_jednostki_organizacyjne.kod       
, czy_glowny                     --czy_glowny                    |varchar2:3     |REQ|Czy budynek jest budynkiem g��|                                        
, feeder_system_name             --feeder_system_name            |varchar2:60    |OPT|                                        
, feeder_system_ref              --feeder_system_name            |varchar2:60    |OPT|
, utw_data,utw_id,mod_data,mod_id
) 
values 
( 
  'PLANNER'                      --bud_kod                       |varchar2:60    |REQ|Kod budynku                   |fk dz_budynki.kod                       
, (select KOD from DZ_JEDNOSTKI_ORGANIZACYJNE@usos where kod = '00000')
                                 --jed_org_kod                   |varchar2:60    |REQ|Kod jednostki                 |fk dz_jednostki_organizacyjne.kod       
, 'T'                            --czy_glowny                    |varchar2:3     |REQ|Czy budynek jest budynkiem g��|                                        
, 'PLAN'             --feeder_system_name            |varchar2:60    |OPT|                                        
, '-1'              --feeder_system_name            |varchar2:60    |OPT|
, sysdate,'PLANNER',sysdate,'PLANNER'
);



insert into dz_cykle_dydaktyczne
( 
  kod                            --kod                           |varchar2:60    |REQ|Kod cyklu                     |                                        
, opis                           --opis                          |varchar2:300   |REQ|Nazwa cyklu dydaktycznego     |                                        
, data_od                        --data_od                       |date           |REQ|Data pocz�tku cyklu dydaktyczn|                                        
, data_do                        --data_do                       |date           |REQ|Data ko�ca cyklu dydaktycznego|                                        
, czy_wyswietlac                 --czy_wyswietlac                |varchar2:3     |REQ|Czy wy�wietla� - Parametr WWW |                                        
, data_zakon                     --data_zakon                    |date           |REQ|Data zako�czenia              |                                        
, tcdyd_kod                      --tcdyd_kod                     |varchar2:60    |REQ|Kod typu cyklu                |fk dz_typy_cykli_dydaktycznych.kod      
, status_cyklu                   --status_cyklu                  |varchar2:3     |REQ|Status cyklu                  |                                        
, description                    --description                   |varchar2:300   |OPT|Opis cyklu w j�zyku angielskim|                                        
, feeder_system_name             --feeder_system_name            |varchar2:60    |OPT|                                        
, feeder_system_ref              --feeder_system_name            |varchar2:60    |OPT|
, utw_data,utw_id,mod_data,mod_id
) 
values 
( 
  'PLANNER'                      --kod                           |varchar2:60    |REQ|Kod cyklu                     |                                        
, 'PLANNER - Semestr dla okresu przej�ciowego'                         
                                 --opis                          |varchar2:300   |REQ|Nazwa cyklu dydaktycznego     |                                        
, DATE'2000-01-01'               --data_od                       |date           |REQ|Data pocz�tku cyklu dydaktyczn|                                        
, DATE'2011-12-31'               --data_do                       |date           |REQ|Data ko�ca cyklu dydaktycznego|                                        
, 'T'                            --czy_wyswietlac                |varchar2:3     |REQ|Czy wy�wietla� - Parametr WWW |                                        
, DATE'2011-12-31'               --data_zakon                    |date           |REQ|Data zako�czenia              |                                        
, (select KOD from DZ_TYPY_CYKLI_DYDAKTYCZNYCH where kod = 'sem')
                                 --tcdyd_kod                     |varchar2:60    |REQ|Kod typu cyklu                |fk dz_typy_cykli_dydaktycznych.kod      
, 'A'                            --status_cyklu                  |varchar2:3     |REQ|Status cyklu                  |                                        
, NULL                           --description                   |varchar2:300   |OPT|Opis cyklu w j�zyku angielskim|                                        
, 'PLAN'                         --feeder_system_name            |varchar2:60    |OPT|                                        
, '-1'                           --feeder_system_name            |varchar2:60    |OPT|
, sysdate,'PLANNER',sysdate,'PLANNER'
);



commit

