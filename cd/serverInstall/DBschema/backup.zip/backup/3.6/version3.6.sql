  create global temporary table tmp_numbers ( id number ) on commit delete rows;
  create table tmp_varchar2 ( sessionid number, param varchar2(240), value varchar2(240) );
  create public synonym tmp_numbers for tmp_numbers;
  create public synonym tmp_varchar2 for tmp_varchar2;
  create index lookups_i1 on planner.lookups (VALUE_SET_ID);
Drop table res_str_elems;
Drop public synonym res_str_elems;
Drop sequence res_str_elems_seq;
Drop public synonym res_str_elems_seq;

create table res_str_elems
(id        number primary key
,parent_id number
,child_id  number
,str_name_lov varchar2(100) default 'STREAM'
);
create index resstrelem1 on res_str_elems (parent_id);
create index resstrelem2 on res_str_elems (child_id);
create unique index resstrelem3 on res_str_elems (parent_id, child_id, str_name_lov);
create sequence res_str_elems_seq;
create or replace view res_str_elems_v as
select 
  res_str_elems.*
  ,(select name from rooms where id = child_id) child_dsp 
  ,(select name from rooms where id = parent_id) parent_dsp
  from res_str_elems;
create public synonym res_str_elems for res_str_elems;
create public synonym res_str_elems_seq for res_str_elem_seqs;  
create public synonym res_str_elems_v for res_str_elems_v;

 
create table gro_str_elems
(id        number primary key
,parent_id number
,child_id  number
,str_name_lov varchar2(100) default 'STREAM'
);
create index grostrelem1 on gro_str_elems (parent_id);
create index grostrelem2 on gro_str_elems (child_id);
create unique index grostrelem3 on gro_str_elems (parent_id, child_id, str_name_lov);
create sequence gro_str_elems_seq;
create or replace view gro_str_elems_v as
select 
  gro_str_elems.*
  ,(select abbreviation||' '||name from groups where id = child_id) child_dsp 
  ,(select abbreviation||' '||name from groups where id = parent_id) parent_dsp
  from gro_str_elems;
create public synonym gro_str_elems for gro_str_elems;
create public synonym gro_str_elems_seq for gro_str_elem_seqs;  
create public synonym gro_str_elems_v for gro_str_elems_v;



create table lec_str_elems
(id        number primary key
,parent_id number
,child_id  number
,str_name_lov varchar2(100) default 'STREAM'
);
create index lecstrelem1 on lec_str_elems (parent_id);
create index lecstrelem2 on lec_str_elems (child_id);
create unique index lecstrelem3 on lec_str_elems (parent_id, child_id, str_name_lov);
create sequence lec_str_elems_seq;
create or replace view lec_str_elems_v as
select 
  lec_str_elems.*
  ,(select  title||' '||last_name||' '||first_name  from lecturers where id = child_id) child_dsp 
  ,(select  title||' '||last_name||' '||first_name  from lecturers where id = parent_id) parent_dsp
  from lec_str_elems;
create public synonym lec_str_elems for lec_str_elems;
create public synonym lec_str_elems_seq for lec_str_elem_seqs;  
create public synonym lec_str_elems_v for lec_str_elems_v;



