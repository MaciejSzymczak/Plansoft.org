UPDATE SYSTEM_PARAMETERS SET VALUE = '3.6' WHERE NAME = 'PLANOWANIE.VERSION_INFO';

COMMIT;


alter table lec_str_elems add (constraint lec_str_elem_fk1 foreign key (parent_id) references lecturers (id) );
alter table lec_str_elems add (constraint lec_str_elem_fk2 foreign key (child_id) references lecturers (id) );
alter table gro_str_elems add (constraint gro_str_elem_fk1 foreign key (parent_id) references groups (id) );
alter table gro_str_elems add (constraint gro_str_elem_fk2 foreign key (child_id) references groups (id) );
alter table res_str_elems add (constraint res_str_elem_fk1 foreign key (parent_id) references rooms (id) );
alter table res_str_elems add (constraint res_str_elem_fk2 foreign key (child_id) references rooms (id) );

create table sub_pla
(
  id      number(10),
  sub_id  number(10),
  pla_id  number(10)
);

create index subpla_sub_fk_i on sub_pla(sub_id);
create unique index subpla_pk on sub_pla (id);
create index subpla_pla_fk_i on sub_pla (pla_id);
create public synonym sub_pla for sub_pla;
alter table sub_pla add (constraint subpla_pk primary key (id));
alter table sub_pla add (  constraint subpla_lec_fk  foreign key (sub_id)  references subjects (id) on delete cascade);
alter table sub_pla add ( constraint subpla_pla_fk foreign key (pla_id)  references planners (id) on delete cascade);

create table for_pla
(
  id      number(10),
  for_id  number(10),
  pla_id  number(10)
);

create index forpla_for_fk_i on for_pla(for_id);
create unique index forpla_pk on for_pla (id);
create index forpla_pla_fk_i on for_pla (pla_id);
create public synonym for_pla for for_pla;
alter table for_pla add (constraint forpla_pk primary key (id));
alter table for_pla add (  constraint forpla_lec_fk  foreign key (for_id)  references forms (id) on delete cascade);
alter table for_pla add ( constraint forpla_pla_fk foreign key (pla_id)  references planners (id) on delete cascade);

create sequence subpla_seq;
create sequence forpla_seq;
create public synonym subpla_seq for subpla_seq;
create public synonym forpla_seq for forpla_seq;

insert into value_sets (id, name, set_type, min_length, max_length, who_creation_date, who_last_update_date, who_created_by, who_last_updated_by, who_last_update_login) values (value_sets_seq.nextval , 'FORM_TYPE', 'LOOKUP', 0, 32000, sysdate, sysdate, 'PLANNER', 'PLANNER', 1426);
insert into lookups (id, value_set_id, lookup_type, code, meaning, enabled, who_creation_date, who_last_update_date, who_created_by, who_last_updated_by, who_last_update_login) values (lookups_seq.nextval, value_sets_seq.currval, 'FORM_TYPE', 'R', 'Rezerwacja', 'Y', sysdate, sysdate, 'PLANNER', 'PLANNER', 1426);
insert into lookups (id, value_set_id, lookup_type, code, meaning, enabled, who_creation_date, who_last_update_date, who_created_by, who_last_updated_by, who_last_update_login) values (lookups_seq.nextval, value_sets_seq.currval, 'FORM_TYPE', 'C', 'Zaj�cia', 'Y', sysdate, sysdate, 'PLANNER', 'PLANNER', 1426);

alter table planner.rooms add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

drop table flex_col_usage;

--alter table PLANNER.FLEX_COL_USAGE add (custom_name varchar2(240))
--alter table PLANNER.FLEX_COL_USAGE drop (name )

create table planner.flex_col_usage
(
  id                  number primary key,
  form_name           varchar2(255 byte) not null,
  context_name        varchar2(255 byte) default 'DEFAULT',
  attr_name           varchar2(10 byte) not null,
  custom_name         varchar2(240 byte) not null,
  caption             varchar2(240 byte) not null,
  width               number,
  value_set_id        number,
  sql_default_value   varchar2(240 byte),
  sql_check_procedure varchar2(240 byte),
  sql_check_message   varchar2(240 byte),
  required            varchar2(1 byte) default '-',
  label_pos_x         number(5),
  label_pos_y         number(5),
  field_pos_x         number(5),
  field_pos_y         number(5),
  show_in_list        varchar2(1 byte) default '+',
  show_in_where       varchar2(1 byte) default '+',
  show_in_order_by    varchar2(1 byte) default '+',
  system_flag         varchar2(1 byte) default '-'
);


begin
delete from flex_col_usage; 
insert into flex_col_usage (id, form_name, context_name, attr_name, caption, width, required, label_pos_x, label_pos_y, field_pos_x, field_pos_y, custom_name, show_in_list, system_flag)
                    values (1, 'FBrowseROOMS', 'Sale', 'ATTRIBS_01', 'Budynek', 300, '-', 0, 16, 89, 8, 'BUILDING', '+', '+');
insert into flex_col_usage (id, form_name, context_name, attr_name, caption, width, required, label_pos_x, label_pos_y, field_pos_x, field_pos_y, custom_name, show_in_list, system_flag)
                    values (2, 'FBrowseROOMS', 'Sale', 'ATTRIBN_01', 'Pojemno��', 100, '-', 517, 16, 605, 8, 'CAPACITY', '+', '+');
commit;
end;

update rooms set attribs_01 = building;
update rooms set attribn_01 = number_of_peoples;
commit

create sequence flex_col_usage_seq start with 200;
create public synonym flex_col_usage for flex_col_usage;
create public synonym flex_col_usage_seq for flex_col_usage_seq;
alter table flex_col_usage add CONSTRAINT FLEX_VALS_FK FOREIGN KEY (value_set_id) REFERENCES VALUE_SETS (ID);
create unique index flex_ui on flex_col_usage ( FORM_NAME, context_name, attr_name )

alter table planner.flex_col_usage add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

alter table planner.subjects add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

alter table planner.forms add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

alter table planner.lecturers add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

alter table planner.groups add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

alter table planner.periods add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

alter table planner.planners add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

alter table planner.resource_categories add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

alter table planner.lookups add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

alter table planner.ORG_UNITS add(
 attribs_01 varchar2(240),attribs_02 varchar2(240),attribs_03 varchar2(240),attribs_04 varchar2(240),attribs_05 varchar2(240),attribs_06 varchar2(240),attribs_07 varchar2(240),attribs_08 varchar2(240),attribs_09 varchar2(240),attribs_10 varchar2(240),attribs_11 varchar2(240),attribs_12 varchar2(240),attribs_13 varchar2(240),attribs_14 varchar2(240),attribs_15 varchar2(240)
,attribd_01 date,attribd_02 date,attribd_03 date,attribd_04 date,attribd_05 date,attribd_06 date,attribd_07 date,attribd_08 date,attribd_09 date,attribd_10 date,attribd_11 date,attribd_12 date,attribd_13 date,attribd_14 date,attribd_15 date
,attribn_01 number,attribn_02 number,attribn_03 number,attribn_04 number,attribn_05 number,attribn_06 number,attribn_07 number,attribn_08 number,attribn_09 number,attribn_10 number,attribn_11 number,attribn_12 number,attribn_13 number,attribn_14 number,attribn_15 number
);

create or replace trigger planner.rooms_temporary_trg
before insert or update on planner.rooms
referencing new as new old as old for each row
begin
 :new.building :=  :new.attribs_01;
 :new.number_of_peoples := :new.attribn_01;
end rooms_temporary_trg;

begin
delete from SUB_PLA;
delete from FOR_PLA;
for rec in (select id from planners)
loop
  insert into sub_pla (id, sub_id, pla_id)
  select SUBPLA_SEQ.nextval, id, rec.id from subjects;
end loop;
for rec in (select id from planners)
loop
  insert into for_pla (id, for_id, pla_id)
  select FORPLA_SEQ.nextval, id, rec.id from forms;
end loop;
commit;
end;


create table tmp_selected_dates
(day             date      not null
,hour            number(2) not null
,created         date      default sysdate not null 
,sessionid       number    default userenv('SESSIONID') not null 
);

create public synonym tmp_selected_dates for tmp_selected_dates;


alter table planners add ( colour integer );
alter table classes modify (owner varchar2(30));
alter table classes modify (created_by varchar2(30)); 
update classes set owner = trim(owner), created_by = trim (created_by);
commit;

create unique index lec_pla_uk on lec_pla (pla_id, lec_id);
create unique index gro_pla_uk on gro_pla (pla_id, gro_id);
create unique index rom_pla_uk on rom_pla (pla_id, rom_id);
create unique index sub_pla_uk on sub_pla (pla_id, sub_id);
create unique index for_pla_uk on for_pla (pla_id, for_id);
create unique index pla_uk on planners ( name );

alter table rom_cla add ( is_child char(1) default 'N');
alter table gro_cla add ( is_child char(1) default 'N');
alter table lec_cla add ( is_child char(1) default 'N');
update rom_cla set is_child = 'N';
update gro_cla set is_child = 'N';
update lec_cla set is_child = 'N';


grant select on SYS.CDEF$ to planner;
grant select on SYS.CON$ to planner;
grant select on SYS.OBJ$ to planner;
grant select on SYS.USER$ to planner;

--zmiana ID rekordow, tak, aby kazdy zasob mial unikatowy numer w ramach calej puli ( wykladowcy, grupy, sale )
--historyczne rekordy wykladowcow maja numery od 1 do 1 000 000
--historyczne rekordy grup maja numery od 1 000 000 do 3 000 000
--historyczne rekordy zasobow maja numery od 3 000 000 do 4 000 000
--nowe zasoby beda mialy nadawane numery ze wspolnej sekwencji poczawszy od 4 000 000.
begin
  for rec in (select * from groups order by id) loop 
    xxmsz_tools.update_record('PLANNER','GROUPS', rec.id, rec.id + 1000000, 'ID');
    commit;
  end loop;
end;  

begin
  for rec in (select * from rooms order by id) loop 
    xxmsz_tools.update_record('PLANNER','ROOMS', rec.id, rec.id + 3000000, 'ID');
    commit;
  end loop;
end;  

begin
 planner_utils.update_lgrs;
 commit;
end;

create sequence hint_seq;
create public synonym hint_seq for hint_seq;

CREATE SEQUENCE PLANNER.MAIN_SEQ
  START WITH 4000000
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 20
  NOORDER;

create public synonym main_seq for main_seq;

drop sequence lec_seq;
drop sequence gro_seq;
drop sequence roo_seq;

drop public synonym lec_seq;
drop public synonym gro_seq;
drop public synonym roo_seq;

create table res_hints
(
  id    number primary key,
  day   date,
  hour  number(2),
  ratio number(4),
  res_id number,
  res_type char(1)
);

create public synonym res_hints for res_hints;

comment on table res_hints   is 'Preferencje terminow, w ktorych powinny / nie powinny byc planowane zajecia';
    
comment on column res_hints.day      is 'Dzie�';
comment on column res_hints.hour     is 'Godzina';
comment on column res_hints.ratio    is '-999 : bardzo niewskazane jest planowanie w tym terminie. 999 - bardzo wskazane jest planowanie w tym terminie';
comment on column res_hints.res_id   is '=lecturers.id or =groups.id or =rooms.id, w zaleznosci od "res_type"';
comment on column res_hints.res_type is 'L=rezerwacja wykladowcy G=rezerwacja grupy R=rezerwacja sali';

create unique index hints_i1 on res_hints ( res_id, res_type, day, hour );
create index hints_i2 on res_hints ( res_id );

grant select on SYS.CDEF$ to planner;
grant select on SYS.CON$ to planner;
grant select on SYS.OBJ$ to planner;
grant select on SYS.USER$ to planner;

--zmiana ID rekordow, tak, aby kazdy zasob mial unikatowy numer w ramach calej puli ( wykladowcy, grupy, sale )
--historyczne rekordy wykladowcow maja numery od 1 do 1 000 000
--historyczne rekordy grup maja numery od 1 000 000 do 3 000 000
--historyczne rekordy zasobow maja numery od 3 000 000 do 4 000 000
--nowe zasoby beda mialy nadawane numery ze wspolnej sekwencji poczawszy od 4 000 000.
begin
  for rec in (select * from groups order by id) loop 
    xxmsz_tools.update_record('PLANNER','GROUPS', rec.id, rec.id + 1000000, 'ID');
    commit;
  end loop;
end;  

begin
  for rec in (select * from rooms order by id) loop 
    xxmsz_tools.update_record('PLANNER','ROOMS', rec.id, rec.id + 3000000, 'ID');
    commit;
  end loop;
end;  

begin
 planner_utils.update_lgrs;
 commit;
end;

create sequence hint_seq;
create public synonym hint_seq for hint_seq;

CREATE SEQUENCE PLANNER.MAIN_SEQ
  START WITH 4000000
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 20
  NOORDER;

create public synonym main_seq for main_seq;

drop sequence lec_seq;
drop sequence gro_seq;
drop sequence roo_seq;

drop public synonym lec_seq;
drop public synonym gro_seq;
drop public synonym roo_seq;

create table res_hints
(
  id    number primary key,
  day   date,
  hour  number(2),
  ratio number(4),
  res_id number,
  res_type char(1)
);

create public synonym res_hints for res_hints;

comment on table res_hints   is 'Preferencje terminow, w ktorych powinny / nie powinny byc planowane zajecia';
    
comment on column res_hints.day      is 'Dzie�';
comment on column res_hints.hour     is 'Godzina';
comment on column res_hints.ratio    is '-999 : bardzo niewskazane jest planowanie w tym terminie. 999 - bardzo wskazane jest planowanie w tym terminie';
comment on column res_hints.res_id   is '=lecturers.id or =groups.id or =rooms.id, w zaleznosci od "res_type"';
comment on column res_hints.res_type is 'L=rezerwacja wykladowcy G=rezerwacja grupy R=rezerwacja sali';

create unique index hints_i1 on res_hints ( res_id, res_type, day, hour );
create index hints_i2 on res_hints ( res_id );

alter table ORG_UNITS add ( unit_type varchar2(32));




create user "PLANNERREPORTS" identified by "123"
 default tablespace users
 temporary tablespace temp
 profile ordinary_user;
 
grant "CONNECT" to "PLANNERREPORTS";
grant "RESOURCE" to "PLANNERREPORTS";

--select 'grant select on planner.'||lower(table_name)||' to plannerreports;' from cat where table_type = 'TABLE' order by table_name
grant select on planner.classes to plannerreports;
grant select on planner.flex_col_usage to plannerreports;
grant select on planner.form_formulas to plannerreports;
grant select on planner.forms to plannerreports;
grant select on planner.for_pla to plannerreports;
grant select on planner.gro_cla to plannerreports;
grant select on planner.gro_pla to plannerreports;
grant select on planner.gro_str_elems to plannerreports;
grant select on planner.groups to plannerreports;
grant select on planner.lec_cla to plannerreports;
grant select on planner.lec_pla to plannerreports;
grant select on planner.lec_str_elems to plannerreports;
grant select on planner.lecturers to plannerreports;
grant select on planner.lookups to plannerreports;
grant select on planner.org_units to plannerreports;
grant select on planner.periods to plannerreports;
grant select on planner.planners to plannerreports;
grant select on planner.reservations to plannerreports;
grant select on planner.res_hints to plannerreports;
grant select on planner.resource_categories to plannerreports;
grant select on planner.res_str_elems to plannerreports;
grant select on planner.rol_pla to plannerreports;
grant select on planner.rom_cla to plannerreports;
grant select on planner.rom_pla to plannerreports;
grant select on planner.rooms to plannerreports;
grant select on planner.subjects to plannerreports;
grant select on planner.sub_pla to plannerreports;
grant select on planner.system_parameters to plannerreports;
grant select on planner.timetable to plannerreports;
grant select on planner.tmp_numbers to plannerreports;
grant select on planner.tmp_selected_dates to plannerreports;
grant select on planner.tmp_varchar2 to plannerreports;
grant select on planner.value_sets to plannerreports;

create or replace function getsqlvalues(sqltext varchar2, exceptifempty char default 'Y', sep varchar2 default '|', maxsizeofres number default 30000) return varchar2 is
begin
 return xxmsz_tools.getsqlv(replace(sqltext,'^',''''), exceptifempty, sep, maxsizeofres, false);
end;

grant execute on getSQLValues to plannerreports;

--2010.09.11
alter table forms add (colour integer); 
update forms set colour = round ( dbms_random.value(0,256 + 256*256 + 256*256*256) );
update planners set colour = round ( dbms_random.value(0,256 + 256*256 + 256*256*256) ) where colour is null;
commit;

alter table classes add ( colour number default 0);
update classes set colour = round ( dbms_random.value(0,256 + 256*256 + 256*256*256) );
commit;


alter table planner.gro_cla modify ( gro_id not null, cla_id not null);
alter table planner.rom_cla modify ( rom_id not null, cla_id not null);
alter table planner.lec_cla modify ( lec_id not null, cla_id not null);
alter table planner.gro_pla modify ( gro_id not null, pla_id not null);
alter table planner.rom_pla modify ( rom_id not null, pla_id not null);
alter table planner.lec_pla modify ( lec_id not null, pla_id not null);

--select table_name from all_tables where owner = 'PLANNER' order by table_name

--CLASSES
alter table FLEX_COL_USAGE add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table FORM_FORMULAS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table FORMS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table FOR_PLA add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
--GRO_CLA
alter table GRO_PLA add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table GRO_STR_ELEMS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table GROUPS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
--LEC_CLA
alter table LEC_PLA add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table LEC_STR_ELEMS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table LECTURERS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table LOOKUPS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table ORG_UNITS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table PERIODS add (creation_date  date default sysdate not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table PLANNERS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table RESERVATIONS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table RES_HINTS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table RESOURCE_CATEGORIES add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table RES_STR_ELEMS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table ROL_PLA add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
--ROM_CLA
alter table ROM_PLA add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table ROOMS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table SUBJECTS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table SUB_PLA add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table SYSTEM_PARAMETERS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table TIMETABLE add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);
alter table VALUE_SETS add (creation_date  date default sysdate not null ,created_by        varchar2(30) default user not null ,last_update_date  date default sysdate not null ,last_updated_by   varchar2(30) default user not null);

-- examination
select table_name from all_tables where owner = 'PLANNER'
minus
select unique table_name from all_tab_cols where owner = 'PLANNER' and column_name = 'LAST_UPDATE_DATE'
--CLASSES
--GRO_CLA
--LEC_CLA
--ROM_CLA
--TMP_NUMBERS
--TMP_SELECTED_DATES
--TMP_VARCHAR2


alter table rooms drop (building, number_of_peoples);
drop trigger rooms_temporary_trg;

alter table forms modify  abbreviation not null;
alter table subjects	modify abbreviation not null;
alter table rooms modify ( name not null );
