declare  
cursor temp
 is
  select 'DROP PUBLIC SYNONYM '||sname s from sys.synonyms where creator = user and syntype = 'PUBLIC';
  c integer;
begin
  for rec_temp in temp
  loop
    c := dbms_sql.open_cursor;
    begin
    dbms_sql.parse(c, rec_temp.s,dbms_sql.v7);
    exception
     when others then 
       raise_application_error(-20000, rec_temp.s||' '||sqlerrm);
    end;
    dbms_sql.close_cursor(c);	 		  
  end loop;  
end;
/

declare 
  cursor temp
  is
  select 'CREATE PUBLIC SYNONYM '||object_name||' FOR '||object_name s from sys.all_objects where owner = user and object_type not in ('SYNONYM', 'INDEX', 'PACKAGE BODY') order by object_name;
  c integer;
begin
for rec_temp in temp
loop
  c := dbms_sql.open_cursor;
  begin           
    dbms_sql.parse(c, rec_temp.s,dbms_sql.v7);           	 		  
  exception -- zablokowanie zatrzymania z powodu b��d�w
    when others then 
      null; -- polecenie raise podnosi wyj�tek
  end;
  dbms_sql.close_cursor(c);
  end loop;  
end;
/

