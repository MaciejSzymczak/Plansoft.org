alter table planner.classes add ( CREATION_DATE date default sysdate )

--package - new version
alter table classes add (calc_rescat_ids varchar2(255));
begin planner_utils.update_lgrs; commit; end;

drop INDEX ROOM_UK;
CREATE UNIQUE INDEX ROOM_UK ON ROOMS ( CASE WHEN RESCAT_ID=1 THEN NAME||' '||ATTRIBS_01 ELSE TO_CHAR(ID) END );

begin
  delete from SYSTEM_PARAMETERS where name in ('RESOURCE_CATEGORY_ID1','RESOURCE_CATEGORY_ID0');
  Insert into SYSTEM_PARAMETERS
   (NAME, VALUE, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, DESCRIPTION)
 Values
   ('RESOURCE_CATEGORY_ID0', '1', TO_DATE('06/11/2011 13:40:04', 'MM/DD/YYYY HH24:MI:SS'), 'PLANNER', TO_DATE('06/11/2011 13:40:04', 'MM/DD/YYYY HH24:MI:SS'), 'PLANNER', 'Resource category (=select id from resource_categories)');
  Insert into SYSTEM_PARAMETERS
   (NAME, VALUE, CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, DESCRIPTION)
 Values
   ('RESOURCE_CATEGORY_ID1', '2', TO_DATE('11/28/2010 16:41:10', 'MM/DD/YYYY HH24:MI:SS'), 'PLANNER', TO_DATE('11/28/2010 16:41:10', 'MM/DD/YYYY HH24:MI:SS'), 'PLANNER', 'Resource category (=select id from resource_categories)');
COMMIT;
end;


declare
 procedure add ( pc varchar2, pm varchar2) is
 begin
  delete from lookups where lookup_type = 'DBMESSAGE_TRANSLATION' and code = pc; 
  insert into lookups (id, value_set_id, lookup_type, code, meaning, enabled) 
  values (
  lookups_seq.nextval
  ,(select id from value_sets where name = 'DBMESSAGE_TRANSLATION')
  ,'DBMESSAGE_TRANSLATION'
  ,pc
  ,pm
  ,'Y'  
  );
 end;
begin
  --select constraint_name from all_constraints where owner = 'PLANNER' and r_owner is not null order by constraint_name
  add('CLA_FOR_FK','Usuni�cie zabronione, forma zosta�a u�yta podczas planowania zaj��');
  add('CLA_SUB_FK','Usuni�cie zabronione, przedmiot zosta� u�yty podczas planowania zaj��');
  add('FLEX_VALS_FK','Usuni�cie zabronione, zestaw warto�ci zosta� u�yty jak atrybut');
  add('FORFOR_FOR_FK','Usuni�cie zabronione, forma zosta�a u�yta podczas definowania formu�');
  add('FORFOR_ORGUNI_FK','Usuni�cie zabronione, jednostka organizacyjna zosta�a u�yta podczas definowania formu�');
  add('GROCLA_GRO_FK','Usuni�cie zabronione, grupa zosta�a u�yta podczas planowania zaj��');
  add('LECCLA_LEC_FK','Usuni�cie zabronione, wyk�adowca zosta� u�yty podczas planowania zaj��');
  add('LECTURERS_ORGUNI_FK','Usuni�cie zabronione, w tej jednostce organizacyjnej s� ju� wyk�adowcy');
  add('ORGUNI_ORGUNI_FK','Usuni�cie zabronione, jednostka organizacyjna zosta�a u�yta jako jednostka nadrz�dna dla innej jednostki');
  add('PER_ROL_FK','Usuni�cie zabronione, autoryzacja zosta�a u�yta podczas definiowania semestru');
  add('ROMCLA_ROM_FK','Usuni�cie zabronione, zas�b zosta� u�yty podczas planowania zaj��');
  add('ROM_RESCAT_FK','Usuni�cie zabronione, istniej� zasoby o tej kategorii zasob�w');
  add('TIMTAB_FOR_FK','Usuni�cie zabronione, forma zosta�a u�yta w planie studi�w');
  add('TIMTAB_GRO_FK','Usuni�cie zabronione, grupa zosta�a u�yta w planie studi�w');
  add('TIMTAB_PER_FK','Usuni�cie zabronione, semestr zosta� u�yty w planie studi�w');
  add('TIMTAB_SUB_FK','Usuni�cie zabronione, przedmiot zosta� u�yty w planie studi�w');
  -- 'FORPLA_LEC_FK','ON DELETE CASCADE'
  -- 'FORPLA_PLA_FK','ON DELETE CASCADE'
  -- 'GROCLA_CLA_FK','ON DELETE CASCADE'
  -- 'GROPLA_GRO_FK','ON DELETE CASCADE'
  -- 'GROPLA_PLA_FK','ON DELETE CASCADE'
  -- 'LECCLA_CLA_FK','ON DELETE CASCADE'
  -- 'LECPLA_LEC_FK','ON DELETE CASCADE'
  -- 'LECPLA_PLA_FK','ON DELETE CASCADE'
  -- 'LOOKUPS_FK','ON DELETE CASCADE'
  -- 'ROLPLA_PLA_FK','ON DELETE CASCADE'
  -- 'ROLPLA_ROL_FK','ON DELETE CASCADE'
  -- 'ROMPLA_PLA_FK','ON DELETE CASCADE'
  -- 'ROMPLA_ROM_FK','ON DELETE CASCADE'
  -- 'SUBPLA_LEC_FK','ON DELETE CASCADE'
  -- 'SUBPLA_PLA_FK','ON DELETE CASCADE'
  -- 'TOMCLA_CLA_FK','ON DELETE CASCADE'
  commit;
end;


