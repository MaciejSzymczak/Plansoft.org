SPOOL Version35.log

connect planner

PROMPT AKTUALIZACJA INFORMACJI O WERSJI SCHEMATU BAZY DANYCH

UPDATE SYSTEM_PARAMETERS SET VALUE = '3.5' WHERE NAME = 'PLANOWANIE.VERSION_INFO';

COMMIT;

prompt usuni�cie poprzedniej wersji tabeli

drop table lookups;

create table value_sets
(ID                    NUMBER primary key
,NAME                  VARCHAR2(100)                   not null
,DESCRIPTION           VARCHAR2(1000)
,SET_TYPE              VARCHAR2(20)   default 'STRING' not null
,SQL_STATEMENT         VARCHAR2(1000) default null
,CHECK_PROCEDURE       VARCHAR2(240)  default null
,MIN_LENGTH            number         default 0
,MAX_LENGTH            number         default 32000
,who_creation_date     date           default sysdate  not null
,who_last_update_date  date           default sysdate  not null
,who_created_by        varchar2(30)   default 'SYSTEM' not null
,who_last_updated_by   varchar2(30)   default 'SYSTEM' not null
,who_last_update_login number         default -1       not null
);

create unique index  value_sets_i on value_sets (name);

create sequence value_sets_seq;

create sequence lookups_seq;

create table lookups
(id                    number                          primary key
,value_set_id          number                          not null 
,lookup_type           varchar2(100)                   not null
,code                  varchar2(100)
,meaning               varchar2(240)
,description           varchar2(1000)
,enabled               varchar2(1)                     not null
,who_creation_date     date           default sysdate  not null
,who_last_update_date  date           default sysdate  not null
,who_created_by        varchar2(30)   default 'SYSTEM' not null
,who_last_updated_by   varchar2(30)   default 'SYSTEM' not null
,who_last_update_login number         default -1       not null
);

create index  lookups_i on lookups (lookup_type);

alter table lookups add  constraint lookups_fk
 foreign key (value_set_id) 
  references value_sets (id) on delete cascade;

begin
insert into VALUE_SETS (id, name, set_type ) values (value_sets_seq.nextval, 'GROUP_TYPE', 'LOOKUP');
INSERT INTO lookups (ID,value_set_id, lookup_TYPE,CODE,meaning,DESCRIPTION, enabled) VALUES (lookups_seq.nextval,value_sets_seq.currval,'GROUP_TYPE','STATIONARY','Dzienne',NULL,'Y');
INSERT INTO lookups (ID,value_set_id, lookup_TYPE,CODE,meaning,DESCRIPTION, enabled) VALUES (lookups_seq.nextval,value_sets_seq.currval,'GROUP_TYPE','EXTRAMURAL','Zaoczne',NULL,'Y');
INSERT INTO lookups (ID,value_set_id, lookup_TYPE,CODE,meaning,DESCRIPTION, enabled) VALUES (lookups_seq.nextval,value_sets_seq.currval,'GROUP_TYPE','OTHER','Inne',NULL,'Y');
insert into VALUE_SETS (id, name, set_type ) values (value_sets_seq.nextval, 'FORM_FORMULA_TYPE', 'LOOKUP');
INSERT INTO lookups (ID,value_set_id, lookup_TYPE,CODE,meaning,DESCRIPTION, enabled) VALUES (lookups_seq.nextval,value_sets_seq.currval,'FORM_FORMULA_TYPE','LEC_UTILIZATION','Obci��enie wyk�adowc�w',NULL,'Y');
INSERT INTO lookups (ID,value_set_id, lookup_TYPE,CODE,meaning,DESCRIPTION, enabled) VALUES (lookups_seq.nextval,value_sets_seq.currval,'FORM_FORMULA_TYPE','STUDENTHOURS','Studentogodziny',NULL,'Y');
COMMIT;
end;
/

CREATE OR REPLACE FORCE VIEW LOOKUPS_GROUP_TYPE ("ID", "TYPE", "CODE", "NAME", "DESCRIPTION") AS 
SELECT "ID","LOOKUP_TYPE","CODE","MEANING","DESCRIPTION" FROM LOOKUPS WHERE lookup_TYPE = 'GROUP_TYPE'  

/
  
CREATE OR REPLACE FORCE VIEW LOOKUPS_FORM_FORMULA_TYPE ("ID", "TYPE", "CODE", "NAME", "DESCRIPTION") AS 
SELECT "ID","LOOKUP_TYPE","CODE","MEANING","DESCRIPTION" FROM LOOKUPS WHERE lookup_TYPE = 'FORM_FORMULA_TYPE'

/

spool off

