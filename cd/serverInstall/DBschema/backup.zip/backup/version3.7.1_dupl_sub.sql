--select 'planner_utils.merge_sub('||id||',''Y'');' from
--(
--select name
--     , count(*) 
--     , xxmsz_tools.getSQLValues('select ABBREVIATION from subjects where name ='''||name||''' order by 1') skroty
--     , xxmsz_tools.getSQLValues('select id from subjects where name ='''||name||''' order by 1') id
--  from subjects
--group by name
--having count(*) >1
--order by 2 desc
--)


begin
planner_utils.merge_sub(1000653, 1000654,'Y');
planner_utils.merge_sub(1000653, 1000655,'Y');
planner_utils.merge_sub(1000653, 1000657,'Y');
planner_utils.merge_sub(1000653, 1000690,'Y');
planner_utils.merge_sub(1000653, 1000691,'Y');
planner_utils.merge_sub(1000653, 1000897,'Y');
planner_utils.merge_sub(1000653, 1000901,'Y');
planner_utils.merge_sub(1000653, 1000906,'Y');
planner_utils.merge_sub(1000653, 1000907,'Y');
planner_utils.merge_sub(1000653, 1000908,'Y');
planner_utils.merge_sub(1000653, 1001377,'Y');
planner_utils.merge_sub(1000653, 1001387,'Y');
planner_utils.merge_sub(1000810, 1003111,'Y');
planner_utils.merge_sub(1000810, 1003112,'Y');
planner_utils.merge_sub(1000810, 1003113,'Y');
planner_utils.merge_sub(1000810, 1003114,'Y');
planner_utils.merge_sub(1000810, 1003115,'Y');
planner_utils.merge_sub(1000810, 1003116,'Y');
planner_utils.merge_sub(1001972, 1001973,'Y');
planner_utils.merge_sub(1001972, 1001974,'Y');
planner_utils.merge_sub(1001972, 1001975,'Y');
planner_utils.merge_sub(1001972, 1002396,'Y');
planner_utils.merge_sub(1001788, 1002427,'Y');
planner_utils.merge_sub(1001788, 1002428,'Y');
planner_utils.merge_sub(1001788, 1002429,'Y');
planner_utils.merge_sub(1001788, 1002430,'Y');
planner_utils.merge_sub(1001779, 1001780,'Y');
planner_utils.merge_sub(1001779, 1001781,'Y');
planner_utils.merge_sub(1001779, 1002998,'Y');
planner_utils.merge_sub(1000834, 1001614,'Y');
planner_utils.merge_sub(1000834, 1002641,'Y');
planner_utils.merge_sub(1000834, 1002642,'Y');
planner_utils.merge_sub(1002777, 1002782,'Y');
planner_utils.merge_sub(1002777, 1002783,'Y');
planner_utils.merge_sub(1002777, 1002784,'Y');
planner_utils.merge_sub(1001306, 1002574,'Y');
planner_utils.merge_sub(1001306, 1002575,'Y');
planner_utils.merge_sub(1001306, 1002576,'Y');
planner_utils.merge_sub(1001454, 1002640,'Y');
planner_utils.merge_sub(1001454, 1002645,'Y');
planner_utils.merge_sub(1001454, 1002646,'Y');
planner_utils.merge_sub(1001970, 1001977,'Y');
planner_utils.merge_sub(1001970, 1001978,'Y');
planner_utils.merge_sub(1001970, 1002395,'Y');
planner_utils.merge_sub(1002078, 1002079,'Y');
planner_utils.merge_sub(1002078, 1002080,'Y');
planner_utils.merge_sub(1002078, 1002578,'Y');
planner_utils.merge_sub(1000966, 1002564,'Y');
planner_utils.merge_sub(1000966, 1002565,'Y');
planner_utils.merge_sub(1000966, 1002566,'Y');
planner_utils.merge_sub(1001969, 1002397,'Y');
planner_utils.merge_sub(1001969, 1002398,'Y');
planner_utils.merge_sub(1001971, 1002399,'Y');
planner_utils.merge_sub(1001971, 1002400,'Y');
planner_utils.merge_sub(1001776, 1001782,'Y');
planner_utils.merge_sub(1001776, 1001783,'Y');
planner_utils.merge_sub(1001450, 1002870,'Y');
planner_utils.merge_sub(1001450, 1002871,'Y');
planner_utils.merge_sub(1003012, 1003088,'Y');
planner_utils.merge_sub(1003012, 1003132,'Y');
planner_utils.merge_sub(1001959, 1001960,'Y');
planner_utils.merge_sub(1001959, 1002766,'Y');
planner_utils.merge_sub(1001650, 1002062,'Y');
planner_utils.merge_sub(1001650, 1002756,'Y');
planner_utils.merge_sub(1002040, 1002569,'Y');
planner_utils.merge_sub(1002040, 1002570,'Y');
planner_utils.merge_sub(1002082, 1002571,'Y');
planner_utils.merge_sub(1002082, 1002572,'Y');
planner_utils.merge_sub(1000739, 1000833,'Y');
planner_utils.merge_sub(1000739, 4001447,'Y');
planner_utils.merge_sub(1001610, 1001961,'Y');
planner_utils.merge_sub(1001610, 1001962,'Y');
planner_utils.merge_sub(1001645, 1002793,'Y');
planner_utils.merge_sub(1001645, 1002794,'Y');
planner_utils.merge_sub(1001455, 1002643,'Y');
planner_utils.merge_sub(1001455, 1002644,'Y');
planner_utils.merge_sub(1001437, 1001459,'Y');
planner_utils.merge_sub(1001455, 1002394,'Y');
planner_utils.merge_sub(1001773, 1002561,'Y');
planner_utils.merge_sub(1001773, 1002562,'Y');
planner_utils.merge_sub(1000474, 1000967,'Y');
planner_utils.merge_sub(1000602, 1001021,'Y');
planner_utils.merge_sub(1001066, 1001078,'Y');
planner_utils.merge_sub(1001089, 1003007,'Y');
planner_utils.merge_sub(1002882, 1003019,'Y');
planner_utils.merge_sub(1001648, 1001723,'Y');
planner_utils.merge_sub(1003060, 1003207,'Y');
planner_utils.merge_sub(1003079, 1003143,'Y');
planner_utils.merge_sub(4001464, 4001465,'Y');
planner_utils.merge_sub(1000210, 1002981,'Y');
planner_utils.merge_sub(1000316, 1000882,'Y');
planner_utils.merge_sub(1000694, 1000873,'Y');
planner_utils.merge_sub(1001821, 1003069,'Y');
planner_utils.merge_sub(1002915, 4001642,'Y');
planner_utils.merge_sub(1000163, 1000438,'Y');
planner_utils.merge_sub(1001722, 1002984,'Y');
planner_utils.merge_sub(1002263, 4001187,'Y');
planner_utils.merge_sub(1003245, 4001575,'Y');
planner_utils.merge_sub(1000396, 1000460,'Y');
planner_utils.merge_sub(1000918, 1003031,'Y');
planner_utils.merge_sub(1002344, 1002345,'Y');
planner_utils.merge_sub(1000360, 1000736,'Y');
planner_utils.merge_sub(1003083, 1003220,'Y');
planner_utils.merge_sub(1001801, 1002445,'Y');
planner_utils.merge_sub(1000642, 1003107,'Y');
planner_utils.merge_sub(1000681, 1001866,'Y');
planner_utils.merge_sub(1002143, 1002524,'Y');
planner_utils.merge_sub(1002762, 1002935,'Y');
planner_utils.merge_sub(1000425, 1001419,'Y');
planner_utils.merge_sub(1000509, 1002580,'Y');
planner_utils.merge_sub(1000202, 4001189,'Y');
planner_utils.merge_sub(1000824, 1003148,'Y');
planner_utils.merge_sub(1001389, 1001834,'Y');
planner_utils.merge_sub(1001919, 1002032,'Y');
planner_utils.merge_sub(1002076, 1002077,'Y');
planner_utils.merge_sub(1002632, 1003057,'Y');
planner_utils.merge_sub(1002261, 1003044,'Y');
planner_utils.merge_sub(4001180, 4001201,'Y');
planner_utils.merge_sub(4001372, 4001375,'Y');
planner_utils.merge_sub(1000898, 1001104,'Y');
planner_utils.merge_sub(1001376, 1002404,'Y');
planner_utils.merge_sub(1001918, 1002728,'Y');
planner_utils.merge_sub(1002653, 1003155,'Y');
planner_utils.merge_sub(1002837, 1003048,'Y');
planner_utils.merge_sub(4001427, 4001535,'Y');
planner_utils.merge_sub(1000223, 1002630,'Y');
planner_utils.merge_sub(1001222, 1001958,'Y');
planner_utils.merge_sub(1001230, 1001328,'Y');
planner_utils.merge_sub(1001132, 1001295,'Y');
planner_utils.merge_sub(1001714, 1002042,'Y');
planner_utils.merge_sub(1002606, 4001174,'Y');
planner_utils.merge_sub(1000780, 1001950,'Y');
planner_utils.merge_sub(1002268, 1002532,'Y');
planner_utils.merge_sub(1000604, 1001712,'Y');
planner_utils.merge_sub(1000842, 1003041,'Y');
planner_utils.merge_sub(1001679, 1002002,'Y');
planner_utils.merge_sub(1001729, 1001894,'Y');
planner_utils.merge_sub(1002720, 4001196,'Y');
planner_utils.merge_sub(1002423, 1002818,'Y');
planner_utils.merge_sub(1002881, 1003018,'Y');
planner_utils.merge_sub(1001511, 1003043,'Y');
planner_utils.merge_sub(1000437, 4001757,'Y');
planner_utils.merge_sub(1003153, 4001569,'Y');
planner_utils.merge_sub(1000995, 1001319,'Y');
planner_utils.merge_sub(1002748, 4001459,'Y');
planner_utils.merge_sub(1002767, 1002774,'Y');
planner_utils.merge_sub(4001384, 4001457,'Y');
planner_utils.merge_sub(1000453, 1000731,'Y');
planner_utils.merge_sub(1000467, 1000732,'Y');
planner_utils.merge_sub(1000658, 1001560,'Y');
planner_utils.merge_sub(1002085, 4001385,'Y');
planner_utils.merge_sub(1002245, 1002254,'Y');
planner_utils.merge_sub(1002357, 1002358,'Y');
planner_utils.merge_sub(1002518, 1002937,'Y');
planner_utils.merge_sub(1000367, 1000368,'Y');
planner_utils.merge_sub(1000399, 1002210,'Y');
planner_utils.merge_sub(1000569, 1001039,'Y');
planner_utils.merge_sub(1001279, 1001370,'Y');
planner_utils.merge_sub(1001439, 4001353,'Y');
planner_utils.merge_sub(1002523, 1003027,'Y');
commit;
end;
/


begin
-- reczne usuwanie duplikatow
--select id || ' ' || name from subjects order by name
--1001497 Admin. syst. oper. unix -> 1002309 Admin. syst. operac. UNIX
--1001362 Aerodynamika i mech. lotu -> 1001081 Aerodynamika i mech.lotu
--1002546 Archimedes -> 1002505 ARCHIMEDES
--4001372 Bezpiecze�stwo i higiena pracy -> 4001374 Bezpiecze�stwo i higiena przcy
--1003059 Centra logistyczna -> 1003209 Centra logistyczne
--1000958 Cyfrowe przetwarzanie obrazu -> 1002976 Cyfrowe przetwarzanie obraz�w
--1000436 Dzie� gotowosci bojowej -> 1000118 Dzie� gotowo�ci bojowej
--1002329 Komunikacja cz�owiek komputer -> 1001577 Komunikacja cz�owiek-komputer
--1001774 Krystalografia i rengenografia strukturalna -> 1001959 Krystalografia i rentgenografia strukturalna
--1001914 Mechanika techniczna i wytrzyma�o�� materia��w -> 1001951 Mechanika techniczna z wytrzyma�o�ci� materia��w
--1001707 Metody analizy i integracji danych -> 1001705 metody analizy i integracji danych
planner_utils.merge_sub(1001497, 1002309,'Y');
planner_utils.merge_sub(1001362, 1001081,'Y');
planner_utils.merge_sub(1002546, 1002505,'Y');
planner_utils.merge_sub(4001372, 4001374,'Y');
planner_utils.merge_sub(1003059, 1003209,'Y');
planner_utils.merge_sub(1000958, 1002976,'Y');
planner_utils.merge_sub(1000436, 1000118,'Y');
planner_utils.merge_sub(1002329, 1001577,'Y');
planner_utils.merge_sub(1001774, 1001959,'Y');
planner_utils.merge_sub(1001914, 1001951,'Y');
planner_utils.merge_sub(1001707, 1001705,'Y');
commit;
end;
/


begin
-- select upper(trim(name))
--      , count(*) 
--      , xxmsz_tools.getSQLValues('select ABBREVIATION from subjects where upper(trim(name)) ='''||upper(trim(name))||''' order by 1') skroty
--      , xxmsz_tools.getSQLValues('select id from subjects where upper(trim(name)) ='''||upper(trim(name))||''' order by 1') id
--   from subjects
-- group by upper(trim(name))
-- having count(*) >1
planner_utils.merge_sub(1002344, 1002346,'Y');
planner_utils.merge_sub(1001124, 1001125,'Y');
planner_utils.merge_sub(1002623, 1002858,'Y');
planner_utils.merge_sub(1000737, 1001247,'Y');
planner_utils.merge_sub(1003058, 4001476,'Y');
planner_utils.merge_sub(1003154, 4001570,'Y');
commit;
end;


begin
-- select upper(trim(name))
--      , count(*) 
--      , xxmsz_tools.getSQLValues('select ABBREVIATION from forms where upper(trim(name)) ='''||upper(trim(name))||''' order by id') skroty
--      , xxmsz_tools.getSQLValues('select id from forms where upper(trim(name)) ='''||upper(trim(name))||''' order by id') id
--   from forms
--   where name is not null
-- group by upper(trim(name))
-- having count(*) >1
planner_utils.merge_for(1004006, 4001492,'Y');
planner_utils.merge_for(1004005, 1004067,'Y');
planner_utils.merge_for(1004005, 4001493,'Y');
planner_utils.merge_for(1004003, 4001491,'Y');
planner_utils.merge_for(1004041, 4001681,'Y');
planner_utils.merge_for(1004041, 4001683,'Y');
planner_utils.merge_for(1004001, 4001489,'Y');
planner_utils.merge_for(1004071, 1004087,'Y');
planner_utils.merge_for(4001515, 4001516,'Y');
planner_utils.merge_for(1004010, 4001494,'Y');
planner_utils.merge_for(1004054, 1004057,'Y');
planner_utils.merge_for(1004002, 4001490,'Y');
planner_utils.merge_for(1004026, 4001637,'Y');
planner_utils.merge_for(1004026, 4001734,'Y');
end;

begin
-- select x.*
--     ,  xxmsz_tools.getSQLValues('select id from rooms where replace(name,''/'','''')||''/''||attribs_01 ='''|| sala  ||''' order by id') id      
-- from
-- (select replace(name,'/','')||'/'||attribs_01 sala
--      , count(*) duplikaty
--   from rooms 
--  group by replace(name,'/','')||'/'||attribs_01
--  having count(*)>1 
--  order by count(*) desc
-- ) x 
planner_utils.merge_res(3502480, 3502921, 'Y');
planner_utils.merge_res(3502480, 3506080, 'Y');
planner_utils.merge_res(3502480, 3506160, 'Y');
planner_utils.merge_res(3502480, 3506321, 'Y');
planner_utils.merge_res(3505740, 4000164, 'Y');
planner_utils.merge_res(3505740, 4001154, 'Y');
planner_utils.merge_res(3505740, 4001411, 'Y');
planner_utils.merge_res(3501843, 3505220, 'Y');
planner_utils.merge_res(3501843, 3505481, 'Y');
planner_utils.merge_res(3504201, 3504260, 'Y');
planner_utils.merge_res(3504201, 3504440, 'Y');
planner_utils.merge_res(3501362, 3506400, 'Y');
planner_utils.merge_res(3501362, 4000142, 'Y');
planner_utils.merge_res(4000317, 4000642, 'Y');
planner_utils.merge_res(4000317, 4000657, 'Y');
planner_utils.merge_res(3502180, 3502660, 'Y');
planner_utils.merge_res(3502180, 3504720, 'Y');
planner_utils.merge_res(3500260, 3500262, 'Y');
planner_utils.merge_res(3500260, 3500263, 'Y');
planner_utils.merge_res(3504020, 4001271, 'Y');
planner_utils.merge_res(3506224, 4001470, 'Y');
planner_utils.merge_res(3000015, 3501420, 'Y');
planner_utils.merge_res(3000065, 3503923, 'Y');
planner_utils.merge_res(3504240, 3504480, 'Y');
planner_utils.merge_res(3501561, 3504080, 'Y');
planner_utils.merge_res(4000318, 4000643, 'Y');
planner_utils.merge_res(3000102, 3500740, 'Y');
planner_utils.merge_res(3500209, 4001152, 'Y');
planner_utils.merge_res(3502461, 3505741, 'Y');
planner_utils.merge_res(3503141, 3506401, 'Y');
planner_utils.merge_res(3503480, 3503980, 'Y');
planner_utils.merge_res(3503920, 3503921, 'Y');
planner_utils.merge_res(3502267, 3506002, 'Y');
planner_utils.merge_res(3501300, 4000139, 'Y');
planner_utils.merge_res(3502900, 3502960, 'Y');
planner_utils.merge_res(3503941, 3505409, 'Y');
planner_utils.merge_res(3505200, 3505420, 'Y');
planner_utils.merge_res(3505960, 3506260, 'Y');
planner_utils.merge_res(3501981, 4000305, 'Y');
planner_utils.merge_res(3501005, 3504741, 'Y');
planner_utils.merge_res(3501460, 3504981, 'Y');
planner_utils.merge_res(3501400, 4000143, 'Y');
planner_utils.merge_res(3502080, 3505680, 'Y');
planner_utils.merge_res(3505180, 4000648, 'Y');
planner_utils.merge_res(3502280, 3505404, 'Y');
planner_utils.merge_res(3502400, 4001706, 'Y');
planner_utils.merge_res(3501721, 4000660, 'Y');
planner_utils.merge_res(3504700, 4000403, 'Y');
planner_utils.merge_res(3500565, 3504200, 'Y');
planner_utils.merge_res(3501401, 3504141, 'Y');
planner_utils.merge_res(3502740, 3505880, 'Y');
planner_utils.merge_res(3505123, 3505440, 'Y');
planner_utils.merge_res(3000017, 3503560, 'Y');
planner_utils.merge_res(3502264, 3504600, 'Y');
planner_utils.merge_res(3500920, 3504040, 'Y');
planner_utils.merge_res(3000069, 3504601, 'Y');
planner_utils.merge_res(3501440, 4001505, 'Y');
planner_utils.merge_res(3503280, 4000578, 'Y');
planner_utils.merge_res(3505061, 4001557, 'Y');
planner_utils.merge_res(3506225, 4001504, 'Y');
planner_utils.merge_res(3000018, 3505280, 'Y');
planner_utils.merge_res(4001151, 4001378, 'Y');
planner_utils.merge_res(3000027, 3000057, 'Y');
planner_utils.merge_res(3502861, 3502862, 'Y');
planner_utils.merge_res(3503240, 3503943, 'Y');
planner_utils.merge_res(3503701, 4001469, 'Y');
planner_utils.merge_res(3504820, 3506300, 'Y');
planner_utils.merge_res(3502265, 3503640, 'Y');
planner_utils.merge_res(3000108, 3500860, 'Y');
planner_utils.merge_res(3500761, 3503220, 'Y');
planner_utils.merge_res(3502482, 4001633, 'Y');
planner_utils.merge_res(3501441, 3504021, 'Y');
planner_utils.merge_res(3500029, 3503160, 'Y');
commit;
end;

begin
-- select x.* 
--     ,  xxmsz_tools.getSQLValues('select id from lecturers where upper(trim(last_name)||'' ''||trim(first_name)||'' ''||trim(title)) ='''|| lecer  ||''' order by id') id      
-- from
-- (
-- select upper(trim(last_name)||' '||trim(first_name)||' '||trim(title)) lecer
--      , count(*) duplikaty 
--   from lecturers 
-- group by upper(trim(last_name)||' '||trim(first_name)||' '||trim(title)) 
-- having count(*)>1 
-- order by 1, count(*) desc
-- ) x
planner_utils.merge_lec(506800, 507141,'Y');
planner_utils.merge_lec(506185, 506862,'Y');
planner_utils.merge_lec(506185, 506920,'Y');
planner_utils.merge_lec(503822, 505364,'Y');
planner_utils.merge_lec(507063, 507481,'Y');
planner_utils.merge_lec(507622, 507624,'Y');
planner_utils.merge_lec(503161, 504201,'Y');
planner_utils.merge_lec(507460, 508108,'Y');
planner_utils.merge_lec(502412, 508208,'Y');
planner_utils.merge_lec(507964, 508409,'Y');
planner_utils.merge_lec(505660, 506142,'Y');
planner_utils.merge_lec(508480, 4000640,'Y');
planner_utils.merge_lec(501961, 4000558,'Y');
commit;
end;

--?duplicates
-- select x.* 
--     ,  xxmsz_tools.getSQLValues('select id from lecturers where upper(trim(last_name)||'' ''||trim(first_name)||'' ''||trim('''')) ='''|| lecer  ||''' order by id') id      
--     ,  xxmsz_tools.getSQLValues('select title from lecturers where upper(trim(last_name)||'' ''||trim(first_name)||'' ''||trim('''')) ='''|| lecer  ||''' order by id') id      
-- from
-- (
-- select upper(trim(last_name)||' '||trim(first_name)||' '||trim('')) lecer
--      , count(*) duplikaty 
--   from lecturers 
-- group by upper(trim(last_name)||' '||trim(first_name)||' '||trim('')) 
-- having count(*)>1 
-- order by 1, count(*) desc
-- ) x


CREATE UNIQUE INDEX SUB_name_I ON SUBJECTS (name);
CREATE UNIQUE INDEX FOR_NAME_UI ON FORMS (NAME);
CREATE UNIQUE INDEX ROOM_UK ON ROOMS (CASE  WHEN (RESCAT_ID=1 ) THEN NAME||ATTRIBS_01 ELSE TO_CHAR(ID) END);
CREATE UNIQUE INDEX LEC_NAME_UI ON LECTURERS (FIRST_NAME,LAST_NAME,TITLE);

drop function isSubsetOf;

begin
 insert into value_sets (id, name, description, set_type) values ( value_sets_seq.NEXTVAL, 'DBMESSAGE_TRANSLATION', 'T�umaczenia komunikat�w bazy danych na komunikaty zrozumia�e dla u�ytkownik�w','LOOKUP');
 commit;
end;

declare
 procedure addv (a varchar2, b varchar2) is
 begin
  insert into LOOKUPS (id, value_set_id, lookup_type, code, meaning, enabled) values (lookups_seq.nextval, (select id from value_sets where name = 'DBMESSAGE_TRANSLATION'), 'DBMESSAGE_TRANSLATION', a,b,'Y' );
 end;
begin
  --delete from LOOKUPS where lookup_type = 'DBMESSAGE_TRANSLATION';
  --select table_name, index_name from all_indexes where owner = 'PLANNER' and uniqueness = 'UNIQUE' order by index_name
  addv ('SUB_NAME_I'          , 'Nie mo�na zapisa� danych, poniewa� istnieje przedmiot o podanej NAZWIE'); 
  addv ('SUB_ABBREVIATION_I'  , 'Nie mo�na zapisa� danych, poniewa� istnieje przedmiot o podanym SKR�CIE'); 
  addv ('FLEX_UI'             , 'Kombinacja nazwy formularza, kontekstu i nazwy atrybutu musi by� unikatowa'); 
  addv ('FRM_ABBREVIATION_I'  , 'Nie mo�na zapisa� danych, poniewa� istnieje forma o podanym SKR�CIE');
  addv ('GRO_ABBREVIATION_I'  , 'Nie mo�na zapisa� danych, poniewa� istnieje grupa o podanym SKR�CIE');
  addv ('LEC_ABBREVIATION_I'  , 'Nie mo�na zapisa� danych, poniewa� istnieje wyk�adowca o podanym SKR�CIE');
  addv ('ORGUNI_NAME_FK_I'    , 'Nie mo�na zapisa� danych, poniewa� istnieje jednostka organizacyjna o podanej NAZWIE');
  addv ('PLA_UK'              , 'Nie mo�na zapisa� danych, poniewa� istnieje planista lub autoryzacja o podanej NAZWIE');
  addv ('STRELEM3'            , 'Kombinacja elementu nadrz�dnego, podrz�dnego i kodu hierarchii musi by� unikatowa');
  addv ('SYSTEM_PARAMETERS_UK', 'Nie mo�na zapisa� danych, poniewa� istnieje parametr systemowy o podanej NAZWIE');
  addv ('VALUE_SETS_I'        , 'Nie mo�na zapisa� danych, poniewa� istnieje zestaw warto�ci o podanej NAZWIE');
  addv('FOR_NAME_UI'          , 'Nie mo�na zapisa� danych, poniewa� istnieje forma zaj�� o podanej NAZWIE');
  addv('ROOM_UK'              , 'Nie mo�na zapisa� danych, poniewa� istnieje sala o podanym NUMERZE i BUDYNKU');
  addv('LEC_NAME_UI'          , 'Nie mo�na zapisa� danych, poniewa� istnieje wyk�adowca o takim samym IMIENIU, NAZWISKU i TYTULE');
  commit;
end;



