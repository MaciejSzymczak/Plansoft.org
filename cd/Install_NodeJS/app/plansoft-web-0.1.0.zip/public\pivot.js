// Tabela przestawna (FMatrix w Delphi): wiersze i kolumny z wybranych pól (wykładowcy, grupy, zasoby, przedmioty, formy,
// dni, miesiące, dni tygodnia, godziny, ...), w komórkach liczba godzin zajęć (jak "Zajęcia (suma)" w Raportowaniu -
// czas bloku * wypełnienie). Dane z tego samego zapytania co okno Raportowanie (/api/report), przestawiane w przeglądarce;
// sumy wierszy i kolumn, eksport do Excela, wydruk.
import { EXCEL_ICON, downloadXlsx } from './xlsx.js';

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined && text !== null) e.textContent = text;
  return e;
}
function button(text, cls, onClick, title) {
  const b = el('button', cls || 'secondary small', text);
  b.type = 'button';
  if (title) b.title = title;
  b.addEventListener('click', onClick);
  return b;
}

// pola: [klucz, etykieta, opcje raportu, kolumna wyniku raportu]
const FIELDS = [
  ['L', 'Wykładowca', { L: true }, 'Wykładowcy'],
  ['G', 'Grupa', { G: true }, 'Grupy'],
  ['R', 'Zasób', { R: true }, 'Zasoby'],
  ['S', 'Przedmiot', { S: true }, 'Przedmioty'],
  ['F', 'Forma zajęć / rezerwacja', { F: true, FnewColumn: false }, 'Formy'],
  ['day', 'Dzień', { day: true }, 'Dzień'],
  ['month', 'Miesiąc', { month: true }, 'Miesiąc'],
  ['dayOfWeek', 'Dzień tygodnia', { dayOfWeek: true }, 'Dzień tyg.'],
  ['hour', 'Godzina', { hour: true }, 'Godzina'],
  ['Luni', 'Jednostka wykładowcy', { Luni: true }, 'Jednostka wykładowcy'],
  ['Gtype', 'Typ grupy', { Gtype: true }, 'Typ grupy'],
  ['Sorg', 'Jednostka przedmiotu', { Sorg: true }, 'Jednostka przedmiotu'],
  ['owner', 'Właściciel', { owner: true }, 'Właściciel'],
  ['createdBy', 'Utworzył', { createdBy: true }, 'Utworzył'],
  ['desc1', 'desc1', { desc1: true }, 'desc1'], ['desc2', 'desc2', { desc2: true }, 'desc2'],
  ['desc3', 'desc3', { desc3: true }, 'desc3'], ['desc4', 'desc4', { desc4: true }, 'desc4'],
];
const ALL_FLAGS = ['L', 'G', 'R', 'S', 'F', 'FnewColumn', 'day', 'month', 'dayOfWeek', 'hour', 'Luni', 'Gtype', 'Sorg', 'owner', 'createdBy',
  'desc1', 'desc2', 'desc3', 'desc4', 'LnewLine', 'GnewLine', 'RnewLine', 'Gstudents', 'Gorg', 'Gparent', 'Rorg', 'fill', 'creationDate', 'integrationId'];
const WD_ORDER = ['pon', 'wt', 'śr', 'czw', 'pt', 'sob', 'niedz', 'nie'];
const PREF_KEY = user => 'plansoft.web.pivot.' + user;

export class PivotWindow {
  // getContext: () => { user, period, settings, objects: {L, G, S} }
  constructor({ api, getContext }) {
    this.api = api;
    this.getContext = getContext;
    this.dialog = el('dialog', 'pivot');
    document.body.append(this.dialog);
  }

  fieldLabel(f) {
    const m = /^desc(\d)$/.exec(f[1]);
    return m ? this.ctx.settings.descPlural[m[1] - 1] : f[1];
  }

  // preset: { rows: [...], col } - np. "Zaawansowane: własny układ" z podglądu
  open(preset) {
    this.ctx = this.getContext();
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem(PREF_KEY(this.ctx.user))) || {}; } catch { /* brak pamięci */ }
    const v = { rows: ['L', '', ''], col: 'F', onlySelected: true, split: true, phrase: '', ...saved, ...(preset || {}) };
    this.build(v);
    this.dialog.showModal();
  }

  build(v) {
    const d = this.dialog;
    d.innerHTML = '';
    const head = el('div', 'b-head');
    head.append(el('h2', '', 'Tabela przestawna'), el('span', 'spacer'), button('×', 'link close', () => d.close(), 'Zamknij (Esc)'));
    const form = el('div', 'pv-form-row');
    const fields = FIELDS.filter(f => this.fieldLabel(f));
    const sel = (value, empty) => {
      const s = el('select');
      if (empty) s.append(new Option(empty, ''));
      for (const f of fields) s.append(new Option(this.fieldLabel(f), f[0]));
      s.value = value || '';
      return s;
    };
    const box = (label, ...inputs) => { const l = el('label', 'b-field'); l.append(el('span', '', label), ...inputs); return l; };
    this.rowSel = [sel(v.rows[0]), sel(v.rows[1], '<brak>'), sel(v.rows[2], '<brak>')];
    this.colSel = sel(v.col, '<brak>');
    const rowsBox = el('div', 'pv-rows'); rowsBox.append(...this.rowSel);
    form.append(box('Wiersze', rowsBox), box('Kolumny', this.colSel));
    const filt = el('div', 'pv-filters');
    const o = this.ctx.objects;
    const names = t => o[t].map(i => i.name).join(', ');
    const chk = (label, val, title) => { const l = el('label', 'check'); const c = el('input'); c.type = 'checkbox'; c.checked = !!val; l.append(c, ' ' + label); if (title) l.title = title; return [l, c]; };
    const [l1, c1] = chk('Tylko obiekty wybrane w oknie głównym', v.onlySelected,
      ['Wykładowcy: ' + (names('L') || '-'), 'Grupy: ' + (names('G') || '-'), 'Zasoby: ' + (names('S') || '-')].join('\n'));
    const [l2, c2] = chk('Każdy wykładowca / grupa / zasób osobno', v.split, 'Zajęcia kilku grup liczone dla każdej grupy osobno (inaczej: wiersz "Grupa A; Grupa B")');
    this.onlySel = c1; this.split = c2;
    this.phrase = el('input'); this.phrase.type = 'search'; this.phrase.placeholder = 'Dowolna fraza (kilka fraz oddziel przecinkiem)'; this.phrase.value = v.phrase || '';
    filt.append(el('span', 'muted', `Okres: ${this.ctx.period ? this.ctx.period.name : '-'}`), l1, l2, this.phrase);
    const actions = el('div', 'b-actions pv-actions');
    this.bGo = button('Utwórz tabelę', 'primary', () => this.generate());
    this.bXls = button('', 'secondary small', () => this.exportExcel(), 'Eksport do Excel'); this.bXls.innerHTML = EXCEL_ICON + ' Eksport do Excel'; this.bXls.disabled = true;
    this.bPrint = button('Drukuj', 'secondary small', () => this.print()); this.bPrint.disabled = true;
    this.status = el('span', 'muted');
    actions.append(this.bGo, this.bXls, this.bPrint, this.status);
    this.out = el('div', 'pv-out');
    d.append(head, form, filt, actions, this.out);
  }

  async generate() {
    const rows = this.rowSel.map(s => s.value).filter(Boolean);
    const col = this.colSel.value;
    if (!rows.length) { this.status.textContent = 'Wybierz pole wierszy.'; return; }
    const keys = [...new Set([...rows, col].filter(Boolean))];
    const opts = Object.fromEntries(ALL_FLAGS.map(f => [f, false]));
    for (const k of keys) Object.assign(opts, FIELDS.find(f => f[0] === k)[2]);
    if (this.split.checked) { opts.LnewLine = keys.includes('L'); opts.GnewLine = keys.includes('G'); opts.RnewLine = keys.includes('R'); }
    opts.period = this.ctx.period && this.ctx.period.id;
    opts.sortOrder = '1';
    opts.phrase = this.phrase.value.trim();
    if (this.onlySel.checked) for (const [t, k] of [['L', 'lec'], ['G', 'gro'], ['S', 'rom']]) opts[k] = this.ctx.objects[t].map(i => i.id);
    try { localStorage.setItem(PREF_KEY(this.ctx.user), JSON.stringify({ rows: this.rowSel.map(s => s.value), col, onlySelected: this.onlySel.checked, split: this.split.checked, phrase: opts.phrase })); } catch { /* brak pamięci */ }
    this.bGo.disabled = true; this.status.textContent = 'Tworzenie tabeli…';
    let r;
    try { r = await this.api('report', opts); } catch (e) { this.status.textContent = e.message; this.bGo.disabled = false; return; }
    this.bGo.disabled = false;
    this.pivot(r, rows, col);
  }

  // dane raportu -> tabela: klucz wiersza (kilka pól), kolumna, suma godzin
  pivot(r, rows, col) {
    const idx = label => r.columns.indexOf(label);
    const valueOf = (row, key) => {
      const f = FIELDS.find(x => x[0] === key);
      if (key === 'L' && this.split.checked) return ['Tytuł', 'Imię', 'Nazwisko'].map(c => row[idx(c)]).filter(Boolean).join(' ').trim() || '(brak)';
      const label = /^desc\d$/.test(f[3]) ? this.ctx.settings.descPlural[f[3].slice(-1) - 1] : f[3];
      const v = row[idx(label)];
      return v === null || v === undefined || v === '' ? '(brak)' : String(v);
    };
    const sumIdx = idx('Zajęcia (suma)');
    const cells = new Map(), rowKeys = new Map(), colKeys = new Set();
    for (const row of r.rows) {
      const rk = rows.map(k => valueOf(row, k));
      const k = JSON.stringify(rk);
      const ck = col ? valueOf(row, col) : 'Razem';
      rowKeys.set(k, rk);
      colKeys.add(ck);
      const v = Number(row[sumIdx]) || 0;
      cells.set(k + '\u0001' + ck, (cells.get(k + '\u0001' + ck) || 0) + v);
    }
    const order = key => (a, b) => {
      if (key === 'dayOfWeek') return WD_ORDER.indexOf(a.replace('.', '')) - WD_ORDER.indexOf(b.replace('.', ''));
      if (key === 'hour' && this.ctx.period) { const h = this.ctx.period.hours.map(x => x.caption || String(x.no)); return h.indexOf(a) - h.indexOf(b); }
      return a.localeCompare(b, 'pl', { numeric: true });
    };
    const cols = [...colKeys].sort(col ? order(col) : () => 0);
    const rws = [...rowKeys.entries()].sort((a, b) => {
      for (let i = 0; i < rows.length; i++) { const c = order(rows[i])(a[1][i], b[1][i]); if (c) return c; }
      return 0;
    });
    const round = x => Math.round(x * 100) / 100;
    this.result = {
      header: [...rows.map(k => this.fieldLabel(FIELDS.find(f => f[0] === k))), ...(col ? cols : []), 'Razem'],
      rows: rws.map(([k, rk]) => {
        const vals = cols.map(c => round(cells.get(k + '\u0001' + c) || 0));
        return [...rk, ...(col ? vals : []), round(vals.reduce((a, b) => a + b, 0))];
      }),
    };
    const totals = cols.map(c => round([...rowKeys.keys()].reduce((a, k) => a + (cells.get(k + '\u0001' + c) || 0), 0)));
    this.result.total = ['Razem', ...rows.slice(1).map(() => ''), ...(col ? totals : []), round(totals.reduce((a, b) => a + b, 0))];
    this.render(rows.length);
    this.status.textContent = `${rws.length} wierszy${r.truncated ? ' (dane obcięte - zawęź filtry)' : ''}`;
    this.bXls.disabled = this.bPrint.disabled = !rws.length;
  }

  render(nRowFields) {
    const { header, rows, total } = this.result;
    this.out.innerHTML = '';
    if (!rows.length) { this.out.append(el('p', 'muted', 'Brak zajęć dla wybranych filtrów.')); return; }
    const t = el('table', 'pv-table');
    const tr = el('tr'); header.forEach((h, i) => tr.append(el('th', i >= nRowFields ? 'num' : '', h)));
    const thead = el('thead'); thead.append(tr); t.append(thead);
    const tb = el('tbody');
    for (const r of rows) {
      const x = el('tr');
      r.forEach((v, i) => x.append(el(i < nRowFields ? 'th' : 'td', i >= nRowFields ? (v ? 'num' : 'num zero') : '', i >= nRowFields && !v ? '' : String(v))));
      tb.append(x);
    }
    t.append(tb);
    const tf = el('tfoot'); const fr = el('tr'); total.forEach((v, i) => fr.append(el(i < nRowFields ? 'th' : 'td', i >= nRowFields ? 'num' : '', String(v)))); tf.append(fr); t.append(tf);
    this.out.append(t);
  }

  exportExcel() {
    if (!this.result) return;
    downloadXlsx('Tabela przestawna', 'Tabela przestawna', this.result.header, [...this.result.rows, this.result.total]);
  }

  print() {
    if (!this.result) return;
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(`<!doctype html><html lang="pl"><head><meta charset="utf-8"><title>Tabela przestawna</title><style>
      body { font: 12px 'Segoe UI', Tahoma, sans-serif; margin: 12px; } table { border-collapse: collapse; }
      th, td { border: 1px solid #999; padding: 3px 6px; } td { text-align: right; } thead th, tfoot td, tfoot th { background: #eef2f7; }
      @media print { button { display: none; } }</style></head><body>
      <h1 style="font-size:16px">Tabela przestawna - ${this.ctx.period ? this.ctx.period.name.replace(/</g, '&lt;') : ''}</h1>
      <button onclick="print()">Drukuj</button>${this.out.innerHTML}</body></html>`);
    w.document.close();
  }
}
