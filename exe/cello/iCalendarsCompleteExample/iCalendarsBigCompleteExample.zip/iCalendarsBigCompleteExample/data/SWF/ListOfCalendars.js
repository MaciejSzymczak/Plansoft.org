var data = [
{ calendarName: 'I6ZG Grupa', link: 'https://calendar.google.com/calendar/ical/8qfm19oag7b0r1b2f59jc7febs@group.calendar.google.com/public/basic.ics' }];