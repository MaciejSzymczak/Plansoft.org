var data = [
{ calendarName: 'I6ZG Grupa', link: 'https://calendar.google.com/calendar/ical/dd41ae54dkg0tk425poedhel0g@group.calendar.google.com/public/basic.ics' }];