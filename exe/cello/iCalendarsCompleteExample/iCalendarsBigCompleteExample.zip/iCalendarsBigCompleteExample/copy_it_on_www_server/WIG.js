var data = [
{ calendarName: 'I6ZG Grupa', link: 'https://calendar.google.com/calendar/ical/p77tic2v6lu1vhhgd4lpji8730@group.calendar.google.com/public/basic.ics' }];