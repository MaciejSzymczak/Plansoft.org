var data = [
{ calendarName: 'I6ZG Grupa', link: 'https://calendar.google.com/calendar/ical/b69nc28c3so1j87ugt22acjdro@group.calendar.google.com/public/basic.ics' }];