/**
 * @author fhelwanger
 */
$.paramquery.pqGrid.regional["pt-br"] = {
    strLoading: "Carregando",
    strAdd: "Incluir",
    strEdit: "Editar",
    strDelete: "Excluir",
    strSearch: "Pesquisar",
    strNothingFound: "Não encontrado",
    strSelectedmatches: "Selecionado {0} de {1} resultados",
    strPrevResult: "Resultado Anterior",
    strNextResult: "Próximo Resultado"
}

$.paramquery.pqPager.regional['pt-br']={
    strPage: "Página {0} de {1}",
    strFirstPage: "Primera Página",
    strPrevPage: "Página Anterior",
    strNextPage: "Próxima Página",
    strLastPage: "Última Página",
    strRefresh: "Atualizar",
    strRpp: "Registros por página: {0}",
    strDisplay: "Mostrando {0} a {1} de {2} itens."
}
