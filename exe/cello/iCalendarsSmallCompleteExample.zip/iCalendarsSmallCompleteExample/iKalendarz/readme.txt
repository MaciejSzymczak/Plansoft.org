How to install

1/ Copy files bin/data/doc
   ! replace paths (..damian..)
   ! update conf.bat
2/ Schedule publikacja.exe, sftp.exe and sync.exe
   ! Instruct user there must be 3 items in tryicons
3/ copy "copy_it_on_ftp_server"
