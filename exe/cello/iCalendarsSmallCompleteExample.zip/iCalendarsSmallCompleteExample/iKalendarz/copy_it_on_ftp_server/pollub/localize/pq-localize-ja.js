/**
 * @author pdhindsa
 */
$.paramquery.pqGrid.regional['ja'] = {
    strAdd: "追加",
    strDelete: "削除",
    strEdit: "編集",
    strLoading: "ロード中",
    strNextResult: "次の結果",
    strNoRows: "表示する行がありません。",
    strNothingFound: "見つかりませんでした。",
    strPrevResult: "前の結果",
    strSearch: "検索",
    strSelectedmatches:"",
};
$.paramquery.pqPager.regional['ja']={
    strDisplay:" {2} 項目中　{0} から {1}　を　表示",
    strFirstPage:"最初",
    strLastPage:"最後",
    strNextPage:"次",
    strPage:"{0}　/ {1}  ページ",
    strPrevPage:"前",
    strRefresh:"リフレッシュ",
    strRpp:"１ページあたりのレコード: {0}",
};
